# 3.2 Market research

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain what the size, growth and competitive structure of a market tell a business, and identify the characteristics, profiles, wants and needs of the customers and consumers in it.
- Explain the distinction between primary and secondary research and the main features of each, and analyse how useful the data collected by each is for a particular business decision.
- Explain why market research is carried out on a sample rather than on a whole population, and analyse the limitations that follow from working with a sample.
- Explain what makes collected data reliable or unreliable, analyse quantitative and qualitative data using totals, percentages and averages and by grouping answers into themes, and interpret information presented in tables, charts and graphs.

---

## Reading a market, and the people in it

### Market size, measured two ways

The size of a market is the total sales in it over a stated period - a year, a quarter, a season.

**Market size by volume** is the number of units sold: 6.2 million litres of long-life milk, 24 000 school uniforms, 1.2 million cubic metres of ready-mixed concrete.

**Market size by value = units sold in the market x the average price paid.** It is what those units sold for.

The two measures can point in opposite directions, because value carries price inside it and volume does not. A market in which fewer units are sold at higher prices is growing by value and shrinking by volume at the same time. Which figure a business needs depends on the decision: a producer planning how much plant and how many staff it needs is planning in volume, while a producer planning revenue, margins and how much it can borrow is planning in value.

### Growth and share, worked through

**Market growth (%) = (size at the end - size at the start) / size at the start x 100.**

Take the Namibian market for ready-mixed concrete. Last year it was worth N$480 million; this year N$552 million. Working in N$ million: 552 - 480 = 72, and 72 / 480 = 0.15. The market grew by **15% by value**.

Now the volume. Last year the same market took 1.2 million cubic metres; this year 1.15 million. Volume fell by about 4%. So where did the 15% come from? From price. Average price last year = 480 / 1.2 = **N$400 per cubic metre**; this year = 552 / 1.15 = **N$480 per cubic metre**, a rise of 80 / 400 = 0.2, or **20%**.

That is a market worth more and selling less. A batching plant reading only the value figure would plan for growth and buy capacity it has no work for.

**Market share (%) = the business's sales / total market sales x 100**, on value or on volume, and which one has to be stated because they give different answers. A producer selling N$138 million of concrete into that market holds 138 / 552 = 0.25, a **25% share** by value.

### What growth and competitors tell a business

Growth and share are not two more numbers to memorise. They answer two questions a business cannot answer from its own sales figures.

**Where did our sales come from?** A business whose sales rose 6% in a market that grew 15% sold more and lost ground: its share fell. Without the market figure it would read the 6% as success. Market growth is what separates sales won because the market expanded from sales taken off a rival.

**How much of this market is open to us?** The number of competitors matters less than how the share is divided among them. Where three producers hold 45%, 30% and 15%, and the remaining 10% is spread among small yards, 90% of the market is already committed to an established supplier. A business entering there is likely to have to take work off one of the three rather than find buyers who have not chosen yet, and that usually means a lower price or a clear point of difference - faster delivery, a grade of product the others do not offer. Where instead the largest producer holds 12% and the rest is fragmented, buyers are already used to switching, and the same entry may cost far less.

### Customers, consumers, wants and needs

The **customer** is the person or organisation that buys the product. The **consumer** is the person who uses it. Often they are the same person. Where they are not - a parent buying a school uniform, a procurement officer buying office chairs, a lodge buying breakfast cereal for guests - the buying decision sits with one person and the experience of the product with another, and research that reaches only one of them misses half of what it needs.

A **need** is something the consumer must have for basic living, or something the product must do to work at all: a uniform has to fit, survive washing and meet the school's colour rules. A **want** is a preference for one particular way of meeting that need: this fabric, this shop, this price, delivered this week. Since competing products in a market usually meet the same need, the choice between them is normally settled by wants, which is where the research effort belongs.

### A profile that changes a decision

A **customer profile** describes the typical buyer: age, income, occupation, gender, location, household situation, lifestyle, and buying behaviour - how often they buy, how much they spend, what prompts the purchase.

A new bakery in Katima Mulilo describes its customers as "people who like bread". Nothing follows from that. Now the profile: households within about two kilometres of the open market, buying five days a week, spending N$25 to N$40 a visit, most of it before eight in the morning on the way to work, paying in cash or by mobile transfer.

Each of those characteristics changes a decision the bakery has to make anyway. "Before eight in the morning" sets the baking schedule and the opening time. "N$25 to N$40 a visit" sets the loaf sizes worth stocking and rules out a premium range. "Within two kilometres" says the delivery van is not needed yet and the site matters more than advertising. "Cash or mobile transfer" decides what the till has to accept.

That is the test of a profile: it is built from characteristics the business can act on. A profile recording that customers are aged 25 to 45 and enjoy fresh bread is true and changes nothing, so it directs no spending anywhere.

### Common errors

**"Market size and market share are the same measure."** Market size is the whole market; share is one business's slice of it. A business can grow its sales while its share falls, if the market grew faster - which is precisely why both figures are needed.

**"Customer and consumer mean the same thing."** They are the same person often enough for the difference to look like pedantry, and then a business researches only the buyer. The parent chooses the school shoe on price and durability; the child decides whether it is worn without complaint, and that decides the repeat purchase.

**"A profile is a description of the average customer."** An average can describe nobody. A profile is useful when it names characteristics that change what the business does, not when it computes a middle value of every customer it has.

---

## Primary and secondary research

### Primary research

**Primary research**, also called field research, is the collection of new data first-hand - by the business itself or by a research firm it pays - for the particular question it is trying to answer.

Its usual methods are worth knowing by what each one produces.

**Questionnaires and surveys** put the same set of questions to many people, on paper, by telephone, online or face to face. They produce numbers that can be counted and scaled up.

**Interviews** put open questions to one person at a time and follow the answers where they lead. They produce reasons rather than counts.

**Focus groups** put a small number of people in a room with a moderator and a product or an idea. They surface reactions people would not have thought to write on a form, and they carry the risk that one confident voice pulls the rest along.

**Observation** watches what people actually do - which shelf they stop at, how long the queue is, which route they take through the store - rather than what they say they do.

**Test marketing** sells the product for real in one town or one branch before a full launch, so the evidence is money changing hands rather than stated intention.

### Secondary research

**Secondary research**, also called desk research, is the use of data that already exists because someone collected it for another purpose.

**Internal** secondary sources sit inside the business: sales figures by product, month and branch; customer records; delivery and returns records; reports written for an earlier decision.

**External** secondary sources sit outside it: the national statistics agency and the central bank, trade association figures, published market reports bought from research firms, competitors' price lists, annual reports and advertising, news reporting, and data published online.

The word "secondary" says nothing about quality. A national household survey run by a statistics agency on a sample of 10 000 households is secondary data to a bakery, and it is better data than anything the bakery could collect for itself.

### What actually separates them

The distinction rests on **who collected the data and why** - not on whether it is numbers or words, and not on how it was gathered.

Data the business collected itself, for the question in hand, is primary however informal the method: a shop owner counting how many people walk past between seven and nine in the morning is doing primary research. Data someone else collected for their own purpose is secondary however closely it happens to fit: a tourism report commissioned by a ministry is secondary data to a lodge, even though the lodge needs exactly those arrival figures.

From that single difference the features of each follow.

Primary data is collected to the business's own specification - its sample, its questions, its timing, its level of detail - and stays with the business unless it chooses to release it. It takes as long as the fieldwork takes, and costs what the fieldwork costs.

Secondary data already exists, so it can usually be in the business's hands within days and at a small fraction of the cost. In exchange, its age, its coverage, its categories and the method behind it were all fixed by whoever collected it, and none of those can be changed afterwards.

### How useful primary data is

The strength of primary data is that it answers the question that was actually asked. The business chooses who is sampled, how the questions are worded, when the fieldwork happens and how much detail is collected, so the findings arrive in a form the decision can use without adjustment. A lodge that wants to know what German visitors arriving in October would pay for a guided walk can ask German visitors arriving in October. No published report is cut that way.

A second strength is exclusivity. Because the business commissioned the data and holds it, rivals are unlikely to have the same findings, so a move based on it may take a competitor longer to anticipate or match than one based on a report any of them can buy.

Against that stand three limits, and they bite hardest on small businesses.

**Cost.** Three hundred face-to-face interviews at N$100 each is N$30 000 before anyone analyses them.

**Time.** The design, the fieldwork and the analysis all have to happen before there is any answer at all. A decision that has to be made in a fortnight cannot wait for a four-week study.

**Quality of the fieldwork.** This is the one that is missed. Primary data is only as good as the way it was collected. A sample that does not represent the target market, a question that suggests its own answer - "would you agree that our prices are reasonable?" - or respondents saying what sounds reasonable rather than what they will do, all produce data that is precise about the wrong thing. The figures still come out to one decimal place, which is what makes the error hard to see.

So primary research repays its cost where the decision is large enough that being wrong is expensive, where no existing data answers the question, and where there is time to run it. Where one of those fails, the same money is likely to do more work spent on secondary sources or on a smaller, narrower primary study.

### How useful secondary data is

The strength of secondary data is that it exists. It can be obtained quickly and cheaply, it frequently covers a whole market or a ten-year run that no single business could afford to survey, and it establishes market size, growth and structure before a cent is spent on fieldwork. For a business deciding whether a market is worth entering at all, that is often the only evidence the decision needs.

Its limits follow from the same fact - it was collected for someone else.

Its **definitions and coverage** may not match the question. A national figure for household spending on "beverages" does not separate bottled water from soft drinks, and a figure for Namibia as a whole says little about Kavango East.

It may be **out of date**. A report published in 2024 may rest on fieldwork done in 2022.

Its **method may not be published**, so how many people were asked, and how they were chosen, cannot be checked. The reliability of the figures cannot be judged from the figures.

It is **available to rivals**. A report that can be bought can be bought by competitors, so it rarely produces an advantage none of them has.

Internal secondary data is a special case worth separating out. The business's own sales records are cheap, already in its own categories and usually current - but they describe the people who already buy from it. They say nothing about the part of the market it has not reached, and nothing about why the people who did not buy stayed away. A business that plans from its own sales records alone is planning from the customers it has about the customers it does not have.

### Choosing between them, in a real decision

Etosha Trails is a small tour operator in Outjo deciding whether to add a four-day self-drive package. It has N$40 000 for research and six weeks before it must commit to the brochure printing.

A published tourism report costs N$6 000 and gives arrivals by nationality, length of stay and average spend for the last five years, from fieldwork done in 2024. A research firm quotes N$34 000 for 300 face-to-face interviews with visitors at two lodges, taking four weeks.

The report answers one question well - is there a flow of visitors of the right kind, and is it growing? It cannot answer the question the decision actually turns on: what these visitors would pay for this package. Nobody has collected that, because the package does not exist.

The sensible order is not either-or. The report first, at N$6 000: if arrivals in the relevant segment have been falling, the decision is settled and N$34 000 has been saved. If they have been rising, the interviews follow, and they can now be narrowed to price and content because the report has already answered the size question. That is the general pattern: secondary research first to establish cheaply what is already known, primary research after it, aimed only at what fieldwork alone can settle.

### Common errors

**"Numbers are primary data and opinions are secondary data."** The form of the data has nothing to do with it. A focus group transcript the business commissioned is primary; a table of government statistics is secondary.

**"Secondary data is the cheap, poor-quality option."** Cheap, usually. Poor quality, not necessarily - a national statistical survey is built on a sample far larger than a small business could fund. The weakness of secondary data is fit and age, not accuracy.

**"Primary data is reliable because the business collected it itself."** Collecting it yourself controls the questions; it does not make the answers representative. Badly sampled primary data is worse than good secondary data, and more expensive.

---

## Sampling: why it is necessary and where it goes wrong

### Population, sample, and what one says about the other

The **target population** is everyone the findings are meant to describe - all households in a town, all buyers of a product, all visitors to a park. The **sample** is the part of that population actually researched, and **sampling** is the process of selecting it.

The whole method rests on one step: a result measured on the sample is used as an estimate of the result that would have been obtained from the whole population. Everything that can go wrong with sampling goes wrong at that step.

### Why a sample is necessary

Researching an entire population is rarely practical. Populations are large: a bank asking every one of its 180 000 account holders would be running a national exercise, not a piece of market research. Contacting all of them costs more money and takes more time than the decision can justify - and the decision usually has a date by which it has to be made. And in many markets no complete list of the population exists to work from: there is no register of everyone who buys bread.

So the choice is not between a sample and a complete count. It is between a sample and no evidence at all.

### How far a sample result can sit from the truth

A sample result differs from the population figure by **sampling error**. It tends to fall as the sample grows, but not in proportion to the sample.

As an approximate guide for a percentage result, the margin of error is about **1 divided by the square root of the sample size**.

Work it through. A retailer in Ondangwa surveys 400 of the 62 000 households in its catchment about a new product at N$25. Of the 400, 148 say they would buy it.

Proportion saying yes = 148 / 400 = 0.37, that is **37%**.

Scaled to the catchment: 0.37 x 62 000 = **22 940 households**.

Now the margin. The square root of 400 is 20, and 1 / 20 = 0.05 - about **5 percentage points either way**. So the true proportion is likely to sit somewhere between 32% and 42%, which is between 0.32 x 62 000 = 19 840 and 0.42 x 62 000 = 26 040 households.

At N$25 each, that is revenue of anywhere between 19 840 x 25 = N$496 000 and 26 040 x 25 = N$651 000 - a spread of N$155 000 on a single survey result. The point of the arithmetic is that the estimate is a range, and a business that plans for the midpoint is planning for a figure the research did not establish.

Narrowing the range costs. To halve the margin to about 2.5 points the sample has to reach about 1 600, because the square root of 1 600 is 40 and 1 / 40 = 0.025. Four times the fieldwork, four times the cost, for half the margin. That diminishing return is why most commercial samples stop in the hundreds.

### The limitation that size does not fix

Sampling error is the manageable problem. The serious one is **bias**: the people in the sample differing systematically from the population.

Suppose those 400 households were approached at a shopping centre on two Saturday mornings. Everyone in the sample was at a shopping centre, on a weekend, and willing to stop and answer questions. Households without transport, households working weekends and people who walk past surveys are all under-represented. Raising the sample to 1 600 at the same shopping centre does not correct any of that: it reproduces the same bias more precisely, and the narrower margin of error makes the result look more trustworthy than it is.

Two ways of selecting reduce the risk. Choosing respondents **at random** from the whole population gives every member a known chance of selection, so no group is systematically left out - though it needs a list of the population to draw from, which is often what is missing. Setting **quotas** that match proportions already known about the population - by age, by area, by income band - forces the sample to resemble the population on those characteristics, though it can still be unrepresentative on a characteristic nobody set a quota for.

Neither removes **non-response**. People who decline to answer are not a random subset of those approached, and the research cannot measure how they differ, because they did not answer. That is why a response rate is reported alongside a finding: it is the reader's only signal of how much of the population the finding is silent about.

---

## Judging data, and reading what it shows

### Reliability, and how it is judged

**Reliability** is the degree to which data can be depended on to describe what it claims to describe, so that a decision taken on it rests on the market rather than on an artefact of how the data was collected.

It cannot be judged from the figures. A percentage calculated to one decimal place from a biased sample is exactly as precise, and exactly as wrong, as it would be from a sound one. Reliability is judged from how the findings were produced, and six questions cover most of it.

**Who collected it, and did they have an interest in the result?** A survey funded by a producer showing its own product preferred is not worthless, but the question of who chose the wording is live.

**How were the respondents selected?** At random, by quota, or by whoever happened to be standing there?

**How many were there?** A finding from 40 people carries a wide margin whatever else is true of it.

**How were the questions worded?** A question that suggests its own answer collects agreement, not information.

**When was it collected?** Data can be an accurate record of its own period and a poor guide to the present. The risk grows with the age of the data and with the speed at which the market moves: three-year-old figures may still be sound for maize meal and useless for mobile data prices.

**How many of those approached answered?** This is the one that is skipped, and it is the one that bites.

### Why the response rate decides what a finding means

A retailer emails a satisfaction survey to 500 customers. Sixty reply, and 48 of them - 48 / 60 = 0.8, or 80% - rate the service good or better.

Trace what that figure describes. It describes the 60 who replied. The other 440 were not measured. People who reply to a satisfaction survey from a business they deal with tend to be those with a reason to reply, and being pleased with the service is one such reason. If the 440 silent customers contained a higher proportion of dissatisfied ones, the true satisfaction across all 500 is below 80% - and the data cannot say by how much, because the people who would answer that question are the people who did not answer.

The consequence for the business is concrete: it reads 80%, concludes service is not where its problem lies, and directs its spending elsewhere while the customers it is losing go on leaving. A response rate of 60 out of 500 is 12%, and quoting the 80% without the 12% beside it is what makes the error invisible.

### Quantitative and qualitative data

**Quantitative data** is information in numerical form - how many, how much, how often. It can be totalled, averaged, turned into percentages and compared across periods.

**Qualitative data** is information about opinions, reasons and attitudes, expressed in words. It is analysed by grouping answers into recurring themes and counting how often each theme appears, not by doing arithmetic on the answers themselves. Forty interview transcripts in which 23 people mention the size of the portion and 9 mention the waiting time have been analysed the moment those themes are named and counted.

The two answer different questions, and that is the whole reason for collecting both. Numbers show how many and how much, so they can be scaled to the market and carried into a forecast. Words show why, so they explain the number and point at what could be changed. A restaurant that knows takings fell 14% knows the size of its problem and not its cause; a restaurant that knows customers find the portions small knows the cause and not whether it explains 14% or 2%. Neither figure alone tells it what to do.

### Averages, and which one to quote

Three averages are used, and they answer slightly different questions.

**Mean = the total of the values / the number of values.** **Median** = the middle value once they are in order, or the midpoint of the two middle values when there is an even number. **Mode** = the value that occurs most often.

A wholesaler records what ten customers spent in a week, in N$:

40, 45, 50, 50, 55, 60, 65, 70, 75, 490

The total is N$1 000, so the mean = 1 000 / 10 = **N$100**. In order, the two middle values are 55 and 60, so the median = (55 + 60) / 2 = **N$57.50**. The value appearing most often is 50, so the mode = **N$50**.

Three answers from one set of figures, and they are not interchangeable. Nine of the ten customers spent less than the mean, which is pulled upwards by the single N$490 order. The median is unaffected by how large that one order is, so it describes the middle customer.

The decision this changes is a real one. A wholesaler pricing a bundle "for a typical customer spending around N$100" has designed it for one customer out of ten. Built around N$57.50, it fits the middle of the trade. The mean is not wrong - it is the right figure for working out total takings - but it answers a different question from the one being asked.

### Reading a table before reading the trend

Interpretation starts with four things, in this order: what is being measured, in what units, over what period, and for whom. The title, the column headings or axis labels, the units and the source. Only then the shape of the numbers. A figure read without those four can be compared with something it is not comparable to - units against value, one region against a whole country, one quarter against a full year.

Namib Tiles, a floor-tile producer, has this table in front of it.

| Year | Market volume (tiles) | Namib Tiles sales (tiles) | Namib Tiles share |
|---|---|---|---|
| 2023 | 400 000 | 80 000 | 20% |
| 2025 | 500 000 | 90 000 | 18% |

The share figures check out: 80 000 / 400 000 = 0.20 and 90 000 / 500 000 = 0.18.

Two true statements come out of the same two rows and they sound like opposites. Namib Tiles sold 10 000 more tiles in 2025 than in 2023, a rise of 10 000 / 80 000 = 0.125, or 12.5%. And its share of the market fell by 2 percentage points.

Both are right, because the market grew faster than the business did: 100 000 / 400 000 = 0.25, a 25% rise in volume against Namib Tiles' 12.5%. Rivals took 90 000 of the 100 000 extra tiles. So a sales director reporting growth and a marketing director reporting lost ground are describing the same two rows, and the business needs both readings - the sales figure says the year was not a bad one, the share figure says the position is weakening.

### How an accurate graph misleads

A graph can be accurate in every number and still leave a false impression, which is why the axis is read before the line.

**A vertical axis that does not start at zero** magnifies small changes. Sales moving from 980 to 1 000 units is a rise of 20 / 980 = 0.02, about 2%. Drawn on an axis running from 970 to 1 010, the line climbs most of the height of the picture. Nothing is falsified; the impression is still wrong.

**A scale that changes part-way along** - quarterly points for three years followed by annual points - makes the later section look flatter than it is, because the same horizontal distance now carries four times as much time.

**A short run of periods** can hide the direction of a longer one. Three rising months inside a five-year decline are still a five-year decline.

And two series that rise together show an **association, not a cause**. A lodge whose bookings and advertising spending both rose through the year may be looking at advertising that worked, at a busy season in which it spent more because bookings were strong, or at both following the same tourist arrivals. Deciding which needs evidence the pattern itself cannot supply: a period in which one moved and the other did not, or a controlled test - holding spending flat in one month and watching what bookings do.

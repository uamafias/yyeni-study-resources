# 4.2 Inventory management

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain why a business holds raw materials, work in progress and finished products; weigh what holding inventory costs against what it buys; work with lead time, buffer inventory and the re-order level; read a simple inventory control chart; and explain why supply chain management matters to a business that controls only part of its own chain.
- Explain what just in time and just in case inventory management are for, and analyse and evaluate what adopting a just-in-time approach does to a business, its suppliers and its staff.

---

## Inventory, what it costs to hold, and how a business controls it

### Inventory

Inventory is the stock of goods a business holds at a point in time. It has three types: the raw materials and components it has bought but not yet used, the work in progress that has entered its process but is not yet finished, and the finished products it has made but not yet sold.

Inventory is not the same thing as an asset the business means to keep. A delivery van is bought to be used for years. A pallet of cement is bought to be sold, or built into something that is sold, and turned back into cash. Inventory is money parked in goods on their way to becoming money again, and how long it stays parked is what inventory management is about.

### Why each type is held

**Raw materials.** These are the bought-in inputs waiting to be used. A business holds them because supply and production do not run to the same rhythm. Deliveries arrive in batches, on days that suit the supplier and the transport; the process consumes material continuously. A stock of raw materials bridges that gap, and it keeps the process running when a delivery is late or usage is heavier than planned.

**Work in progress.** This is output that has started down the process and has not yet come out of the other end: dough proving, a chassis part-welded, an order picked but not packed. Some work in progress is unavoidable, because any process that takes time has partly finished output inside it at any moment. A business may also hold more than that minimum on purpose, placing a small stock between two stages so that the later stage keeps working for a while when the earlier one stops.

**Finished products.** These are completed goods waiting to be sold or dispatched. They are held so that a customer who orders today can be supplied today rather than waiting for a production run, and so that output can be made at a steady rate while sales rise and fall through the year. A bottler that sells twice as much in December as in June can either build a plant large enough for December and leave it half idle in June, or run at an even rate all year and let finished-product inventory absorb the difference.

A service business fits the pattern only in part. It holds materials and consumables - a salon holds colour and towels, a clinic holds dressings - but it cannot hold a finished service, because a service is produced at the moment it is consumed. That is why a fully booked salon turns customers away instead of working ahead on Tuesday to sell on Saturday.

### What it costs to hold inventory

Holding inventory is not free, and the cost has more parts than a storage bill.

**Space and its running.** Warehouse rent, or the value of space the business owns and could otherwise use or let out. Racking, refrigeration for goods that need it, security, insurance against fire and theft, and the wages of the people who move, count and look after the goods.

**Capital tied up.** Money spent on goods sitting on a shelf is money the business cannot spend on anything else. If the inventory is financed by an overdraft there is interest to pay; if it is the owner's own money there is still an opportunity cost, because the same money could have bought a machine, reduced borrowing, or been kept as a cushion against a bad month.

**What can happen while goods wait.** Food and chemicals deteriorate. Clothing and electronics go out of fashion or are superseded. Goods are dropped, damaged by damp, or stolen. The longer the average item waits, the larger these losses tend to be.

**Ordering and administration.** Every order costs something to raise, chase, receive, check and pay for, and the records have to be kept accurately enough to be trusted.

Set against all that is the cost of the inventory a business does not hold, which is easy to leave out because no invoice ever arrives for it. Running out - a stock-out - stops production or leaves an order unfilled. The contribution on the sale is lost, the fixed costs of the period are incurred anyway, and a customer who is turned away may buy from a competitor next time as well.

### Putting a number on the holding cost

Businesses rarely add up every item on that list separately. The usual working figure is a rate: the annual cost of holding inventory expressed as a percentage of the average value held.

**Annual holding cost = average inventory value x holding-cost rate**

*Worked example.* Otavi Hardware holds an average of N$900 000 of inventory through the year. It puts its holding-cost rate at 18%: 7% for storage, security and insurance, 8% for the capital tied up, and 3% for damage, shrinkage and obsolescence.

Annual holding cost = N$900 000 x 0.18 = N$162 000 a year.

Per month that is N$162 000 / 12 = N$13 500.

*What the figure means.* N$13 500 a month is what Otavi pays for the cover its inventory gives it. It is the number to set beside the cost of the stock-outs that would happen if the average level were cut. Suppose it reduced average inventory to N$600 000: the annual holding cost would be N$600 000 x 0.18 = N$108 000, a saving of N$54 000 a year. That saving is worth having only where the thinner cover does not cost more than N$54 000 in lost sales and stopped work.

*What the figure does not tell you.* The rate is an estimate, and one average hides the mix. N$900 000 of cement behaves nothing like N$900 000 of laptops, because cement does not go out of date and laptops do, so a single rate applied to the whole store understates the risk on some lines and overstates it on others.

### What the inventory buys

Inventory is held because it does things for a business that nothing else does as cheaply.

**Demand that arrives unannounced can be met.** A hardware shop that has the fitting a plumber needs makes the sale; one that has to order it may not. What that is worth is the contribution on sales that would otherwise be lost, plus the goodwill of a customer who found what they came for.

**Production keeps going when supply does not.** A delivery held up at a border, a supplier's breakdown, a road closed by flooding - a stock of raw materials absorbs all of these without the process stopping. Stopping a process is expensive out of proportion to the length of the delay: the workforce is paid, the overheads run, and restarting may mean scrapping whatever was in the machine.

**Larger orders can be cheaper per unit.** Suppliers often price in quantity bands, and a delivery charge is spread over more units when fewer, fuller deliveries are made. A 4% discount on materials that are 60% of the cost of a product is worth more than the headline figure suggests.

**Output can be steadier than sales.** Where demand is seasonal, finished-product inventory lets a business produce at an even rate, which is usually cheaper than hiring and releasing staff twice a year, or than paying overtime through the peak.

### How much inventory is the right amount

The two sides pull against each other. More inventory costs more to hold and exposes more value to damage and obsolescence. Less inventory costs less to hold and raises the chance of running out. The level worth holding is the point at which carrying one more unit stops being cheaper than the stock-outs that unit would prevent.

That point is not the same for two businesses, because both sides of it are built from their own figures. A business with a high holding-cost rate - chilled goods, or expensive items financed by borrowing - pays a lot to carry cover. A business with a large contribution per unit, or customers who go elsewhere and stay there, pays a lot for a stock-out. And a business whose supply is quick and reliable needs less cover to reach the same protection than one waiting three weeks for an imported part.

So the answer moves when the figures move. A fall in interest rates lowers the cost of carrying inventory; a supplier that becomes unreliable raises the cost of not carrying it. The judgement is a comparison of two costs for this business at this time, not a target level that can be copied from another firm.

### Lead time, buffer inventory and the re-order level

Three terms do the work in inventory control, and one formula connects them.

**Lead time** is the time between placing an order with a supplier and the goods being available to use. It is not only the supplier's picking or manufacturing time: it includes transport, customs clearance where goods are imported, and the buyer's own goods-inwards checking. In practice a lead time is described by two figures rather than one - how long it usually takes, and how much it varies.

**Buffer inventory**, also called safety stock or the minimum inventory level, is the quantity the business plans to hold in reserve above what it expects to use during the lead time. It is there for the two things that go wrong: usage heavier than expected, and a delivery later than promised. Where both go to plan, the buffer is never touched.

**The re-order level** is the inventory level at which the next order is placed. It is not a quantity to order; it is a trigger point, set so that the goods arrive before the reserve runs out.

**Re-order level = (average usage per day x lead time in days) + buffer inventory**

The first part covers what will be used while the order is travelling. The second is the reserve that should still be sitting there, untouched, when the delivery arrives.

### Working out a re-order level

*Worked example.* A bakery in Katutura uses 40 bags of flour a day, six days a week. Its miller delivers five days after an order is placed. The owner wants enough in reserve to cover three days of baking if a delivery runs late.

Buffer inventory = 40 x 3 = 120 bags.

Usage during the lead time = 40 x 5 = 200 bags.

Re-order level = 200 + 120 = 320 bags.

*Interpretation.* When the flour store falls to 320 bags, the order goes in. Over the next five days the bakery expects to use 200 bags, so the level should be at 120 bags - the buffer, untouched - on the morning the delivery arrives. If the miller is two days late, the bakery eats 40 x 2 = 80 bags into the buffer and still bakes. If the miller is four days late, the buffer is gone and the ovens stop.

**The re-order quantity** is a separate decision: how much to order each time. Where deliveries arrive just as the buffer is reached, the maximum inventory level is the buffer inventory plus the re-order quantity. If the bakery orders 600 bags at a time, its maximum level is 120 + 600 = 720 bags, and its average level is roughly the buffer plus half the order, about 420 bags. Ordering more at a time means fewer orders and often a better price per bag; it also means a higher average level, and so a higher holding cost.

### When the lead time lengthens

Suppose the miller moves to weekly deliveries and the lead time goes from five days to eight. Nothing about the bakery's demand has changed, but three figures move.

Usage during the lead time rises from 200 bags to 40 x 8 = 320 bags, so the re-order level rises to 320 + 120 = 440 bags. The order has to go in earlier. If the owner also judges that a longer journey is a less certain one and raises the reserve from three days to four, buffer inventory becomes 40 x 4 = 160 bags and the re-order level becomes 320 + 160 = 480 bags.

The average level of flour held rises with the buffer, and the holding cost rises with it. The bakery is paying more to stand still: the same protection against a late delivery now costs it 40 more bags of average inventory, with the storage space, the interest and the spoilage risk that go with holding flour longer in a warm store.

The chain runs the other way too. A supplier that shortens its lead time, or makes it more predictable, lets the business cut the buffer for the same protection, releasing capital and lowering holding cost. That is one reason a business may pay slightly more per unit to a nearer or more dependable supplier: the saving is in the inventory it no longer has to finance.

### Reading a simple inventory control chart

A simple inventory control chart plots the inventory level on the vertical axis against time on the horizontal axis. The plotted line falls as inventory is used and jumps straight up when a delivery arrives, which gives the familiar saw-tooth shape. Three horizontal lines are drawn across it: the maximum inventory level, the re-order level, and the buffer inventory level.

Four quantities can be read off it.

- **The usage rate** is the steepness of the falling line: how many units the level drops over a given period.
- **The lead time** is the horizontal distance between the point where the falling line crosses the re-order level and the vertical rise that follows it.
- **The re-order quantity** is the height of that vertical rise.
- **Whether the buffer was broken into** is read by seeing whether the line went below the buffer inventory line before the delivery landed.

*Worked example.* Okahandja Hardware sells cement. It uses 100 bags a day, its supplier's lead time is three days, it keeps a buffer of 400 bags, and it orders 1 200 bags at a time. Usage during the lead time is 100 x 3 = 300 bags, so its re-order level is 300 + 400 = 700 bags, and its maximum level is 400 + 1 200 = 1 600 bags.

The plotted line for the first four weeks is set out below as a table of points, so that every value can be read exactly rather than estimated from a picture.

| Day | Bags held at the start of the day | What happens that day |
| --- | --- | --- |
| 0 | 1 600 | inventory being used at the normal rate |
| 3 | 1 300 | inventory being used at the normal rate |
| 6 | 1 000 | inventory being used at the normal rate |
| 9 | 700 | level reaches the 700-bag re-order level; the next order is placed |
| 12 | 400 (before delivery) | level down to the 400-bag buffer; delivery of 1 200 bags arrives, taking the level to 1 600 |
| 15 | 1 300 | inventory being used at the normal rate |
| 18 | 1 000 | inventory being used at the normal rate |
| 21 | 700 | level reaches the 700-bag re-order level; the next order is placed |
| 24 | 400 (before delivery) | level down to the 400-bag buffer; delivery of 1 200 bags arrives, taking the level to 1 600 |

Reading it: the line falls 300 bags every three days, which is the usage rate of 100 bags a day. It touches 700 bags on day 9 and the delivery lands on day 12, three days later - that gap is the lead time. The rise on day 12 takes the level from 400 to 1 600 bags, and 1 600 - 400 = 1 200 bags is the re-order quantity. The lowest point of each cycle is 400 bags, exactly the buffer, so nothing has gone wrong: the reserve has been reached but never broken into.

### What a departure from the plan looks like

The chart earns its keep when the actual line stops matching the plan.

**A steeper fall** means inventory is being used faster than the plan assumed. The line reaches the re-order level early and the buffer early, so the gap the buffer was meant to cover is smaller than intended.

**A rise plotted further to the right than the lead time** means the supplier was late. The line keeps falling past the point where it should have jumped, and that extra fall comes out of the buffer.

**A line that reaches zero** is a stock-out: from that point there is nothing to sell and nothing to work with until the delivery arrives.

*Continuing the example.* Okahandja Hardware orders again on day 33, when the level reaches 700 bags. The delivery is due on day 36, but the truck is held up and arrives on day 39.

| Day | Bags held at the start of the day | What happens that day |
| --- | --- | --- |
| 24 | 1 600 | the previous delivery has just arrived; the level is back to its 1 600-bag maximum |
| 27 | 1 300 | inventory being used at the normal rate |
| 30 | 1 000 | inventory being used at the normal rate |
| 33 | 700 | level reaches the 700-bag re-order level; the order is placed, delivery due on day 36 |
| 36 | 400 | planned delivery day; the level is at the 400-bag buffer but the delivery has not come |
| 37 | 300 | the delivery is still outstanding, so the fall is now eating into the buffer |
| 38 | 200 | the delivery is still outstanding, so the fall is now eating into the buffer |
| 39 | 100 | delivery of 1 200 bags finally arrives, taking the level to 1 300 |
| 42 | 1 000 | inventory being used at the normal rate |

The plan had the level at 400 bags on day 36 with the delivery arriving that morning. Instead the line keeps falling through the reserve: 300 bags on day 37, 200 on day 38, and 100 on day 39, when the delivery finally lands and takes the level to 1 300 bags. The three-day delay used 300 of the 400-bag buffer and left one day's cover. Had the truck been four days late instead of three, the line would have reached zero and the yard would have had no cement to sell.

That is the buffer doing exactly the job it was bought to do. It is also the argument for reviewing it: a supplier that runs three days late more than occasionally needs a larger buffer set against it, a shorter lead time agreed with it, or replacing.

### What the chart assumes, and what it does not show

The saw-tooth shape assumes two things that are rarely exactly true: that inventory is used at a steady rate, and that deliveries of a constant size arrive on the day they are due. Real usage is lumpy - one large order can take a week's stock in a morning - and real deliveries vary.

So the chart is a plan the actual line is compared against, not a forecast of what will happen. Its value is in the comparison. The moment the actual line crosses a planned line early or late, the business can see which of its figures is wrong: the usage rate it assumed, the lead time it was promised, or the buffer it chose.

Two further limits are worth holding on to. A simple chart tracks one item, so a wholesaler with four thousand lines would need four thousand of them; in practice it watches closely only the items where the value tied up, or the consequence of running out, is large. And the chart shows quantity, not value. A line sitting at 400 bags says nothing about whether that is N$20 000 or N$200 000 of capital standing still.

### Supply chain management

A supply chain is everything that has to happen for a product to reach the customer: the extraction or growing of the original materials, the businesses that process and assemble them, the transport between each pair of them, the warehouse, the shop or the delivery van, the customer - and the route back for returns.

**Supply chain management** is the management of the flow of materials, information and money along that chain. For one business it covers choosing and managing suppliers, purchasing, inbound transport, holding and controlling inventory, scheduling production, warehousing, and getting the finished product to the customer.

The word *information* is doing as much work in that definition as the word materials. Much of what goes wrong in a chain goes wrong because somebody downstream knew something - a promotion planned, an order cancelled, a machine broken - that somebody upstream did not.

### Why the rest of the chain decides what a business can promise

A business controls its own factory and its own shop. It does not control the mine, the mill, the shipping line or the border post, and yet what it can promise a customer depends on all of them.

The mechanism is easy to state and expensive to ignore. A supplier's delay becomes this business's delay, because the order cannot be completed without the part. A supplier's defect reaches the customer under this business's name, because the customer sees one product and one brand. And cost added anywhere in the chain ends up either in the price the customer pays or in the margin the business keeps.

Inventory is where this shows up in the accounts. The buffer a business holds is largely a purchase of protection against uncertainty in the chain. Where supply chain management shortens the lead time and makes it more predictable - a supplier nearer by, deliveries on a fixed schedule, forecasts shared far enough ahead for the supplier to plan - the buffer needed for the same protection falls, and with it the capital tied up and the holding cost. How large that saving is depends on how much of the inventory was there to cover lead-time uncertainty in the first place: a business holding stock mainly to earn bulk discounts saves little by making its supplier more punctual.

The chain carries risk that is not about time at all. A supplier's labour or environmental practices attach to the buyer's reputation as soon as a customer or a journalist connects the two, which is why large buyers tend to audit their suppliers rather than only pricing them.

### What this means for a Namibian business

Much of what Namibian manufacturers and retailers use is imported. Containers arrive through Walvis Bay; a great deal comes overland from South Africa on the B1. Either route adds distance, and both add steps that can slow down: port handling, customs clearance, cross-border formalities, and a long road haul on which one breakdown costs a day.

The consequence for inventory is direct. A long lead time raises the usage that has to be covered while an order is travelling, and a lead time that varies raises the buffer on top of that. A Windhoek workshop waiting three weeks for an imported component, give or take a week, has to carry roughly four weeks of that component to be reasonably safe - capital standing in a store room, exposed to damage and obsolescence, for a part that a workshop in Johannesburg might hold for three days.

That is why supply arrangements carry more weight here than the textbook case suggests. Consolidating orders so that fewer, fuller containers arrive on a schedule. Finding a regional supplier for the bulky, low-value items where transport is most of the landed cost. Agreeing that a supplier holds the stock and releases it weekly. Tracking a shipment so that a delay is known in time to act on it. Each of these reduces either the lead time or how much it varies, and both feed straight back into the buffer the business has to finance.

---

## Just in time and just in case

### Just in time (JIT)

Just in time is an approach to inventory in which materials and components are ordered and delivered so that they arrive as they are needed in production, and output is made to fill orders rather than to build a stock of finished products. Very little inventory is held at any stage.

JIT is not simply holding less stock. It is a way of running the whole operation, in which small frequent deliveries, short production runs and quick changeovers replace the buffers that used to absorb every irregularity. The inventory is removed; the irregularities have to be removed with it, or they stop the process.

### Just in case (JIC)

Just in case is the opposite approach. The business deliberately holds buffer stocks of materials and finished products so that production and sales continue when a delivery is late, a machine fails, or demand is higher than expected.

JIC is not carelessness about stock. It is a decision to buy continuity, and the price of it is the holding cost: the storage, the capital tied up, and the risk of goods deteriorating or going out of date while they wait.

### What each approach is for

**The purpose of JIT** is to take out the cost of holding inventory, to release the capital and the space that inventory occupies, and - less obviously - to make problems visible. Where a pile of spare parts sits beside a machine, a supplier delivering 5% defective components and a machine breaking down every fortnight can both be absorbed quietly for years. Take the pile away and each of them halts production within hours, so each of them has to be fixed. That gain is easy to underrate: the inventory saving is a one-off improvement, while a problem the inventory was hiding goes on costing money for as long as it is hidden.

**The purpose of JIC** is continuity. The inventory is insurance against what cannot be fixed or predicted: a port closure, a strike, a harvest failure, a competitor's product recalled and demand doubling in a week. A business that cannot afford to stop - because a stoppage costs it customers it will not get back, or because it supplies something that has to be available, such as medicines or fuel - is buying something real with its holding cost.

Put plainly: JIT minimises the cost of holding inventory and accepts more exposure to disruption, while JIC accepts a higher holding cost and buys protection from it. Neither is the correct answer in general. Which is better for a particular business depends on the size of those two costs for that business.

### What JIT needs in place

JIT works where a set of conditions holds, and it is those conditions, rather than the idea itself, that decide whether a business can adopt it.

- **Reliable, frequent supply.** Suppliers have to deliver small quantities, often, on time. A supplier three weeks away by sea cannot do that for a factory that needs parts daily unless somebody holds stock nearer - which usually means the supplier does, and charges for it.
- **Dependable transport.** The deliveries have to actually arrive. Where a single road, a single border post or a single port stands between supplier and factory, JIT inherits that risk.
- **Accurate, shared demand information.** A supplier can produce to a schedule only if it has been told about it far enough ahead to make what is wanted.
- **Quality that is right first time.** With no spares to draw on, one defective component halts the process. That usually means checking quality at each stage rather than at the end, and giving an operator the authority to stop the process when something is wrong.
- **A flexible workforce.** Short runs and frequent changeovers need staff who can move between tasks and machines, which means training and often a different way of organising and paying people.
- **Systems that can order and track.** Many small orders multiply the paperwork unless the ordering is automated and shipments can be tracked.

Where these conditions are weak, the same approach that removes holding cost exposes the business to stoppages. That is the whole evaluation in one sentence.

### What JIT is worth, and what it costs

The financial case has two sides, and both have to be counted.

*Worked example.* Erongo Furniture in Swakopmund holds an average of N$1 200 000 of timber, fittings and finished units. Its holding-cost rate is 20% a year. It takes twelve deliveries a year, and each delivery costs it N$1 500.

Holding cost now = N$1 200 000 x 0.20 = N$240 000 a year.

Delivery cost now = 12 x 1 500 = N$18 000 a year.

Under a JIT arrangement it would hold an average of N$300 000 and take a delivery every week - 52 a year.

Holding cost under JIT = N$300 000 x 0.20 = N$60 000 a year, a saving of N$240 000 - N$60 000 = N$180 000 a year.

Delivery cost under JIT = 52 x 1 500 = N$78 000 a year, an increase of N$78 000 - N$18 000 = N$60 000 a year.

Net saving = N$180 000 - N$60 000 = N$120 000 a year. On top of that, average inventory falls by N$1 200 000 - N$300 000 = N$900 000, and that capital is released once, into the bank or into whatever the business does with it next.

*Interpretation.* N$120 000 a year, plus N$900 000 released, is a real gain for a business of this size. It is also the whole of the gain, and it has to be set against what a stoppage would cost. If a week without timber costs Erongo N$90 000 in lost contribution, then a little more than one extra stoppage a year on average removes the annual saving - which puts the decision back where it belongs, on how dependable the supply actually is.

*What the calculation leaves out.* Quantity discounts given up on smaller orders, the cost of training and reorganising the workshop, and any price the supplier charges for holding the timber instead.

### What happens when supply is interrupted

Under JIC an interruption is absorbed. The materials for the next fortnight are already in the store, so a supplier running three days late costs the business three days of anxiety and nothing else.

Under JIT there is nothing to absorb it, and the chain runs like this. A delivery due on Tuesday morning does not arrive, because the truck has broken down, the border is congested, or the supplier's own supplier failed. By Tuesday afternoon the components on the line are used up and production halts. The workforce is paid to stand and the overheads run whether anything is made or not. Output not made is contribution not earned, and it cannot be recovered later if the plant is already working near capacity. If the business had promised a delivery date, it may pay a penalty or lose the order, and a customer let down twice may place the next one elsewhere.

The size of that cost is a figure a business can work out for itself: contribution per unit multiplied by the units not made, plus any penalty, plus the fixed costs incurred anyway while the plant stands. That is the number to put on the other side of the holding-cost saving.

None of this is an argument against JIT. It is an argument that the reliability of supply is what decides whether JIT is right, and that a business whose supply is not reliable should either make it reliable first or keep a reserve on the items where a stoppage would cost the most.

### What changes for suppliers, staff and customers

Adopting JIT changes relationships, not only stock levels.

**Suppliers.** A business running JIT tends to buy from fewer suppliers on longer agreements, because the arrangement depends on reliability and on sharing production schedules, and neither is worth building with a supplier used once. The supplier is asked to deliver more often in smaller amounts, which costs it more, so it may ask for a higher unit price, a minimum commitment, or payment for holding the stock itself. The buyer also becomes more dependent on each remaining supplier, which matters if one of them fails or raises its price.

**Staff.** Work is organised in smaller batches with more changeovers, so people move between tasks more often and need broader training. Quality becomes each operator's responsibility rather than an inspector's at the end, which usually comes with the authority to stop the process when something is wrong. Some workers value the variety and the responsibility; others find the pace and the absence of slack stressful, particularly where a stoppage is visible to everyone at once. Which effect dominates depends on how the change is introduced, how much training goes with it, and how people are paid.

**Customers.** Output made to order can mean more choice and less obsolete stock to clear at a discount, but a customer who wants something today may have to wait for it. That suits some markets and not others.

### Which approach suits which business

There is no general answer, but there is a usable test: compare the holding cost that JIT would save with the cost of the stoppages it would cause, and ask which of the two the business can influence.

JIT tends to suit a business with suppliers that are near and dependable, demand that is steady or well forecast, inventory that is valuable to carry or quick to go out of date, and a process flexible enough to run small batches. A Windhoek assembler buying from a plant in Gauteng on a daily overnight run is in a very different position from one waiting six weeks for a container from Asia.

JIC tends to suit a business with long or unreliable supply lines, demand that jumps about, inventory that is cheap and durable enough to be held without much loss, or a very high cost of stopping - a mine that loses a day of output, a pharmacy that cannot be out of a medicine.

Most businesses sit between the two and decide item by item rather than for the whole store: JIT for the bulky, predictable, locally supplied materials, and a reserve for the small, critical, imported parts that stop everything when they are missing. The judgement moves when the facts move. A new supplier close by, a port upgrade, or a run of dependable deliveries pushes a business towards JIT; a border dispute, a currency shock, or one expensive stoppage pushes it back.

# 2.3 Management

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Describe the four traditional functions of management - planning, organising, directing and controlling - and explain how they depend on each other.
- Explain how Fayol and Mintzberg each describe the role of a manager, and what each account is good for.
- Analyse the part managers play in business performance, and the limits on crediting a result to the manager alone.
- Define and distinguish the autocratic, democratic, laissez-faire and paternalistic management styles, and evaluate which of them suits a given situation.
- Explain McGregor’s Theory X and Theory Y as sets of assumptions, and analyse how those assumptions shape the way a manager manages.

---

## Management: functions, roles, styles and assumptions

### What management is

Management is the activity of getting a business’s objectives achieved through the work of other people. A manager is judged on what a department produces, not on what the manager personally produces, and that is the whole difference between managing and doing.

The syllabus divides the activity into four functions: planning, organising, directing and controlling. They are four purposes rather than four jobs, and a single working hour usually serves more than one of them.

### The four traditional functions

**Planning** is deciding what the business is trying to achieve over a stated period and how it will get there: setting objectives, choosing between courses of action, and committing resources and a timescale to the course chosen. A plan that names no figure and no date leaves nothing definite to check against later.

**Organising** is arranging people, tasks, authority and resources so the plan can be carried out. It settles who does what, who reports to whom, what equipment and money each part of the work is given, and which decisions are delegated and which are kept.

**Directing** - older accounts call it commanding, and many people call it leading - is the day-to-day work of instructing, guiding and motivating staff so the tasks in the plan are actually carried out. Briefing a shift, settling a dispute between two sections, explaining why a target has changed: that is directing.

**Controlling** is comparing what actually happened with what the plan said should happen, and acting on the difference. Two halves, and the second is the one learners leave out. A weekly output report that nobody acts on is measurement, not control.

### The functions are a loop, not a list

Set out as four words they look like four stages that happen in order and then stop. They work as a loop. What controlling reveals becomes an input to the next round of planning: a shortfall found in March is the reason the June target is set differently, or the reason a second machine is bought.

They also depend on each other in sequence, and the dependence is where most of the analysis in this part of the syllabus lives. An objective written as “improve output” rather than “raise output to 52 000 crates a month by 30 June” gives the controlling stage nothing definite to compare actual results against, so a weakness at the planning stage shows up months later as an inability to say whether the business is on track. Organising that leaves nobody clearly responsible for a task has the same effect on directing: the instruction is given, and each of two people assumes the other will act on it.

### Etosha Bottling: one quarter, four functions

Etosha Bottling fills soft drinks in Otjiwarongo. A new supermarket contract means output must rise from 40 000 crates a month to 52 000 by the end of June.

*Planning.* The owner sets the objective as 52 000 crates a month by 30 June, and chooses between adding a second shift and installing a faster filling line. The second shift is chosen because it can start in three weeks, while the line would take four months to install and commission.

*Organising.* Twelve staff are recruited for the evening shift and a shift supervisor is appointed. The storeroom is re-keyed so the evening shift can draw materials without the day supervisor, and the authority to stop the line for a fault is given to the shift supervisor rather than kept by the owner.

*Directing.* The supervisor briefs the shift each evening, explains why the contract matters to the business, and settles the first fortnight’s arguments about who cleans the filler.

*Controlling.* Output is counted weekly against a target of 13 000 crates. Week four comes in at 11 200 crates, which is 1 800 short. The owner investigates, finds the evening shift is losing forty minutes a night to a changeover it has not been trained on, arranges the training, and revises the June target to 50 000 crates while the shift settles.

Notice what the control step did. It did not simply record a number. It produced a cause, an action and a changed plan, which is the loop closing.

### Fayol: management as five functions

Henri Fayol, a French mining engineer who ran a large mining and metals firm, set out what he took to be the content of a manager’s job in any organisation: **forecasting and planning, organising, commanding, coordinating and controlling**.

Four of the five are the traditional functions under different names. The fifth, **coordinating**, is the one worth holding onto, because the traditional four do not name it separately: it is the work of making the separate parts of the business act in step, so that the packing section is ready at the moment the filling section finishes.

Fayol’s account is *prescriptive*. It says what a manager ought to be doing, and it was drawn from his own experience of running a firm rather than from watching managers at work. That is both its strength and the source of its main weakness.

### Mintzberg: management as ten roles

Henry Mintzberg went the other way. He observed managers through their working days, described what they were actually doing, and grouped it into ten roles.

**Interpersonal roles**, which come from the manager’s position and the people it puts them in front of:

- *Figurehead* - representing the business at a supplier’s opening or a long-service presentation.
- *Leader* - hiring, training, motivating and judging the people in the department.
- *Liaison* - keeping contacts outside the immediate chain of command, the people a manager telephones for a favour.

**Informational roles**, which follow from those contacts:

- *Monitor* - gathering information about what is happening inside and outside the business.
- *Disseminator* - passing information down and across to the people who need it.
- *Spokesperson* - giving information out on the business’s behalf.

**Decisional roles**:

- *Entrepreneur* - starting improvements and changes rather than waiting for them.
- *Disturbance handler* - dealing with what nobody planned for: a breakdown, a resignation, a complaint that has grown.
- *Resource allocator* - deciding who gets the money, the equipment and the manager’s own time.
- *Negotiator* - bargaining with suppliers, customers, staff or their representatives.

What Mintzberg found alongside the roles matters as much as the roles themselves. Managerial work was fragmented and largely reactive: many short activities, frequent interruptions, and a great deal of it done by talking rather than by writing or analysing. The tidy sequence of functions was not what a day looked like.

### What each account is good for

The two are not rival answers to one question. They answer different questions.

Fayol’s functions describe the **purposes** a manager’s work serves. Mintzberg’s roles describe the **forms** the work takes while it is being done. A manager who spends an hour settling an argument between two shifts is in the disturbance-handler role, and the purpose that hour serves is directing. Both descriptions of the hour are correct.

Each has a use and a weakness. A list of functions can be written into a job description and used to ask whether a purpose is being neglected - a manager who plans and controls but never coordinates has a gap the list will find. Its weakness is that it makes the job look orderly and deliberate, which tends to mislead a new manager about what the week will feel like. The roles describe the week accurately and explain why so little of a day goes on planning, but they are harder to turn into a statement of what a manager should do next, because a description of what managers do is not a statement of what they ought to do.

### A Wednesday morning at a Windhoek hardware branch

The branch manager’s morning, in order. At 07:40 she reads the overnight sales figures and the warehouse’s stock-out list - the *monitor* role. At 08:05 she tells the two counter staff which lines are short so they can offer substitutes - *disseminator*. At 08:20 a delivery arrives two pallets light and she spends twenty-five minutes on the telephone agreeing a partial credit - *negotiator*, and *disturbance handler* at the same time. At 09:00 a customer complains about a paint mix; she handles it herself in front of the staff - *figurehead* and *leader* together. At 09:30 she decides that the one spare trolley jack goes to goods-in rather than to the yard - *resource allocator*. At 09:45 she telephones a manager at another branch to ask how they cut queue times at the cutting bench - *liaison*, and the start of the *entrepreneur* role if she acts on what she hears.

Two hours, seven roles, nothing lasting more than half an hour, and not one minute that would be recognised as planning. That is the observation Mintzberg’s account is built on. It does not mean she is managing badly. It means the functions describe why the morning mattered, and the roles describe what it consisted of.

### The part managers play in business performance

A warning before the substance. The syllabus phrase here is “the contribution of managers to business performance”, and *contribution* is being used in its everyday sense - the part managers play in producing the result. It is not the costing term met in topic 5.4, and the formula of selling price minus variable cost does not apply to it. Where the everyday sense is meant, it is safer to write *the part managers play* and keep the other word for the calculation.

Managers affect performance through five routes, and naming the route is what turns an assertion into analysis.

**Direction.** Objectives tell people which work counts. Effort spent on work that serves no objective is effort the business has paid for and not used.

**Coordination.** Matching what one part of the business does to what another needs stops resources standing idle: stock waiting for a machine, a machine waiting for staff, staff waiting for materials.

**Motivation and retention.** How staff are managed affects whether they stay, how hard they work, and how much of what they know they are willing to use.

**Resource allocation.** Money, equipment and the manager’s own attention are scarce, and deciding which use gets them is a decision only management can take.

**Control.** A problem found in week four costs less to put right than the same problem found at the year end, because there is still time to act on it.

The part managers play is visible in figures rather than impressions: labour turnover, absenteeism, output per worker, cost per unit, the proportion of orders delivered on time, customer retention, and whether the objectives that were set were met.

### One chain, written out in full

Analysis means carrying an effect through to something measurable, so it is worth having one chain written out.

A manager changes the shift roster so that staff know their hours a month ahead instead of a week. Staff can then arrange childcare and transport, which removes the reason most of them gave for leaving. Labour turnover falls. Fewer replacements have to be recruited and trained, which cuts recruitment spending directly. The staff who remain are more experienced, so the defect rate and the time taken per unit tend to fall, which lowers cost per unit. A lower cost per unit raises the profit earned on each sale at the same price, and a settled workforce is one the business can promise delivery dates on - which serves the objective of holding the supermarket contract.

Every link has a reason attached to it. That is the difference between a chain and a leap.

### Okahandja: putting a figure on it

A furniture workshop in Okahandja employs 50 people. Labour turnover ran at 34% a year. After the roster change described above it settled at 18%.

Turnover of 34% on 50 staff means 17 people leaving and being replaced in a year. At 18% it is 9. That is 8 fewer replacements. The workshop reckons each replacement costs about N$6 500 by the time advertising, the owner’s time interviewing, and six weeks of below-normal output during training have been counted, so the saving is 8 x N$6 500 = N$52 000 a year.

Two things are worth noticing about that figure. It is money the business keeps without selling another chair, and it comes entirely from a management decision that cost nothing to make. And it is probably an understatement, because it counts only the cost of replacing people and not the value of what the eight who would otherwise have left already knew about the work.

### The limits of crediting a result to the manager

Three things limit how much of a business’s performance can be credited to its managers.

*External conditions the managers do not control.* A drought that cuts the maize crop, a fall in the Namibian dollar that raises the price of imported components, a competitor opening across the road: any of these may move a business’s results further in a year than good management would.

*The joint nature of the output.* A department’s result is produced by its manager, its staff, its equipment and the market it sells into together, and there is no clean way to separate out one manager’s share. That is why one year’s figures for one department are weak evidence about the manager taken alone.

*The lag.* Several of the routes above - training, retention, reorganising how work flows - take months to reach the figures, so a manager may be judged on results that were largely set before they arrived, and may leave before their own decisions show up.

None of this makes management irrelevant. It makes the evidence needed to judge a manager more demanding than a single number: a run of periods, a comparison with other departments facing the same external conditions, and indicators the manager plainly does control, such as labour turnover and whether agreed objectives were met.

### Management style

Management style is the way a manager takes decisions and deals with the people they manage - chiefly how much say those people have in a decision, and how closely their work is directed once the decision has been taken.

Style is not personality, and it is not the four functions. A manager of any style plans, organises, directs and controls; style is *how* those things are done.

### The four styles and the dimension they differ on

The syllabus names four styles, and they differ mainly along one dimension: how much of the decision the manager keeps.

- **Autocratic** - the manager keeps the decision and issues it as an instruction.
- **Paternalistic** - the manager keeps the decision, but explains it, and weighs what they judge to be good for the staff.
- **Democratic** - the manager shares the decision, consulting staff and letting their views change the outcome.
- **Laissez-faire** - the manager agrees the objective and hands the method over entirely.

A second dimension runs across the first: how much personal concern the manager shows for the individual. That is what separates paternalistic from autocratic, since both keep the decision.

Two consequences follow. The styles are points on a range rather than four separate boxes, so a manager who consults about the holiday rota and decides alone about fire procedure is matching the style to the decision rather than being inconsistent. And which style suits a situation depends on four things: how urgent the decision is, how skilled and experienced the staff are, how serious the consequences of a wrong decision would be, and what the manager believes about the people they manage.

### Autocratic management

**Autocratic management** is a style in which the manager takes decisions alone and passes them down as instructions, with little or no consultation and with communication running mostly one way.

*Where it works, and why.* Three conditions favour it. When a decision has to be made faster than a discussion can be held - a fire, a machine fault, a customer emergency - one person deciding is quicker than a group agreeing. When staff are new or unskilled, they may have little to add to the decision and need clear instruction to do the job at all. And when the consequences of a wrong decision are severe - handling chemicals, working at height, food hygiene - a manager may reasonably refuse to put the method to a vote.

*Where it costs.* Staff who are not consulted have no way of putting what they know into the decision, and the person who runs the machine usually knows something the manager does not. Being told rather than asked tends to lower the sense of being valued; where that happens, motivation may fall, absenteeism and labour turnover may rise, and the business pays to recruit and train replacements. The manager also becomes a bottleneck, because nothing needing a decision moves while they are away. And staff who do not take decisions do not learn to take them, so the business has fewer people ready to promote.

### Democratic management

**Democratic management** is a style in which the manager consults the people affected and lets their views influence the decision, with communication running both ways.

Consultation is not the same as a vote. In most businesses the manager still takes the decision and still answers for it. What makes the style democratic is that staff views genuinely change the outcome rather than being collected and filed.

*Where it works, and why.* Two mechanisms do the work. The first is information: staff who do the job hold knowledge the manager does not, so on questions about how work is done, consulting them tends to produce a better decision. The second is commitment: people carry out a decision they helped shape with more willingness than one handed to them, so it is implemented as intended rather than followed to the letter and no further. Consulting staff also develops them, which gives the business a pool of people who can be promoted.

*Where it costs.* It is slow, and a decision that has to be taken this afternoon cannot wait for a meeting. It depends on staff knowing enough about the question; consulting people who do not may produce a worse decision than the manager would have taken alone. And it raises an expectation, so staff consulted on most decisions may resent the one taken without them, even where urgency made consultation impractical.

### Laissez-faire management

**Laissez-faire management** is a style in which the manager agrees the objective and then leaves staff to decide for themselves how to achieve it, intervening little.

The distinction that matters most is between laissez-faire and neglect. Laissez-faire is a deliberate handing over of the method by a manager who has set an objective, agreed a deadline and provided resources. A manager who has done none of those and is simply absent is not practising a style.

*Where it works, and why.* It suits skilled, self-motivated specialists whose work a manager could not direct in detail anyway - a research chemist, an architect, a software developer, a designer. Given room, such staff may try approaches the manager would not have thought of, which is why creative and research work is often organised this way. It also signals trust, and people trusted with the method tend to take ownership of the result.

*Where it costs.* Without agreed objectives and check-points, work can drift for months before anyone notices, and by then the deadline may be beyond recovery. Coordination suffers, because people choosing their own methods separately may make choices that do not fit together. And staff who want guidance - the inexperienced, or anyone new to the task - can be left floundering, which is the opposite of the freedom the style intends.

### Paternalistic management

**Paternalistic management** is a style in which the manager takes the decision but explains the reasoning behind it, and takes the welfare and interests of staff into account in making it - acting, as the word suggests, like a parent deciding for a family.

Consultation may happen. What does not happen is a transfer of the decision: the manager listens, weighs what they judge to be good for the staff, and then decides.

*Where it works, and why.* Explaining a decision rather than announcing it makes the decision easier to carry out, because staff who understand the reason can apply it to cases the instruction did not cover. Visible concern for welfare - a transport allowance, flexibility over a family emergency, taking the time to explain a redundancy in person - tends to build loyalty, and staff who stay longer keep their experience inside the business. It suits a workforce that is young or inexperienced, needs direction, and responds badly to being ordered.

*Where it costs.* The staff still have no real say, and skilled or experienced people may find that harder to accept than plain autocracy, because the style invites them to feel consulted while leaving the decision where it was. It depends on the manager judging correctly what is good for the staff, and a benefit nobody wanted is still money spent. And it can create dependence: staff accustomed to having decisions made in their interest may not develop the habit of taking decisions themselves.

### Paternalistic against autocratic, and against democratic

Paternalistic is the style most often mixed up, and it gets mixed up in two different directions.

**Against autocratic.** Both keep the decision with the manager, so the difference is not who decides. It is two other things: the paternalistic manager explains the reason, and weighs what is good for the staff as part of making the decision. An autocratic manager may do neither and still be managing perfectly autocratically.

**Against democratic.** Both may involve talking to staff, so the difference is not whether a conversation happens. It is whether staff views change the outcome. A democratic manager gives staff influence over the decision; a paternalistic manager gives them consideration without influence.

Put the two comparisons together and the boundary is clear. Paternalistic sits between the other two: it keeps the decision like an autocrat and takes an interest like a democrat.

### Choosing a style

Asked which style is best, the useful answer is the one that names what decides it.

**Urgency.** The less time there is, the further the balance tilts towards the manager deciding alone.

**The skill and experience of the staff.** The more they know about the work, the more the business loses by not asking them.

**The consequences of being wrong.** Where a mistake would be dangerous or very expensive, a manager may keep the decision even with skilled staff.

**What the manager believes about the people they manage.** Which is the subject of the next section.

Two further points sharpen a judgement. The style has to fit the decision rather than the whole business: the same manager may sensibly decide alone about fire procedure and consult about the holiday rota. And changing style has a cost of its own. Staff used to being told take time to start contributing when they are suddenly consulted, and a manager who announces that the business is now democratic and then overrules the first decision the staff take has produced something worse than either style, because the consultation is now known to be for show.

### McGregor: two sets of assumptions

Douglas McGregor’s Theory X and Theory Y are not two types of worker. They are two sets of **assumptions a manager holds about people**, and McGregor’s argument is that the assumptions shape how the manager manages, whether or not the manager has ever stated them.

**Theory X assumptions.** The average person dislikes work and avoids it where possible. People therefore have to be directed, closely supervised and pushed by the threat of penalty before they will put in effort. Most prefer to be told what to do, avoid responsibility, have little ambition, and want security above everything else.

**Theory Y assumptions.** Effort at work is as natural as rest or play. People will direct and control themselves in pursuit of objectives they are committed to, and that commitment comes from the satisfaction of achieving something rather than from being supervised. Under the right conditions people seek responsibility rather than avoid it. Imagination and ingenuity are widely spread in a workforce, and in most organisations a good part of what people can do goes unused.

The word *assumptions* is the one to hold onto. McGregor was not claiming to have discovered what people are really like. He was pointing out that a manager acts on a theory about people whether or not they know they hold one.

### Why the assumptions tend to confirm themselves

The mechanism is the part worth being able to write out, and it runs in both directions.

A manager holding Theory X assumptions supervises closely, leaves no discretion, checks everything and ties effort to penalties. Staff in that position have no opportunity to show initiative, so they show none. There is no reward for offering an idea, so ideas stop being offered. People who are watched closely tend to do exactly what is asked and nothing more. The manager then observes staff doing the minimum and taking no responsibility, and reads it as proof that the assumptions were right. The behaviour was produced by the management rather than discovered by it.

The same loop runs the other way. A manager holding Theory Y assumptions delegates a real decision, so staff get the chance to exercise judgement. Judgement exercised successfully builds both the staff’s confidence and the manager’s trust, so more is delegated, and over time the staff come to look like the people the assumptions described.

In both directions it is a tendency and not a certainty. Some staff given responsibility do not want it and do not use it well, and a manager who delegates a decision to someone without the knowledge to take it has not applied Theory Y - they have lost control of the decision.

### How the assumptions relate to the four styles

The link is one of tendency, not of definition. Theory X assumptions push a manager towards autocratic practice - close direction, decisions kept, obedience expected - and can equally produce a paternalistic style, where the manager still keeps the decision but believes staff must be looked after rather than driven. Theory Y assumptions push towards democratic practice, and towards laissez-faire where the staff are skilled enough for it.

It is a tendency because the situation intervenes. A manager with thoroughly Theory Y assumptions who is running an evacuation gives orders and does not consult, and is not abandoning the assumptions in doing so. Style responds to the situation; the assumptions are what a manager falls back on when the situation leaves a choice.

### What Theory X and Theory Y do not settle

Two limitations are worth holding on to. The framework describes assumptions rather than evidence: it does not establish what people are actually like, and a manager may hold Theory Y assumptions about a workforce those assumptions do not fit.

And Theory Y is not automatically the better set to hold. McGregor argued that it fitted what was then known about motivation better than Theory X did, but applying it where staff are inexperienced, the work is safety-critical, or the deadline is immediate may produce worse results than direction would. Which set of assumptions serves a business better depends on the work and on the people doing it, which is why the sensible exam answer treats the pair as a lens on a manager’s behaviour rather than as a recommendation.

### Common errors

**“Laissez-faire means the manager does nothing.”** A laissez-faire manager agrees the objective, sets the deadline and provides the resources, then leaves the method to the staff. A manager who has not done those things is absent, not laissez-faire.

**“Theory X and Theory Y are two types of worker.”** They are two sets of assumptions a manager holds about workers. The point of the framework is that the manager’s assumptions shape the staff’s behaviour, which is the reverse of the error.

**“Democratic means the staff vote.”** In most businesses the manager still takes the decision and still answers for it. What makes the style democratic is that staff views genuinely influence the outcome.

**“Paternalistic is autocratic with a smile.”** Both keep the decision, but the paternalistic manager explains the reasoning and weighs staff welfare in making it, and those two differences change how the decision is received and how well it is carried out.

**“Contribution here means selling price minus variable cost.”** In topic 2.3 the word means the part managers play in the result. The costing formula belongs to topic 5.4 and does not apply here.

### Where this connects

Management style is where this topic meets motivation in 2.2: the mechanisms by which consultation, delegation and recognition affect effort are set out there, and a style is largely a decision about how much of each to use. Employee participation in management is 2.2.4, and it is the democratic style seen from the workforce’s side.

The performance indicators used in this topic are defined elsewhere: labour turnover is measured in 2.1.2, and the implications of high and low turnover are set out there too, so a chain that ends in turnover can be continued into that topic’s figures. Training and development in 2.1.6 is one of the conditions that makes a laissez-faire or democratic style workable, because both depend on staff knowing enough to be given the decision. Cooperation between management and workforce is 2.1.7.

Behind all of it, the objectives that planning starts from belong to topic 1, which is where a business decides what it is trying to do before management decides how to get there.

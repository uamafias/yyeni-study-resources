# 4.1 The nature of operations

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain how a business uses the four factors of production, set out the stages of the transformational process from inputs to outputs, and explain how operations contributes to added value.
- Explain why efficiency, effectiveness, productivity and sustainability matter to an operation, distinguish efficiency from effectiveness, calculate and interpret labour productivity, and analyse the impact on a business of measures taken to improve the sustainability of its operations.
- Analyse the benefits and limitations of capital intensive operations and of labour intensive operations, and evaluate which suits a given business.
- Explain the differences between job, batch, flow and mass customisation production, analyse the advantages and disadvantages of each, and evaluate the problems a business faces in changing from one method to another.

---

## Operations: factors of production, the transformational process and added value

### Factors of production

The factors of production are the four types of resource a business combines in order to make goods or provide services: land, labour, capital and enterprise.

The point of the list is that production rarely rests on one resource alone. A bakery with flour and no oven produces nothing, and so does a bakery with an oven and nobody to run it. Operations is the job of putting the four together in workable proportions.

### What each factor does in an operation

**Land** means the natural resources the operation draws on: the site it occupies, the water it uses, and the minerals, crops, timber or fish it takes from nature. For a Namibian fishing company at Walvis Bay, land is the quota of hake in the sea and the quayside the vessels tie up at.

**Labour** means the physical and mental effort supplied by the people the business employs. What that effort is worth to the operation depends on skill, training and motivation as much as on the number of people, which is why two plants with the same headcount can produce very different quantities.

**Capital** means the man-made assets used to produce other goods and services - machinery, buildings, vehicles, tools and equipment - together with the money committed to acquiring them. Capital is itself produced: a filleting machine is the output of somebody else's operation and the input to this one.

**Enterprise** means the act of bringing the other three together and bearing the risk that the venture loses money. It is supplied by the entrepreneur, or by managers acting for the owners. Enterprise is the factor that decides how much of the other three to use, and it is the one that is not paid a fixed rate for its work.

### The mix is a decision, not a given

The proportions in which a business combines the four factors are a management decision rather than a fixed recipe. Two businesses making a similar product may use very different mixes. A Windhoek workshop may make forty steel gates a month with twelve welders and simple equipment; a fabricator in the same street may make the same forty with three operators and a programmed cutting machine.

The mix also shifts over time. Where one factor becomes scarcer or dearer, a business may substitute another factor for it - more machinery in place of costly labour, or more labour where equipment is expensive to buy and maintain - provided the technology of the process allows one to do the work of the other. That proviso matters. A machine can replace a pair of hands on a cutting table; it substitutes far less easily for the judgement of a nurse or the eye of a furniture restorer.

### The transformational process

The transformational process is the sequence by which an operation converts inputs into outputs that are worth more to a customer than the same inputs were worth separately.

That last phrase is the whole reason the process exists. Leather, thread and a buckle lying in a store room are worth what they cost. Assembled into a sandal somebody wants, they are worth more. Everything operations does sits between those two states.

### Inputs, transformation, outputs

The process runs in three stages.

**Inputs.** The four factors of production, together with bought-in materials and components, information - orders, specifications, forecasts - and, in many services, the customer. A passenger on a bus and a patient in a clinic are inputs to those operations in a way that a bag of cement is not.

**Transformation.** The work done on the inputs. It may change the physical form of a material, as milling changes maize into meal. It may move something to where it is wanted, which is what a haulage business sells. It may hold it until it is wanted, which is what cold storage sells. Or it may change a condition or an ownership: a clinic transforms the state of a patient, a retailer transforms who owns the goods. A service operation often transforms the customer, the customer's information or the customer's possessions rather than a material of its own.

**Outputs.** The goods or services the business sells - and also by-products, scrap and waste. Waste is an output, and it is one that carries costs of its own: disposal, reworking, or the value of material bought and not sold. An operation that reports only its saleable output is describing half of what comes out of it.

### Measuring and feeding back

A process that is not measured cannot be corrected. The operation is controlled by measuring what comes out against the standard set for it - quantity, quality, time taken, cost - and feeding that result back, so that the inputs used or the steps of the transformation itself can be adjusted.

A brickworks that finds one batch in twenty cracking can respond at either end: change an input, by drying the clay longer, or change the transformation, by lowering the kiln temperature. The measurement is what makes either response possible.

### Worked example: Namib Sands Brick Works

Namib Sands is a small brickworks outside Okahandja employing fourteen people.

*Inputs*: the clay pit it holds rights over and the water it is licensed to draw (land); fourteen employees, of whom two are trained kiln operators (labour); a press, a kiln, a loader and the yard buildings (capital); the owner, who decided to buy the second kiln on borrowed money and carries the risk if the housing market slows (enterprise); plus cement and sand bought in, and the week's order book (information).

*Transformation*: the clay is dug, mixed with sand and water, pressed into moulds, dried in the yard and fired in the kiln. The change is physical - a wet mixture becomes a hard block - and it is irreversible, which is why the measurement at the end matters so much.

*Outputs*: about 40 000 bricks a week that meet the standard and are sold; several hundred that crack in firing and are crushed for hardcore; and the kiln's ash and flue gases. The cracked bricks used the same clay, the same labour and the same fuel as the sound ones, so they carry their full cost and earn almost none of it back.

### Added value

Added value is the difference between the price at which a product is sold and the cost of the bought-in materials and components used to make it.

It measures what the operation itself put in. Everything between the material arriving and the product leaving - the cutting, the assembly, the checking, the design that made it worth choosing - is what added value counts.

### Calculating added value

Added value per unit = selling price per unit - cost of bought-in materials and components per unit.

Total added value for a period = added value per unit x units sold in that period.

Both are amounts of money and are written in the currency of the business, here Namibian dollars. Two points of care. The cost subtracted is the cost of **bought-in materials and components only** - not wages, not power, not rent. And the figure is per unit sold, so a period's total uses units sold rather than units made.

### Worked calculation: Okahandja Leatherworks

Okahandja Leatherworks sells a pair of sandals for N$260. The leather, soles, buckles and thread in each pair cost N$95. It sells 400 pairs in a month. Its wages for the month are N$38 000 and its rent, power, delivery and other costs come to N$20 000.

Added value per pair = N$260 - N$95 = N$165.

Total added value for the month = N$165 x 400 = N$66 000.

What that N$66 000 has to do: N$66 000 - N$38 000 = N$28 000 left after wages, then N$28 000 - N$20 000 = N$8 000 of profit.

So the operation added N$165 to every pair, and kept N$20 of it once everything else was paid. Reading the first figure as the second is the mistake this calculation exists to prevent.

### How operations raises added value

Operations works on added value from two directions at once, and the formula shows why: the gap widens if the price rises or if the bought-in cost falls.

Upwards, by making the output worth more to the buyer. Better design, more reliable quality, faster delivery, a finish or a service the alternatives do not offer. A tannery that dyes and finishes its hides rather than selling them raw sells the same skin for more.

Downwards, by lowering what is paid for bought-in inputs. Buying in larger quantities or on better terms, cutting the material lost as offcuts, and reducing the units that have to be remade. Cutting the scrap rate on leather from eight per cent to four per cent takes money straight out of the subtracted term while the price is untouched.

### Common errors

**"Added value is profit."** It is not. Added value is the amount left to cover wages, power, rent, marketing, finance and every other cost the business carries, and only what remains after all of those have been met is profit. At Okahandja Leatherworks the added value was N$165 a pair and the profit N$20 a pair.

**"Added value means subtracting all the costs."** Only the bought-in materials and components are subtracted. Wages are part of what creates the added value, not a deduction from it.

**"Contribution means selling price minus variable cost."** It does in the costs topic. In this topic the word is used in its ordinary sense - the part operations plays in creating added value - and carries no formula. If a question asks about the contribution of operations to added value, it is asking what operations does, not for a calculation.

### Connections

The four factors of production appear again in topic 1.1, where the same list describes what any business needs in order to operate at all. Added value connects forward to pricing and to costs: the added value a product carries is what the rest of the business has to live on, so a product with a thin gap between price and bought-in cost has to sell in volume to be worth making.

---

## Efficiency, effectiveness, productivity and sustainability

### Four tests of the same operation

Efficiency, effectiveness, productivity and sustainability are four separate tests of the same operation, and they ask four different questions.

**Efficiency**: how little resource does it use for the output it produces?

**Effectiveness**: does it achieve the objectives that were set for it?

**Productivity**: how much output does each unit of input yield?

**Sustainability**: can it be carried on into the long term?

They can move in opposite directions, which is the reason for using more than one. Running a bottling line faster raises output per employee while it may also raise the scrap rate, so productivity improves and efficiency worsens at the same time. A business that judges operations on a single measure can miss the cost appearing on the others. Managers use the four together because each answers a question the others leave open, and the weight given to each depends on the objectives set for the period: a business fighting for survival weights cost, one bidding for a supply contract may weight sustainability.

### Efficiency

Efficiency is the extent to which an operation produces its output with the minimum of resources, so that as little as possible is wasted.

### Effectiveness

Effectiveness is the extent to which an operation achieves the objectives that have been set for it, whatever quantity of resources it uses in doing so.

### Telling the two apart

Efficiency asks about the ratio of output to the resources consumed. Effectiveness asks whether the intended result was reached. They are different questions, and the four combinations are all real.

A clinic that sees ninety patients a day at a low cost per patient, and sends most of them away without the right treatment, is efficient and ineffective. A clinic that treats everybody correctly by keeping three times the staff it needs is effective and inefficient. The target is to be both, and the common failure is to improve one while quietly damaging the other.

One common measure of efficiency is average cost per unit:

Average cost per unit = total cost of a period / output of that period, in currency per unit.

Ondangwa Bakery spends N$48 000 in a week to bake 12 000 loaves: N$48 000 / 12 000 = N$4.00 a loaf. After the oven is re-sequenced it spends N$50 400 to bake 14 000 loaves: N$50 400 / 14 000 = N$3.60 a loaf. Total cost went up and efficiency improved, which is the whole point of measuring the ratio and not the total.

A fall in average cost only indicates greater efficiency where quality and the mix of products are unchanged. A bakery that reaches N$3.60 by using cheaper flour and selling a worse loaf has changed the product, not the efficiency of making it.

### Productivity

Productivity is output per unit of input over a stated period. It is a ratio, so it is reported as output per employee, per labour hour or per machine hour, and not as a total.

Production is the total quantity an operation produces; productivity is that quantity divided by the input used to produce it. The two move apart more often than learners expect. A factory that adds a night shift raises production. If the night shift produces less per worker than the day shift, production has risen and productivity has fallen in the same week.

### Measuring labour productivity

**Labour productivity = total output in a period / number of employees in that period.**

Output is counted in whatever unit the operation produces - loaves, cabinets, passenger journeys, claims processed. Employees is the number employed in that period. The result is measured in units of output per employee per period, and the period has to be stated: 120 cabinets per employee means nothing until it says per month.

Where employees work unequal hours, a headcount misleads, and the better measure is:

**Labour productivity = total output / total labour hours worked**, giving output per labour hour.

A related figure turns productivity into money:

**Labour cost per unit = total labour cost of the period / output of that period**, in currency per unit. It falls as labour productivity rises, so long as the wage bill does not rise in the same proportion.

### Worked calculation: Rundu Cabinet Works

Rundu Cabinet Works employs 18 people. In a four-week month they produce 2 160 cabinets. The wage bill for the month is N$126 000. Each employee works 160 hours in the month.

*Labour productivity* = 2 160 / 18 = 120 cabinets per employee per month.

*Per labour hour*: total hours = 18 x 160 = 2 880 hours, so 2 160 / 2 880 = 0.75 cabinets per labour hour.

*Labour cost per cabinet* = N$126 000 / 2 160 = N$58.33.

The firm then buys a second panel saw and retrains the two operators. The next month the same 18 people, on the same wage bill, produce 2 520 cabinets.

*New labour productivity* = 2 520 / 18 = 140 cabinets per employee per month, a rise of 20 per employee, which is 20 / 120 = 16.7%.

*New labour cost per cabinet* = N$126 000 / 2 520 = N$50.00, a fall of N$8.33 on every cabinet.

The extra output is 2 520 - 2 160 = 360 cabinets, produced for no extra wages at all, which is why the cost per cabinet fell.

### Reading a productivity figure

140 cabinets per employee per month means nothing on its own. A productivity figure is read against something: the same operation's earlier figures, the target set for it, or another business producing comparable output by comparable methods. Rundu's 140 is informative because last month was 120.

A rise in productivity lowers the cost of that input per unit of output, provided the price paid for the input has not risen by as much or more. Had the retraining come with a 16.7% pay rise, the wage bill would have risen in the same proportion as output and labour cost per cabinet would have been unchanged at N$58.33. The saving came from holding the wage bill still, not from the extra cabinets by themselves.

There is a second condition, and it is the one most often missed. Higher productivity turns into a lower total cost only where the extra output can be sold, or where the input can be reduced in step with it. If Rundu can sell only 2 160 cabinets, the extra 360 sit in a store room as unsold inventory, having consumed timber and hardware, and the business is worse off rather than better. The productivity figure has still risen. The benefit has not arrived.

### What labour productivity does not tell you

Labour productivity counts quantity and not quality. Cabinets later reworked, scrapped or returned are still in the output figure, so an operation can raise measured productivity by working faster and less carefully.

The figure is also raised by better machinery rather than by harder work. Rundu's employees did not become a sixth more capable; a saw was bought. Treating the rise as evidence about the workforce would be reading it wrongly.

A headcount that treats part-time and seasonal staff as whole employees understates the labour actually used, which is why output per labour hour is the safer measure in an operation with shift or seasonal working. And in many services the output itself is hard to count: the number of patients a nurse sees is a poor measure of the nursing done.

### Raising productivity

Productivity can be raised by training, so that the same hour produces more; by better or better-maintained equipment; by improving the layout and sequence of the process so that less time is spent moving materials and waiting for the next stage; and by changes to pay, job design and supervision that raise motivation.

The four are not alternatives to choose between. Training a workforce on badly laid-out equipment raises output less than training it on equipment that has been rearranged, and a productivity bonus paid where the process itself is the constraint frustrates the people paid it.

### Sustainability of operations

Sustainability of operations means running the operation so that it can be carried on into the long term: using natural resources no faster than they are replaced, and keeping the environmental and social costs it imposes within limits it can go on meeting.

The test is whether the operation could still run on the same basis in twenty years. A fishery taking more hake each year than the stock replaces fails that test however profitable this season looks.

### Three fronts

Sustainability of an operation is usually examined on three fronts.

**Environmental**: energy, water, materials, waste and emissions.

**Social**: safety, pay and conditions, and the effect on the communities around the site.

**Economic**: whether the operation earns enough to keep itself going, because an operation that closes is not sustained either.

Common measures include cutting the energy and water used per unit, replacing non-renewable inputs with renewable ones, recycling and re-using materials, reducing scrap and reworking, designing products to last longer or to be repaired, and sourcing inputs closer to the point of use. In a country where water is the binding constraint over much of the territory, water used per unit is often the measure that matters most.

### Analysis: how a sustainability measure reaches the accounts

Start from the condition: a measure that removes a genuine quantity of a purchased input, in a business that goes on operating long enough to collect the saving.

A laundry installs solar water heating. The mechanism is simple - water heated by the sun is water not heated by purchased power - so the monthly power bill falls. That saving repeats every month the equipment runs, so it compounds where the first outlay does not. The measurable consequence is a lower cost per kilogram washed, which either widens the margin at the current price or allows the laundry to quote lower against a competitor still paying the full power bill.

The counter-effect runs first, though, and it runs through cash. The panels are paid for before any saving arrives, staff lose part of a week to the installation, and the business may borrow to fund it. So profit and cash are likely to worsen before they improve, and the chain reaches a better position only if the business can hold out until the saving accumulates past the outlay.

### Worked calculation: payback on a sustainability measure

Swakopmund Laundry uses electric heaters to raise its wash water. Solar water heating for the building costs N$180 000 installed and is expected to cut the monthly power bill by N$4 500.

Payback period = outlay / saving each period = N$180 000 / 4 500 = 40 months, which is three years and four months.

The measure is worth making if the laundry expects to be in that building, on that equipment, for appreciably longer than forty months, and if it can find N$180 000 now without straining the cash it needs for wages and supplies. Both conditions belong to the decision, and neither is in the arithmetic. A payback of forty months on equipment with a fifteen-year life is a different proposition from the same forty months on a five-year lease.

### Judging a sustainability measure

The case in favour is rarely only environmental. Improved sustainability may widen the market a business can sell into, because some retail chains, exporters and public bodies set environmental conditions on the suppliers they buy from, and it may help recruitment and retention where employees place a value on it. A Namibian processor that wants shelf space in a European supermarket may find the certification is the price of entry.

The case against is the cash and sometimes the unit cost. Most measures require capital spending, retraining and a period of disruption before any saving appears. And certified, recycled or locally sourced inputs sometimes cost more per unit than the inputs they replace, so a measure can raise the cost of every unit made rather than lower it. That is a different shape of problem from an outlay: an outlay is paid once, a higher input price is paid for as long as the policy lasts.

What decides it is the size and durability of the saving set against the outlay, whether the business can finance that outlay without straining its cash, and whether its own customers and regulators place a value on the change. Where the saving is real and repeating and the payback is short relative to the life of the equipment, the measure is likely to be worth making. Where the whole case rests on customers valuing it, the business needs evidence that they do before it commits, because a preference reported in a survey is not the same as a price paid at the till.

### Common errors

**Inverting the formula.** Labour productivity is output divided by employees. Dividing employees by output gives a figure that falls when the operation improves, and it is the commonest error on this calculation.

**Reporting total output as productivity.** 2 520 cabinets is production. 140 cabinets per employee per month is productivity. A question asking for productivity is asking for the ratio.

**Treating a productivity rise as a cost saving in itself.** It becomes one where the extra output is sold or the input is reduced. Without either, the business has made more of something and paid the same for it.

**Confusing efficiency with effectiveness.** Doing the thing cheaply is not the same as doing the thing that was wanted.

### Connections

Productivity connects to motivation and to workforce planning: training, job design and pay all appear in this calculation through the output term. Efficiency connects to costs, where average cost per unit is the same figure met again. Sustainability connects to business objectives and to external influences, since a good deal of what a business does about it is a response to regulation, to buyers or to the risk that an input becomes scarce.

---

## Capital intensive and labour intensive operations

### The two descriptions

A **capital intensive** operation is one in which machinery and equipment do most of the work, so that capital costs form the larger share of total cost and relatively few employees are needed for the output produced.

A **labour intensive** operation is one in which people do most of the work, so that labour costs form the larger share of total cost and relatively little capital equipment is used for the output produced.

The words describe a proportion, not a category. The test is which factor carries the larger share of cost, so the same industry can hold operations at both ends: a bottling plant filling 15 000 crates a month and a craft brewery filling 600 by hand are both breweries.

### What capital intensive operation buys

**Uniform output.** Machinery repeats the same action to the same tolerance for as long as it is maintained, so a capital intensive operation tends to produce more uniform output, with fewer defects and less reworking, than one that depends on people repeating the same action by hand. Where a customer buys on consistency - a supermarket taking a weekly pallet to a fixed specification - this is often the decisive benefit rather than the cost one.

**Lower cost per unit, at volume.** Where volume is high and steady, a capital intensive operation tends to have the lower cost per unit, because the heavy fixed cost of the equipment is spread over a large number of units and little labour time is used on each one. The condition in that sentence is load-bearing: at low volumes the same fixed cost raises average cost sharply, which is why the benefit reverses in a slack year.

**Availability and speed.** Equipment can be run for long or continuous hours and its output raised quickly once it is installed, which suits demand that is large and predictable. It also reduces the disruption an operation suffers from absence or industrial action, since fewer people are needed to keep it running.

### What capital intensive operation costs

**The outlay comes first.** The money is committed before any of the output is sold, and it then becomes a cost that must be covered whatever level of output is achieved. A business that borrows to install a line and then meets weaker demand than it forecast carries the repayments regardless.

**Inflexibility.** Altering the specification usually means re-tooling or reprogramming, which takes time and money. A breakdown stops a whole line rather than one worker's station, so maintenance becomes a critical activity rather than a routine one, and skilled maintenance staff may be scarce or expensive locally.

**Loss of value.** Equipment loses value both through wear and through newer models coming onto the market, so a business can be left running a line that still works while competitors run cheaper ones.

### What labour intensive operation buys

**A smaller entry cost.** The initial outlay is smaller, so the operation can be started with less finance, and its scale can be raised or lowered without committing or stranding large sums of capital. For a new business without security to offer, this is often not a preference but the only route open to it.

**Flexibility.** People can be moved between tasks and re-instructed within a day, so a labour intensive operation handles varied, customised or irregular work more readily than equipment that has been set up for one specification. A workshop taking forty different gate designs a month is doing something a programmed line would struggle with.

**Value that comes from people.** Where the value of a product rests on craft, judgement or personal contact with the customer - a tailored suit, a guided tour, a consultation - labour is the factor that creates that value, and equipment substitutes for it only in part.

### What labour intensive operation costs

**Cost per unit at volume.** Labour cost per unit tends to be higher at large volumes, because each additional unit takes roughly the same amount of paid time as the last, where a machine's cost is spread more thinly the more it makes.

**Exposure to wages.** Costs rise directly whenever wage rates rise, whether through negotiation, minimum wage changes or competition for skilled staff, and there is little in the operation to absorb the increase.

**Variation.** Output varies with absence, turnover, fatigue and individual skill, so uniform quality is harder to hold and harder to promise. Recruitment and training are continuing costs, and the knowledge of how the work is done leaves with the person who had it.

### Worked example: Katima Mulilo Juice

Katima Mulilo Juice fills bottles by hand with 20 workers paid N$5 500 a month each. An automated filling line would cost N$2 400 000 installed and need 4 operators on the same pay.

Labour cost now = 20 x N$5 500 = N$110 000 a month. With the line = 4 x N$5 500 = N$22 000 a month. Monthly saving on wages = N$110 000 - N$22 000 = N$88 000.

On wages alone, N$2 400 000 / 88 000 = 27.3 months to recover the outlay - a little over two years, before any allowance for power, maintenance and the interest on the money.

Whether that is a good move depends on facts the arithmetic does not hold. If the plant runs near its capacity every month, the case is strong. If demand is seasonal and the line stands idle for a quarter of the year, the N$2 400 000 is being carried by nine months of output, and the sixteen people who would be released are the same people whose wages are the town's income.

### Choosing the mix

The choice is a matter of degree rather than of kind: most operations mix the two, and the sensible mix depends on the volume and variety of the output, the relative cost of labour and equipment where the business operates, and the finance it can raise.

Volume and variety usually decide it. High volume of a standard specification favours capital; low volume of varied specifications favours labour. Relative prices then modify the answer: where labour is plentiful and equipment has to be imported, paid for in a foreign currency and serviced from far away, the volume at which capital becomes the cheaper route is higher than it would be elsewhere.

The strongest argument for going capital intensive even at modest volume is consistency, because a customer who needs a specification met every time may not be reachable by hand at all. The argument against is that the commitment is hard to reverse: if demand falls, wages can be reduced by releasing staff, but the equipment has to be paid for either way. So the judgement turns on how confident the business is in the volume, and it changes if the demand is seasonal, if the finance is borrowed on short terms, or if the product specification is still changing.

### Connections

This choice is the factor mix of section 4.1.1 made concrete, and it reappears in the production methods of section 4.1.4: flow production is normally capital intensive and job production normally labour intensive, though the two pairs of terms are not synonyms. It also connects to costs, because the capital intensive route converts what would have been a variable labour cost into a fixed one.

---

## Methods of production and the problems of changing method

### The four methods

**Job production** is making one item, or one complete order, at a time to a customer's own requirements, and finishing it before the next is begun. A wedding cake, a bridge, a bespoke shopfitting.

**Batch production** is making identical items in groups, with the whole group completing one stage of the process before it moves to the next, and the equipment reset between one group and the next. A bakery making 600 brown loaves, then cleaning down and making 400 white.

**Flow production** is the continuous movement of identical items through a fixed sequence of stages, each stage adding something to every item, with output coming off the end for as long as the line runs. Bottling, canning, vehicle assembly.

**Mass customisation** is the use of flow methods to produce items that differ from one another in specified ways, achieved by assembling standard modules in different combinations or by leaving the varying work to a late stage of the line. A vehicle built to order on a moving line; a paint mixed to a chosen shade from standard bases at the point of sale.

### The dimensions they differ on

The methods are compared along the same dimensions: the volume of output, the variety of specification allowed, the cost per unit, the skill and flexibility asked of the workforce, the capital equipment required, and how quickly the operation can be switched to something different.

Read as a sequence from job to flow, volume rises, variety falls, cost per unit falls, the capital needed rises, and the breadth of skill asked of any one worker narrows. Mass customisation is the attempt to break that trade-off at one point: to hold flow volumes and flow costs while giving the buyer some of the variety job production offers.

### Advantages and disadvantages of each method

**Job.** Allows any specification the customer asks for and can command a higher price for it. The work is whole and varied, which suits skilled, motivated employees. Against that, cost per unit is high, because skilled time and equipment are devoted to a single item; total output is low; and quoting is difficult because no two jobs cost the same.

**Batch.** Spreads each set-up over a whole group, so cost per unit is lower than job production while some variety is kept - a real advantage where demand comes in distinct product lines. The price is the time lost setting up at every change of group, and the part-finished stock that waits between stages, tying up money and storage space. Scheduling batches around one shared machine is the recurring management problem.

**Flow.** Gives the lowest cost per unit at high volume and a very uniform product, and it can be largely automated. Against that, it requires a large capital outlay, allows little variety once installed, and a stoppage at any one point halts the whole line. The work is repetitive, so motivation and quality of working life need active attention.

**Mass customisation.** Offers buyers a choice of specification without the unit cost of job production, which can win business a standard product cannot. It requires the product to be designed as modules and a system able to track which variant belongs to which order; the number of variants that can be offered is limited by what that system can handle, and an error in tracking produces a finished item nobody ordered.

### Choosing a method

Two facts usually settle the choice: how much of the product is wanted, and how far the units differ from one another. A business selling 200 identical crates of juice a month is not a candidate for a flow line, whatever the unit cost on paper, because the line would stand idle. A business selling 15 000 identical crates is wasting money making them in batches.

Finance is the third fact. A method that is cheaper per unit but needs N$3 000 000 up front is not available to a business that cannot raise N$3 000 000, so the theoretically best method and the reachable one are often different.

### The problems of changing method

**Capital committed before anything is earned.** A change of method usually requires new equipment and a new layout, so the business spends, and often borrows, before the new method has produced anything to sell.

**Lost output during the change.** The old arrangement is taken out while the new one is installed and tested, so the business has to build up finished stock beforehand or accept that some orders are late or lost. Customers lost during a changeover may not return.

**Retraining and resistance.** The skills the operation needs change with the method, so staff have to be retrained. A move towards flow methods narrows many jobs to one repeated task, which some employees experience as a loss of skill and interest, and that may raise labour turnover and weaken motivation.

**Fewer people, and the cost of that.** A change of method usually changes the number of people required, so the business may face redundancy payments, statutory consultation with employees or their representatives, and a spell of poor industrial relations while the change is negotiated. Exact legal requirements for notice, consultation and compensation depend on the jurisdiction.

**A slow start.** Output per employee on a new method usually starts below the level it will eventually reach, because operators and supervisors are still learning the process, so unit costs are higher and defects more frequent in the first months of running.

### Analysis: why a change to flow raises risk

Start from the condition: the change is financed by committing capital that has to be paid for whether the line runs or not.

A move towards flow production raises the share of total cost that is fixed. Wages that used to rise and fall with the order book are replaced by equipment that costs the same at 5 000 units as at 15 000. The mechanism is straightforward: the same capital now has to be covered from whatever volume actually appears. So if the forecast volume does not materialise, cost per unit rises sharply rather than gently, and the business reaches a loss at a level of demand that would have been survivable before.

There is a second pathway, and it works on revenue rather than cost. A move from job or batch towards flow narrows the range of specifications the business can offer, so customers who bought it for that flexibility may go elsewhere. The volume the investment was justified on is exactly the volume the change can undermine, which is why the two effects are worth tracing together rather than separately.

### Worked example: Otjiwarongo Bottling

Otjiwarongo Bottling fills 9 000 crates a month in batches, using 18 employees paid N$6 000 a month each. A flow line would cost N$3 200 000, need 11 employees and fill 15 000 crates a month. Redundancy terms for the seven employees released would be N$18 000 each.

Output per employee now = 9 000 / 18 = 500 crates a month. On the line = 15 000 / 11 = 1 364 crates a month.

Wage bill now = 18 x N$6 000 = N$108 000, so labour cost per crate = N$108 000 / 9 000 = N$12.00. On the line = 11 x N$6 000 = N$66 000, so N$66 000 / 15 000 = N$4.40 a crate.

Redundancy cost = 7 x N$18 000 = N$126 000, payable at once and on top of the N$3 200 000.

The saving of N$7.60 a crate is real only if the extra 6 000 crates a month can be sold. If demand stays at 9 000, the line produces them for N$66 000 / 9 000 = N$7.33 a crate in labour - still lower - but the N$3 200 000 is then being carried by 9 000 crates a month instead of 15 000, and the case that justified the spending has not happened.

### Judging whether to change

A change of method is worth making where the volume that justifies it is secure, and it is worth delaying where it is not. The decisive criterion is the security of the forecast demand, not the unit cost the new method achieves on paper, because the unit cost is a function of that demand.

The strongest argument for moving early is that a competitor who moves first reaches the lower cost first and can hold a price the business cannot match, so waiting has a cost of its own. That argument carries most weight in a market where buyers choose on price and least where they choose on specification.

The problems are reduced where the change is phased: one line converted and proved first, employees consulted early, and the existing method kept running until the new one reaches its planned output. Phasing costs money and delays the saving, so it is an insurance premium rather than a free improvement. On balance, a business with volatile or seasonal demand and borrowed finance should phase; one with a signed long-term order at a known volume has bought the certainty that makes the full change reasonable.

### Connections

Production methods and the capital-labour choice of section 4.1.3 describe the same decision from two angles, and both feed the cost structure of the business: moving towards flow converts variable labour cost into fixed capital cost. The problems of changing method also connect to managing change and to workforce planning, since retraining, consultation and redundancy are the human side of the same decision.

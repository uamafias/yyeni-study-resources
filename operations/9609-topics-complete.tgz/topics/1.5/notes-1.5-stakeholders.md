# 1.5 Stakeholders in a business

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Identify the individuals and groups with an interest in a business, explain the difference between internal and external stakeholders, and explain the roles, rights and responsibilities that stakeholders carry.
- Analyse how business decisions affect stakeholders and how stakeholders react, how stakeholder aims shape business decisions, how and why a business is accountable to its stakeholders, how conflict arises between stakeholders with different aims, and evaluate how a change of business objective affects them.

---

## Who has a stake, and what each side owes

### What a stakeholder is

A stakeholder is any individual or group with an interest in the activities of a business: affected by what the business does, able to affect what it does, or both.

The word carrying the meaning is *interest*. An interest is something a person or group stands to gain or lose because of what the business does. A cashier at Katutura Tailors has an interest, because her wage and her job depend on the shop trading. A household next to the kiln at Namib Clay Bricks has an interest, because the dust settles on its washing. Neither owns any part of the business, and both are stakeholders.

Because interest is measured by what is at stake, stakeholders are not equally involved. The strength of an interest depends on how much of a person's income, custom, amenity or capital rests on the business - not on how strongly that person feels. A supplier selling a tenth of its output to one customer has a much smaller stake in that customer than a supplier selling nine tenths of its output to the same firm.

### Who the stakeholders usually are

Eight parties appear in almost every business, and they are worth being able to name without pausing: the owners or shareholders, the managers, the employees, the customers, the suppliers, the providers of finance, the government, and the local community in which the business operates.

The list is a prompt, not a ranking. A particular business may deal with others - a trade union, an industry regulator, a franchisor - and may find that one on the list matters little to it. A mine in the Erongo region deals with a regulator and a surrounding community every week; a one-person tailoring shop in Windhoek may deal with neither from one year to the next. Naming the parties is the start of an answer. What each of them gets from the business, and what it can do about it, is the answer itself.

### Stakeholder is not another word for shareholder

A shareholder owns part of a limited company. That ownership gives a financial interest in the company's results, so a shareholder is one kind of stakeholder. A stakeholder, though, need not own any part of the business at all: the customer, the supplier and the neighbour are stakeholders on the strength of what they stand to gain or lose, not on the strength of what they own.

The distinction matters because the two words point at different rights. Ownership carries rights set out in company law - to vote at a general meeting, to receive the accounts, to share in any dividend declared. A stakeholder who owns nothing has rights where a contract or a law creates them, and otherwise has expectations rather than entitlements. Writing "stakeholder" when the argument turns on ownership drops the part of the answer that was doing the work.

### Internal and external stakeholders

Internal stakeholders form part of the organisation itself: its owners, its managers and its employees. External stakeholders sit outside it but are affected by it or can affect it - its customers, its suppliers, the providers of its finance, the government and the local community.

The line is drawn by membership of the organisation, not by how much is at stake. That is the point most often got wrong. A family living beside a quarry is external, and may have far more riding on the quarry's next decision than a shareholder holding a hundred shares out of a million. External does not mean minor.

One person can stand on both sides at once. A depot supervisor at Omaruru Dairies who holds shares under a staff scheme is internal as an employee and an owner as a shareholder, and the positions can pull against each other: closing her depot may protect the dividend she receives and end the job she does.

Membership also shapes how each side finds out and how it responds. Internal stakeholders are usually closer to a decision and hear of it sooner, so they can push back while it is still being made. External stakeholders more often learn of it afterwards and respond through the market, through a contract or through the law - by taking their custom elsewhere, by changing the terms they offer, or by complaining to a regulator. That is a difference in speed and route, not a difference in how much each is affected.

### Roles: what each stakeholder does

A stakeholder's role is the part it plays in the business's activity. Employees supply labour and skill. Suppliers deliver inputs on agreed terms. Customers buy the output and provide the revenue. Providers of finance advance money and carry the risk of not being repaid. The government sets the rules the business trades under and collects tax from it. The local community hosts the operation and usually provides much of its workforce. Owners put capital in and carry the residual risk: they are paid after everyone else, or not at all.

Setting the roles out this way shows something a list of names does not. Nearly every stakeholder hands the business a resource it cannot run without, and takes something back in return. That exchange is what makes the relationship two-sided, and it is where rights and responsibilities come from.

### Rights and responsibilities

Rights are what a stakeholder is entitled to receive or to do in its dealings with the business. Some are created by law: an employee's entitlement to the wage and conditions set out in employment legislation, a customer's entitlement to goods that match their description, a shareholder's entitlement to vote at a general meeting and to receive the accounts. Others are created by agreement: a supplier's thirty-day payment terms, a distributor's exclusive territory.

Responsibilities are what is expected in return. An employee is expected to work to the terms of the contract and to follow the safety rules. A supplier is expected to deliver to specification and on time. A customer is expected to pay for what is supplied. A shareholder is expected to provide capital and to accept that it is at risk.

The two fit together. One party's right is usually the other party's responsibility: the employee's right to be paid the agreed wage is the employer's responsibility to pay it, and the supplier's right to be paid in thirty days is the buying business's responsibility to settle the invoice. Writing about rights without the matching responsibility describes half a relationship.

Which of these rights can actually be enforced depends on the country the business operates in. Employment law, consumer protection and company law differ between jurisdictions, so a right that can be taken to a court in one country may be a customary expectation in another. An answer that treats the law of one country as though it held everywhere is making a claim it cannot support.

### Worked example: three stakeholders of one haulier

Erongo Transport is a private limited company running twelve trucks between Walvis Bay and Windhoek. Take three of its stakeholders and set the three headings against each.

**Its drivers.** Role: they supply the labour and the licences that move the freight. Rights: the wage, the hours and the rest breaks set out in their contracts and in employment legislation. Responsibilities: driving to the agreed schedule, keeping the vehicle log, and reporting faults before they become breakdowns.

**Its fuel supplier.** Role: it supplies the diesel the fleet runs on, and does so on thirty-day credit. Rights: payment of the invoice within those thirty days, and orders placed with the agreed notice. Responsibilities: delivering the quantity and the grade ordered, on the day agreed.

**The households on the route through Okahandja.** Role: they host the operation, in the sense that the trucks pass their doors. Rights: whatever the noise limits and road-use rules of the district give them. Responsibilities: very few, which is worth noticing. A stakeholder that hands the business no resource has little to withhold, so its route to influence runs through the local authority rather than through a contract.

### Errors that recur

Three errors recur in answers on this section.

The first is treating "stakeholder" and "shareholder" as the same word. They are not, and the argument usually turns on the difference between an owner's entitlements and an affected party's expectations.

The second is deciding internal or external by how much a party cares rather than by whether it belongs to the organisation. The neighbouring household is external however strongly it feels about the dust.

The third is naming a stakeholder group and stopping there. Saying that the government is a stakeholder says nothing until the answer says what the government receives from the business, what it can require of it, and what it can do if the business does not comply.

---

## Decisions, aims, accountability and conflict

### How a decision reaches a stakeholder

Every business decision changes what somebody gets from the business or gives up to it. That is the whole mechanism, and stating it plainly turns a vague question into a workable one: name the decision, name the party, and name the thing that changes for them.

For employees the thing that changes is pay, hours, job security or working conditions. For customers it is price, quality, range or availability. For suppliers it is order volume, specification or payment terms. For owners it is the return on the capital they have put in. For the providers of finance it is the risk of not being repaid. For government it is tax revenue and compliance with the law. For the local community it is jobs, traffic, noise, dust or water.

Okapuka Poultry, a private limited company north of Windhoek, decides to install an automated packing line. Sixty people work in packing; the line needs twenty. That single decision changes job security for forty employees, changes the wage bill for the owners, changes the order pattern for the electrical contractor who will install and maintain the line, and changes household income in the village most of the packers come from. Four parties, four different things changing - and the answer has to say which thing, for which party.

### Analysis: why reactions differ in size

A stakeholder does not react in proportion to how much it dislikes a decision. It reacts in proportion to three things.

**How large the effect is, set against what that party has at stake.** A supplier losing an order worth two per cent of its turnover behaves differently from one losing an order worth forty per cent of it.

**Whether it has an alternative.** A customer in Windhoek who can buy the same bread from three other bakeries can leave at no cost, so dissatisfaction shows up immediately as lost sales. A customer in a settlement with one shop cannot leave, so the same dissatisfaction shows up as complaint and slow erosion of goodwill instead.

**How much influence it can bring to bear.** Influence comes from the business's dependence on that party, from the law, or from the ability to act together with others. One packer at Okapuka Poultry has little influence; forty packers acting through a recognised union have more; a regulator that can suspend the operating licence has more still.

Run the Okapuka decision through those three and the reactions separate out. The forty packers face a loss that is total for them and have no ready alternative employer in the district, so a collective response through their union is likely and the redundancy process is likely to be slow and contested. The electrical contractor gains work and does not push back at all. The village loses forty wages, cannot replace them locally, and can act only through the regional authority or the press, so its response is likely to be public and slow rather than immediate.

### Reactions feed back into the decision

The reason for tracing a reaction is that it comes back to the business. The resources stakeholders supply - labour, inputs, custom, credit and the permission to operate - are the same resources the decision depends on. A decision that saves money directly can cost more than it saves once the reaction is valued.

At Okapuka the direct saving is the wage bill of forty packers. At an average packing wage of N$10 000 a month, that is N$4.8 million a year. Set against it: the redundancy settlements, the output lost while a contested process runs, the risk that the twenty packers who remain work less willingly, and the possibility that the regional authority looks harder at the next planning application. None of those is certain, and none can be read straight off the decision. What can be said is that a wage saving of N$4.8 million a year is not a net gain of N$4.8 million a year until those effects have been priced.

### What each stakeholder wants

Stakeholders arrive with aims of their own, and those aims are fairly stable from one business to the next.

Owners generally want a return on the capital they have put in, as dividends now or as a more valuable business later. Employees want pay, security, decent conditions and a route to promotion. Customers want quality and reliability at a price they think fair. Suppliers want prompt payment and repeat orders they can plan around. Providers of finance want interest and repayment on the dates agreed, and want the risk of default kept low. Government wants tax revenue, employment and compliance with the law. The local community wants jobs and as little nuisance as the operation can manage.

These are tendencies, not rules, and treating them as rules produces thin answers. An owner nearing retirement may want cash out now where a younger one wants the business grown. An employee may value flexible hours above pay. The list is a starting point, not a substitute for reading what the particular parties in the case say they want.

### Analysis: how an aim turns into a decision

An aim on its own changes nothing. It reaches a decision through the pressure the stakeholder can apply, and each party applies a different kind.

An owner's aim reaches the board through the vote at a general meeting and the power to replace directors. An employee's aim reaches it through the willingness to work, and through collective bargaining where a union is recognised. A customer's aim reaches it through the purchase: a customer who stops buying has made an argument no meeting can ignore. A supplier's aim reaches it through the terms it offers, including whether it offers credit at all. A finance provider's aim reaches it through the conditions attached to the money. A government's aim reaches it through regulation, tax and licensing.

It follows that the weight an aim carries tends to track the pressure behind it rather than its merit. That weight tends to rise with how much the business depends on the party, and with how easily that party can act together with others or be replaced. A sole customer taking most of a small manufacturer's output shapes that manufacturer's decisions heavily; a hundred small customers spending the same amount in total shape them much less, because they cannot act together.

Aims enter a decision in one of two ways, and the distinction is useful. Some become objectives the business adopts - a pay settlement it commits to, a service standard it publishes. Others become constraints it works within - an emissions limit it must not exceed, a condition on its borrowing it must not breach. A constraint cannot be traded off against profit in the way an objective can, so identifying which kind an aim has become tells you whether the business still has a choice.

### Worked example: a price decision at Swakop Seafoods

Swakop Seafoods, a private limited company, is deciding whether to raise the price of its frozen hake from N$78 to N$86 a pack. Four sets of aims meet in that decision.

The owners want a better return, so they push for the rise: the margin on each pack widens by N$86 - N$78 = N$8. Their pressure is the vote and the power to replace the managing director.

Customers want value, so they push against it. Their pressure is the purchase. Some buy a cheaper brand instead, and how many do so depends on how close the substitutes are and how visible the shelf price is.

Employees want security. The rise serves that aim where it protects the margin and the wage bill with it, and works against it where volume falls far enough to cut shifts. Their pressure is their willingness to work, which is slow to apply and easy for the board to discount in the short run.

The largest retail customer, taking a third of output, wants shelf prices its shoppers accept - and it has the pressure to back the aim, because losing that account leaves a third of the volume unsold.

The decision that emerges is shaped less by whose aim is most reasonable than by whose pressure is hardest to absorb. Here that is the retail customer's, so the likely outcome is a smaller rise negotiated with that account, or the full rise applied to the independent trade first while the large account is held at the old price for a season.

### Accountability

Accountability means being required to explain and justify decisions to the parties affected by them, and to accept the consequences of those decisions.

There are two halves there, and answers usually drop the second. Explaining is disclosure: publishing the figures, reporting what was done and why. Accepting the consequences is what gives the disclosure force - directors who can be voted out, a licence that can be withdrawn, a contract that can be cancelled, a penalty that can be levied. Disclosure with no consequence attached to it is information, not accountability.

### How a business is held to account

Accountability runs through identifiable channels, and each channel connects the business to a particular party.

To owners: the annual report, the audited financial statements, and the general meeting at which they can question the directors and vote.
To the providers of finance: the accounts, and whatever periodic information the lending agreement asks for.
To customers and suppliers: the contract, published service standards, and the ordinary remedies for breach.
To government: tax returns, regulatory filings, and inspection of premises and records.
To employees: consultation arrangements, and in many businesses a recognised union with bargaining rights.
To the local community: public statements about environmental and social effects, planning consultations, and the attention of the press.

How much of this a business carries depends on how it is owned. A sole trader answers mainly to the parties it has contracted with and to the tax authority. A public limited company additionally reports to its shareholders and to the market under company law, on a timetable it does not set. That is one of the real costs of the ownership form, and it is a fair point to raise when a business is deciding whether to incorporate or to list.

### Why accountability is in the business’s own interest

Part of the answer is simply that it is required. Company law obliges limited companies to file accounts and to report to shareholders, and regulators require returns from businesses in licensed industries. That covers the "must".

The more interesting half is why a business would go beyond the legal minimum. The parties it depends on - employees, customers, lenders, suppliers - commit their labour, custom, credit and goods on the strength of what they can find out about it. Where information is withheld, those parties tend to protect themselves by assuming the worst: asking a higher price, offering shorter payment terms, seeking security over assets, or simply going elsewhere. Accountability lowers that cost by making the business's position checkable, which is why a firm with nothing to hide often discloses more than the law asks.

It also brings disagreement into the open early. A business that tells its employees honestly that the order book is falling is having the argument about hours in month one, when short time is still an option. A business that says nothing is having the same argument in month six, on worse terms and with less trust to spend.

### Where conflict comes from

Conflict between stakeholders is not a failure of goodwill. It follows from arithmetic. A business has finite money and finite capacity, so N$1 of profit paid out as dividend is not available to pay as wages, to fund a price cut, or to reinvest in cleaner equipment. Each of those uses serves a different party, and the same money cannot serve more than one of them.

The conflicts that recur are the ones where that arithmetic bites hardest. Owners wanting larger distributions against employees wanting higher pay. Customers wanting lower prices against owners wanting wider margins. The local community wanting less dust and noise against owners wanting lower costs. Managers wanting the business bigger against owners wanting the return now. Suppliers wanting payment in thirty days against a business wanting to hold its cash for sixty.

A difference in aims is not automatically a conflict, and treating it as one produces weak analysis. Aims conflict where meeting one measurably reduces how far another can be met. Aims are complementary where meeting one helps the other: training that raises product quality serves the customer, raises the employee's earning power, and protects the owner's margin at the same time. Before writing that two parties are in conflict, it is worth checking whether the resource is being divided or enlarged.

### Analysis: what makes a conflict sharp

Three conditions make a conflict hard to manage, and naming them is more useful than listing opposing wishes.

**The trade-off is immediate and the benefit is diffuse.** Spending N$2 million on dust-suppression equipment at a quarry shows up in this year's profit and in this year's dividend, while the gain to the neighbouring households arrives as an absence of dust that nobody can point at. A visible cost set against an invisible benefit is the hardest argument a board has to win.

**The party bearing the cost cannot be compensated.** Where the business can pay for what it takes - overtime for the extra hours, a higher price for the faster delivery - the conflict is a negotiation, and negotiations settle. Where it cannot, because the cost falls on people it has no contract with, the conflict has nowhere to settle and moves instead to the regulator, the local authority or the press.

**The business is under financial pressure.** Meeting two aims at once usually costs more than meeting one. A business with room in its margins can raise pay and hold prices; a business trying to survive has to choose, so conflicts that stayed dormant while trading was good surface together when it is not.

### Changing objectives, and who bears the change

Objectives are not fixed. A new business typically pursues survival first, because it can do little else while cash is tight. Once established it pursues profit, then often growth, and some businesses later add social or environmental objectives. The sequence is typical rather than universal, and a business moves back down it when trading conditions turn.

Each change redirects money, capacity and attention, which is why it moves stakeholders' positions rather than merely the wording in a plan.

**From distributing profit to financing growth.** Profit is retained and reinvested instead of paid out, so owners receive less now in exchange for a larger business later - a trade whose value to them depends on how long they intend to hold the shares, which is why a retiring shareholder and a thirty-year-old one can reasonably disagree about the same decision. Suppliers gain, because output and orders rise. Employees gain promotion opportunities, and face more change, more training and often more work. The providers of finance watch the risk profile, because growth financed by borrowing raises the repayments the business has to meet out of trading that has not happened yet.

**To survival.** The cost concentrates on the parties whose payments the business can cut quickest, because those are the outflows it can actually change in the short run: employees through reduced hours or job losses, and suppliers through delayed payment and smaller orders. Owners lose the distribution too, but they lose it later than employees lose the hours - and that difference in timing is often the whole argument in an evaluation question.

**To an environmental or social objective.** Costs usually rise before revenue does - cleaner equipment, better-paid labour, certified inputs - so owners carry a lower return in the short term while the local community gains sooner. Whether owners are compensated at all turns on two things largely outside the business's control: whether enough customers pay more for the cleaner product, and whether regulation obliges competitors to meet the same standard, which stops the business being undercut for doing it.

The general point to carry into an evaluation is that a change of objective redistributes rather than simply improving or worsening matters. The question worth answering is not whether stakeholders are better or worse off, but which of them bears the change, how large it is for each, and over what period the position reverses.

### Holding the topic together

Four moves cover most of what this topic asks.

Name the party precisely, and say whether it sits inside the organisation or outside it, because that determines how it finds out and how it can respond.

Say what the decision changes for that party - the pay, the price, the order, the return, the amenity - rather than saying it is "affected".

Say what the party can do about it, and why that response has force: the alternative it can move to, the dependence it can exploit, the law it can invoke.

Then say what the response costs the business, and whether it is large enough to change the decision.

Conflict, accountability and changing objectives are the same machinery seen from different angles. Conflict is what happens when two claims meet a resource that cannot cover both. Accountability is the channel through which a party finds out enough to press its claim. A change of objective is a decision to move the resource, which is why it tends to produce both at once.

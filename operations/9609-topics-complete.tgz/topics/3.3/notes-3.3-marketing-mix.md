# 3.3 The marketing mix

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Identify the four elements of the marketing mix and explain what each one covers and why the four are decided together.
- Explain the difference between goods and services, the tangible and intangible attributes of a product, why product development matters, and what product differentiation and a unique selling point are.
- Analyse the stages of the product life cycle and decisions about extension strategies, carry out Boston Matrix analysis and state its uses, and evaluate how product portfolio analysis affects marketing decisions.
- Explain the objectives and usefulness of competitive, penetration, skimming, price discrimination, dynamic, cost-based and psychological pricing, and analyse and evaluate which suits a business in a given situation.
- Explain the objectives and usefulness of different promotion methods - advertising, sales promotion, direct promotion and digital promotion - and the role of packaging and branding in promotion, and analyse and evaluate which methods suit a business.
- Explain the objectives and usefulness of different channels of distribution, and analyse the difference between digital and physical distribution and what each one suits.

---

## The marketing mix: four decisions, taken together

### The marketing mix

The marketing mix is the combination of decisions a business makes about its product, its price, its promotion and the place it is sold through, planned together so that the product reaches its chosen market in a form, at a price, with a message and through an outlet that market accepts.

Because the four words begin with the same letter, the mix is usually called the 4Ps. The letters are a memory aid. What matters is that each P is a decision the business has to take, and that taking one changes what the others can sensibly be.

### What each element covers

**Product.** What is sold: its design, features, quality, range of sizes and variants, packaging, and the service wrapped around it such as a guarantee or installation.

**Price.** The amount charged, and the method used to arrive at it - matching competitors, adding a mark-up to cost, launching low to win share, launching high to recover development spending.

**Promotion.** How the business communicates with its market: advertising, sales promotion, direct contact, digital channels, packaging and branding.

**Place.** The route the product takes to reach the buyer: selling direct, through retailers, through wholesalers, through an agent into an export market, physically or over a network.

### Why the four are decided together

Each element says something to the buyer, and buyers read them together rather than one at a time.

Think of a leather bag made in Windhoek and sold at N$2 400. The price says the bag is not an everyday purchase. If the promotion is a discount flyer and the place is a stall at a weekend market, the buyer receives two contradictory signals and tends to resolve them downwards: the product is probably not worth N$2 400 after all. The mix has undermined the position the business was trying to hold. The same bag sold through a shop in the Old Breweries craft centre, promoted through photographs of the workshop, and priced at N$2 400 tells one story consistently.

This is why a change to one element usually forces a look at the other three. Deciding to sell through supermarkets rather than a single shop changes how much packaging has to do, because nobody is there to explain the product; it usually changes the price, because the retailer takes a margin; and it changes promotion, because the buyer now meets the product on a shelf rather than in conversation.

### The weight of each element is not the same everywhere

The mix is four decisions, but they do not carry equal weight in every market.

A differentiated consumer good in a crowded market - a soft drink, a shampoo, a mobile package - usually leans on promotion and branding, because the physical differences between competing products are small and the difference buyers feel has to be built.

A standard input sold to industrial buyers - cement, steel reinforcing, packaging film - usually turns mainly on price, reliability and delivery, because the buyer is a business comparing quoted prices and lead times rather than a shopper responding to an image.

So the useful question in a case is rarely 'what are the 4Ps here'. It is which of the four is doing the work in this market, and whether the others support it.

### One product, two mixes

Namib Fresh grows tomatoes outside Otjiwarongo. It can sell them in two ways.

Through a supermarket chain: product is a graded, pre-packed 500 g punnet with a barcode; price is negotiated with the chain's buyer and is low for each kilogram because the chain takes its own margin; promotion is essentially the pack and the shelf position; place is the chain's depot, from which the chain distributes.

Direct at a Saturday market: product is loose fruit sold by the bowl, picked the day before; price is higher for each kilogram because no intermediary takes a share; promotion is the stall, the grower's presence and word of mouth; place is one location, open one morning a week.

The product itself is the same tomato. Every other decision differs, because a change of place changed what the product has to be, what it can be priced at, and what promotion is available. That is the mix working as one decision rather than four.

### Common errors

**"The 4Ps are a checklist to work through in order."** They are four decisions that constrain one another. Changing any one of them may require the other three to be revisited, so the order in which they are written down carries no meaning.

**"Place means the shop's address."** Place is the route to the buyer, including the intermediaries who handle the product on the way, not simply where the business is located.

**"Promotion means advertising."** Advertising is one method within promotion. Sales promotion, direct contact, digital channels, packaging and branding all sit inside the same element.

### Where this connects

The segment the mix is aimed at comes from segmentation and targeting in 3.1.6, and the objective it serves comes from marketing objectives in 3.1.1. Each element is opened up in the sections that follow: product in 3.3.2 and 3.3.3, price in 3.3.4, promotion in 3.3.5 and place in 3.3.6. The cost figures that set the floor under a price are in 5.4.

---

## Product: goods, services, attributes, development and difference

### Goods and services

Goods are physical items that can be made in advance, stored, owned and resold. Services are acts performed for a customer, produced at the moment they are used.

A bag of maize meal is a good. A haircut, a bus journey, a night in a lodge and an insurance policy are services.

### Four differences that change the marketing

The distinction is only worth teaching because of what follows from it.

**Intangibility.** A service cannot be inspected before it is bought. A buyer can weigh a bag of maize meal; a buyer cannot weigh a haircut that has not happened yet.

**Perishability.** Capacity not used at the time cannot be kept for later. A lodge bed empty on Tuesday night is revenue that no longer exists on Wednesday, while an unsold bag of maize meal is still there in the morning.

**Inseparability.** The service is produced and consumed at the same moment, so the person or system delivering it is part of what is bought. The driver is part of the taxi ride.

**Variability.** A service is harder to repeat identically, because it runs through people and circumstances. Consistency has to be managed through training, standards and supervision rather than assumed from a production line.

### Why a service business markets differently

Start from intangibility. A buyer who cannot inspect a service before buying it needs some other way of judging it, so the buyer reads whatever is available: the price, the state of the premises, the reputation of the business, the appearance and manner of the staff, online reviews, and what guarantee is offered if the service goes wrong.

That changes what the mix has to do. Those signals are not decoration - they are the only evidence the buyer has, so spending on them is spending on the product itself. A guesthouse in Swakopmund photographing its rooms and answering its reviews is not advertising around the product; it is supplying the inspection the buyer cannot make.

Perishability pushes in a second direction: because unsold capacity earns nothing at all, service businesses commonly discount in quiet periods rather than hold an empty room, which is why off-peak pricing and dynamic pricing are so common in services. The consequence for the business is that revenue depends heavily on how evenly demand is spread across the week and the year.

### Most offerings are a blend

Very few things sold are purely one or the other. A restaurant sells food, which is a good, and the cooking and serving of it, which is a service. A vehicle dealership sells a bakkie alongside a warranty and a servicing plan, and the buyer's decision may turn on the servicing rather than the vehicle.

So the question in a case is not which box the business belongs in. It is how much of what the customer is paying for is the physical item and how much is the act performed, because that is what decides where the marketing effort goes.

### Tangible and intangible attributes

The tangible attributes of a product are the features that can be seen, touched or measured: size, materials, performance, durability and the packaging it comes in.

The intangible attributes are the features a buyer cannot physically examine: brand reputation, the status attached to owning it, after-sales support, a guarantee, and the convenience of buying it.

Note that this is a different cut from goods against services. A physical good has intangible attributes too - a tyre carries a reputation for safety - and a service has tangible ones, such as the vehicle a tour operator uses.

### Why the intangible side is worth paying for

Buyers may pay more for intangible attributes than the physical product alone would earn. Two 750 ml bottles of coffee-grade roasted beans may be near enough identical in the cup, and still sell at N$85 and N$140, because one carries a reputation, a story about where the beans came from, and a shop that will replace a bad bag.

The business reason for investing there is copying speed. A physical feature can be measured by a rival and matched in a production run; a reputation is built out of years of consistent delivery and cannot be bought in a quarter. That is what makes the intangible side of a product a more durable advantage.

The condition attached to that is important and often left out. The premium holds while the tangible performance keeps supporting the reputation. Where the product stops delivering, the reputation decays with it, and a strong name then works against the business, because more buyers had expected more.

A product is bought as a bundle of both kinds of attribute. That is why a decision about one - cheaper materials, a shorter guarantee - changes the value of the bundle even where the other side of it is untouched.

### Product development

Product development is the work of improving an existing product or creating a new one for the business to sell.

It ranges from a small change - a new flavour, a resealable pack, a lighter frame - to a product the business has never made before.

### Why it matters, and what it costs

Products lose appeal as tastes, technology and competitors move. A business that does not develop its products is likely to find revenue falling as its existing products age, with nothing prepared to replace them. Development is how the gap is filled before it opens.

Beyond replacement, development can open a segment the business does not reach today, support a higher price where the improvement is one buyers value, make use of spare capacity in a factory or a kitchen, and reduce how far the business depends on a single product.

The cost side is what makes it a genuine decision rather than an obvious one. Development spending is committed before any revenue arrives from it, and some projects do not reach the market at all. So the money has to come out of the earnings of existing products or from external finance, and the risk is carried by the business rather than shared with the buyer. A small business with one profitable product is choosing between spending that product's earnings on a successor and taking them as profit now.

### Differentiation and the unique selling point

Product differentiation is making a product distinguishable from competing products in ways buyers notice and value, through features, quality, design, service, branding or packaging.

A unique selling point is the single feature or benefit a product has that competing products do not, used as the centre of the message the business puts to the market.

The boundary between them is worth being precise about. Differentiation is the general activity of making a product distinguishable. A unique selling point is one claimable point of difference singled out of it. A product can be differentiated in several small ways - slightly better stitching, a friendlier shop, a wider range of colours - without any one of them being distinctive enough to build a message on.

### What differentiation buys

The commercial point of differentiation is what it does to the business's freedom over price.

Where a product is undifferentiated, the nearest alternative is an equal substitute, so a price rise sends buyers to the rival and costs a great deal of volume. Where differentiation succeeds, the nearest alternative is no longer an equal substitute: switching now means giving something up. A price rise therefore costs less volume than it would otherwise, and the business can hold a premium and earn more for each unit sold.

Two conditions sit on that conclusion, and the chain is wrong without them. The difference has to be one buyers actually value - a feature nobody asked for differentiates the product on paper and not in the market. And rivals must not yet have matched it: differentiation that has been copied has stopped being differentiation, which is why the premium is a temporary position that has to be defended rather than a permanent one.

Differentiation may be real, where the product genuinely differs, or perceived, where the difference is created by branding and promotion. Both can support a premium. The perceived kind is easier for a rival to attack, because the product underneath it is the same, so the argument can be reopened by a rival's own promotion.

### A unique selling point that earns its keep

Etosha Leather makes school shoes in Okahandja and sells them at N$520 a pair against imported shoes at N$340. It offers a written promise to re-sole any pair free of charge within the first school year.

That promise is doing three things. It is a unique selling point, because no importer at N$340 offers it. It is an intangible attribute, because the parent cannot inspect it at the point of sale and is buying a promise. And it is the reason a N$180 price gap is arguable at all: a parent who expects to buy one pair rather than two is comparing N$520 with N$680, not with N$340.

The condition is the one attached to every intangible attribute. The promise supports the price while the shoes genuinely last and the re-soling is genuinely honoured. A single term of returned shoes and slow repairs turns the same promise into the reason the parent does not come back.

### Common errors

**"A service has no tangible attributes."** It usually has several - the vehicle, the premises, the uniform, the printed policy document - and because the service itself cannot be inspected, those tangible things carry more weight than they would for a physical good.

**"Differentiation means being different."** It means being different in a way buyers notice and value. A difference nobody wants is a cost with no return.

**"Every product needs a unique selling point."** Many profitable products have none, and compete on price, availability or service instead. A unique selling point is one route to a premium, not an entry requirement.

**"Product development means inventing something new."** Most of it is improvement of what already sells: a new size, a reformulation, a longer guarantee.

### Where this connects

How a product moves through its life, and what is done when sales flatten, is 3.3.3. The price a differentiated product can hold is 3.3.4, and the promotion and branding that create perceived difference are 3.3.5. Whether buyers are consumers or other businesses, which changes how much of the decision rests on intangible attributes, is 3.1.4. Research into what buyers actually value is 3.2.

---

## The life cycle, the Boston Matrix and the portfolio

### The product life cycle

The product life cycle describes the pattern of sales a product is expected to follow over its life, usually set out in five stages: development, introduction, growth, maturity and decline.

Plotted, it is sales on the vertical axis against time on the horizontal: flat and below zero in development, rising slowly at introduction, steeply in growth, flattening in maturity, and falling in decline.

### What happens in each stage

**Development.** No sales at all, spending only - research, design, testing, tooling, trial production. Cash flow is negative and there is nothing yet to set against it.

**Introduction.** Sales are low because few people know the product exists. Promotion spending is heavy for the volume sold, and cost for each unit is high because output is small. A loss at this stage is common. Price is set either high, to recover development spending from early buyers, or low, to win share quickly.

**Growth.** Sales rise quickly as awareness spreads and the product gets into more outlets. Cost for each unit falls as output rises. Competitors notice the growth and enter. Distribution widens and promotion shifts from explaining what the product is to arguing why this one rather than the rival's.

**Maturity.** Sales growth flattens. Almost everyone who is going to buy the product is buying it, so growth for one business now comes from taking share from another, and competition turns to price and promotion. This is usually where profit is highest, because volume is high and development is paid for - and where it is most under pressure.

**Decline.** Sales fall. The business has to decide whether to support the product with an extension strategy, take what cash it still yields while spending nothing further on it, or withdraw it from the market.

### The mix changes as the product moves

The life cycle is worth learning because of what it tells a business to do, and each element of the mix moves with the stage.

**Promotion** moves from informing at introduction, through persuading in growth when rivals have arrived, to reminding in maturity when everyone already knows the product and the job is to stay chosen.

**Price** is usually at its freest at introduction, when the product is new and there may be nothing directly comparable, and comes under the most pressure in maturity, when rivals are selling a near-identical thing and price is one of the few remaining levers.

**Place** widens through growth, because a product selling well earns shelf space that could not be won at launch, and may narrow again in decline as retailers give the space to something else.

**Product** itself is varied in maturity - new sizes, flavours, a restyled pack - to hold interest in something the market has stopped finding new.

The chain to hold on to runs: the stage sets what the buyers of the product still need to be told, which sets what promotion has to do; and the number of rivals sets how much freedom price has. Both consequences land on the same place, which is the contribution each unit earns and therefore the profit the product returns to the business.

### Extension strategies

An extension strategy is an action taken to lengthen the maturity stage of a product and postpone its decline.

The usual actions are: new variants, sizes or flavours; finding new uses for the product; opening new segments or export markets; restyling and repackaging; reducing the price; running a fresh promotion campaign; and selling through a channel the product has not used before.

### When an extension strategy is worth doing

An extension strategy is worth undertaking where the additional contribution it earns exceeds what it costs, and where the change still fits the position the product holds.

Both halves matter. A price reduction that adds volume may add less contribution than it gives away, so the arithmetic has to be done rather than assumed. And an extension that wins volume by cheapening the product can cost more than it earns in a different currency: a premium brand extended into a budget pack has bought this year's sales with next year's price.

The decisive question is usually why sales are falling. Where the fall is a matter of fashion, of tired promotion, or of a market the business has not yet reached, extension can genuinely reverse it. Where the product has been technically replaced - a service that phones now perform, a format buyers have left behind - extension usually postpones decline rather than reversing it, and the same money may do more in a replacement product.

The strongest argument on the other side is that extension is cheap beside development. A new flavour costs a fraction of a new product and uses machinery and distribution the business already has, so even a modest extension of maturity can earn its cost back. That argument holds while the product still has buyers who like it; it fails when the extension is being used to avoid a replacement decision the business has already left late.

### How far the life cycle can be trusted

The life cycle describes a common pattern rather than a law, and three limitations follow.

The length and shape of the curve differ between products and cannot be read off in advance. A fashion item may run its whole cycle in a season; a staple food may sit in maturity for decades. Knowing the shape of the curve does not tell a business where on it a particular product currently is.

Falling sales may be a marketing failure rather than maturity. A product losing share because its promotion is stale is not in decline; it is being out-marketed, and the response is different.

And the model can make itself come true. A business that labels a product as declining, cuts its promotion and gives its shelf space to something else will see sales fall - which it then reads as confirmation. That is why the stage a product is in is a judgement to be tested against sales data and market research, not a label to be applied and then acted on.

### The Boston Matrix

The Boston Matrix classifies the products in a business's portfolio on two measures: the share of the market the product holds relative to its largest competitor, and the rate at which that market is growing.

Relative market share, not absolute share, is the horizontal measure: a product with 20% of a market whose leader holds 50% is in a weak position, while a product with 20% of a market where no rival exceeds 8% is the leader. Market growth rate is the vertical measure, and it is a property of the market rather than of the product.

### The four positions

**Star.** High relative share in a fast-growing market. It earns a great deal and spends a great deal keeping its position while rivals chase the same growth, so it is often close to cash-neutral. It is what a business wants a question mark to become and a cash cow to have been.

**Cash cow.** High relative share in a slow-growing market. The market no longer demands heavy spending to keep up with, and the product's position is established, so it generates more cash than it needs. That surplus is what funds the rest of the portfolio.

**Question mark.** Low relative share in a fast-growing market, sometimes called a problem child. The market is attractive, but the product is not winning it. It absorbs cash, and the business has to decide whether to invest enough to make it a star or stop supporting it.

**Dog.** Low relative share in a slow-growing market. It neither earns nor absorbs much. The textbook answer is to withdraw it; the better answer is to ask what it is doing for the rest of the range first.

### Plotting a real portfolio

Kalahari Beverages sells four products.

Bottled still water: 34% of a market growing at 11% a year; the nearest rival holds 19%. High relative share, fast growth - a star. It earns well and needs heavy promotion to keep the lead while the market attracts entrants.

Traditional cordial: 41% of a market growing at 1% a year; nearest rival 12%. High relative share, slow growth - a cash cow. It pays for everything else.

Energy drink: 6% of a market growing at 23% a year, where the leader holds 38%. Low relative share, fast growth - a question mark. Winning here would be valuable; winning would also be expensive, and the business has to decide whether it can afford to fight a leader six times its size in that market.

Glass-bottled cola: 4% of a market growing at 1%, leader at 44%. Low share, slow growth - a dog. Before withdrawing it, the business should ask whether the shops that stock it take the cordial because of it.

Read as a portfolio, this is reasonably healthy: one product funding the others, one strong product in a growing market, one bet, and one candidate for withdrawal. A portfolio of four question marks would be a financing problem, and a portfolio of four cash cows would be a future problem.

### What the matrix is used for

The matrix is used to judge whether a portfolio is balanced - whether there is something funding the business now and something being prepared to fund it later. It is used to decide where the cash generated by cash cows is directed, which is normally towards stars and towards the question marks the business has chosen to back. It shows how far the business depends on a small number of products. And it informs decisions about which products to support and which to withdraw.

### What the matrix does not tell you

The matrix rests on two measures and leaves others out, so it informs a decision rather than settling one.

Relative market share is not the same as profitability. A product can hold a large share of a market at a margin so thin that it earns less than a small share of a richer one.

The answer changes with how widely the market is defined. Is the traditional cordial competing in cordials, in soft drinks, or in everything drunk with a meal? A narrow definition makes almost any product look dominant, and the business choosing the definition is also the business reading the result.

A product in a weak position may still earn its place. It may complete a range that buyers and retailers expect, or use capacity that has no better use. Withdrawing it can cost sales elsewhere.

And a position is a snapshot. Products move between positions as their markets grow or slow and as their share changes, so the matrix is most useful when the same products are plotted repeatedly and the direction of travel is read alongside the current position. A star sliding towards a question mark and a question mark climbing towards a star sit in different places on this year's chart and tell opposite stories.

### Product portfolio analysis

Product portfolio analysis is the practice of examining all the products a business sells together, rather than judging each one on its own. The Boston Matrix is one tool for doing it; comparing where each product sits in its life cycle is another.

### What it changes about marketing decisions

**Budget allocation.** Looking at the portfolio as a whole changes how a marketing budget is divided, because spending can be directed to the products where it changes the outcome instead of being spread evenly across the range. Spending on a cash cow past the point where it defends the position earns little; the same money behind a question mark may decide whether the business has a product in a growing market at all.

**Timing.** The portfolio shows whether there are products coming through to replace those approaching decline. A business that can see a gap two years out can start development before revenue falls, rather than after - which matters because development takes time that a business in trouble does not have.

**Dependence.** Where a large share of revenue comes from one product or one market, the analysis makes the exposure visible and the business can decide whether to widen the range.

**The mix for each product.** Position shapes the mix. A product with a high share of a slow-growing market is usually supported with reminder advertising and wide availability, while a new product in a fast-growing market usually needs promotion that generates trial and a price set to win share.

### How much weight the analysis should carry

The conclusions depend on the data behind them and on where the boundary of the market is drawn, so a product's portfolio position is evidence to be weighed alongside cost, capacity and strategy rather than an instruction to act.

The decisive factor is usually the quality of the share and growth figures. A business with reliable independent market data can act on the position with some confidence; a business estimating the size of its market from its own sales and a guess is producing a chart that looks like evidence and is not.

Against that, the alternative to portfolio analysis is not perfect information - it is judging products one at a time, which systematically favours whichever product is in front of the manager and hides the question of what happens when the earner ages. Imperfect portfolio analysis usually beats no portfolio view at all, provided the business treats the position as a prompt to investigate rather than as a decision already taken.

### Common errors

**"A dog should always be withdrawn."** The position says the product is not strong and its market is not growing. It does not say what the product does for the range, what the shops that stock it also take, or whether anything better could use the capacity.

**"Market share means the business's share of total sales."** In the Boston Matrix it is share relative to the largest competitor, which is a different number and can point the other way.

**"A product in decline is at the end of its life cycle."** Falling sales are consistent with decline and also with poor marketing, a stock shortage or a temporary competitor offer. The stage is a diagnosis, and it has to be argued for.

**"Extension strategies restart the life cycle."** They lengthen maturity. Sales after a successful extension are usually held rather than returned to their growth-stage rate.

### Where this connects

Market share and market growth, the two measures the matrix uses, are defined and calculated in 3.1.3. The pricing decisions the life cycle stage drives - low to win share at launch, high to recover development spending - are in 3.3.4. Extension through repackaging and fresh promotion runs into 3.3.5. Development spending and the finance for it are in 3.3.2 and in topic 5.

---

## Price: the objectives and usefulness of seven pricing methods

### What a pricing method is

A pricing method is the rule a business uses to arrive at the price it charges for a product.

The seven methods in this syllabus are not seven prices. They are seven different things a business can look at when it decides the number: what rivals charge, what share it wants to win, what the earliest buyers would pay, which group the buyer belongs to, what demand is doing today, what the product costs to make, and how the figure itself reads.

### The floor and the ceiling

Before any method is applied, every price sits between two limits.

The **floor** is cost. Over time the revenue from a product has to cover the costs of supplying it, or the business does not survive selling it. A single order can be taken below full cost where it still covers the costs that order itself causes - that is the special-order argument in 5.4.3 - but the product as a whole cannot be sold below cost indefinitely.

The **ceiling** is what buyers are prepared to pay given the alternatives open to them. It is not what the business would like, and it is not set by the business at all.

Every method chooses a point between the two. Cost-based pricing starts from the floor and works up. Competitive pricing takes its bearing from where rivals have settled in between. Skimming works down from the ceiling. Understanding a method means knowing which of the two limits it takes as its starting point, and therefore which one it is in danger of ignoring.

### What a pricing decision is trying to achieve

A method is chosen to serve an objective, and the same business may hold different objectives for different products at the same time.

To **enter a market and win share**, where being established matters more than early profit. To **recover development spending quickly**, where the product was expensive to create and may be copied. To **defend share against a rival** that has moved on price. To **fill capacity** that would otherwise earn nothing, such as an empty lodge bed midweek. To **signal quality**, where buyers cannot judge the product any other way. Or simply to **cover cost with a margin**, which is what most small businesses are doing most of the time.

Naming the objective first is what makes a pricing answer more than a list of methods. A method is not good or bad; it is suited or unsuited to what the business is trying to do.

### Competitive pricing

Competitive pricing sets the price of a product by reference to what competitors charge - at, just below, or just above the going rate.

Where products are similar and buyers compare prices easily, a price well above the going rate loses volume quickly, so the price is set largely by the market rather than by the business. Competitive pricing accepts that rather than fighting it. A fuel station, a hardware shop stocking the same brands as the shop across the road, or a minibus operator on a route where everyone charges N$25 is in that position.

It helps a business avoid losing volume to a rival on price and avoid starting a price war by accident, and it needs almost no information, which suits a small business that cannot research what buyers would pay.

Its weakness is that it looks outward and not inward. Matching a larger rival's price may mean matching a cost base the business does not have, so the margin left may be too thin to cover its own overheads. And a genuinely differentiated product priced at the going rate gives up the premium its difference could earn - the business has done the work of differentiating and then priced as though it had not.

### Penetration pricing

Penetration pricing sets a low price when a product is launched, in order to build sales volume and market share quickly, with the intention of raising the price once the product is established.

It suits a market where buyers compare on price, where the product is not strongly differentiated, and where the business has the finance to accept a thin margin while volume builds. A new brand of maize meal entering a market held by two established brands is the standard case.

### How penetration pricing is supposed to work

A low launch price lowers the cost to a buyer of trying something unfamiliar, so more people try it. Trial turns into repeat purchase for those who like it, so volume rises. Rising volume gets the product into more outlets, because retailers stock what sells. And higher output lowers cost for each unit, because the fixed costs of the business are spread over more units, which in turn makes the low price easier to sustain and harder for a small rival to match.

The chain holds under two conditions. Demand has to be sensitive to price, or the low price buys little extra volume and simply gives away margin on the units that would have sold anyway. And the business has to be able to supply the volume it creates: a penetration price that produces orders the business cannot fill converts a marketing success into empty shelves and lost retailers.

Three risks follow. The thin margin has to be financed until volume arrives, so a business without cash or an overdraft facility cannot run the strategy to its conclusion. Raising the price later may lose the buyers the low price attracted, because price was the reason they came. And a low launch price can fix the product in buyers' minds as a cheap one, which limits what it can charge afterwards even when the product improves.

### Price skimming

Price skimming sets a high price when a product is launched, aimed at the buyers least sensitive to price, and lowers it in stages as that group is served and competitors appear.

A high launch price earns a large margin on each early sale, so development spending is recovered sooner, and the price itself signals that the product is new and distinctive. As the buyers willing to pay most are served, each reduction opens the product to a further group, so the same product is sold at several prices over its life. New consumer electronics is the familiar example, and so is a new medicine under patent.

Skimming depends on three things: the product being genuinely new or distinctive, a group of buyers who value having it early, and something that delays imitation, such as a patent, scarce know-how or a lead in distribution. Take away the third and rivals arrive at the high margin before the business has finished skimming.

Its risks run the other way from penetration. The high price limits early volume, so cost for each unit stays high and the business does not get the cost advantage that volume brings. A visibly large margin is itself an advertisement to competitors that the market is worth entering. And buyers who paid the launch price may resent a later cut, which damages the relationship the brand depends on - which is why businesses that skim often disguise the reduction as a new model rather than announcing a price cut.

### Penetration and skimming set side by side

The two launch strategies answer the same question in opposite directions, and the choice between them is usually decided by how differentiated the product is and how fast it can be copied.

Penetration takes a low margin on high volume, aims at share, and suits an undifferentiated product entering an established market. Skimming takes a high margin on low volume, aims at early cash, and suits a distinctive product that rivals cannot match immediately.

They also leave opposite problems behind. Penetration has to raise its price later from a base of price-driven buyers. Skimming has to lower its price later without insulting the buyers who paid most. Neither problem disappears; the business chooses which of them it would rather have.

### Price discrimination

Price discrimination is charging different prices to different groups of buyers for the same or a very similar product, where the difference in price is not explained by a difference in the cost of supplying them.

The last clause is what makes it discrimination rather than ordinary costing. Charging more to deliver to Rundu than to deliver within Windhoek is a cost difference. Charging a tourist more than a resident for the same room on the same night is not.

It requires three conditions. The business must be able to identify and separate the groups - by a student card, a residence document, the time of travel, the booking channel. The groups must differ in how sensitive they are to price, or there is nothing to gain by separating them. And buyers in the cheaper group must not be able to resell easily to the dearer one, or the cheap price becomes the only price.

Common bases are the time of use, such as off-peak fares and midweek lodge rates; the identity of the buyer, such as student or pensioner rates; and location, such as separate resident and international rates at a Namibian lodge.

### Why discrimination raises revenue

A minibus route out of Katutura carries commuters in the morning peak and a much thinner midday traffic. Suppose there are 300 peak passengers prepared to pay N$25 and 120 midday passengers prepared to pay no more than N$15.

A single price of N$25 earns 300 x N$25 = N$7 500 and carries nobody at midday. A single price of N$15 carries all 420 and earns 420 x N$15 = N$6 300 - more passengers, less money, because the peak passengers who would have paid N$25 now pay N$15.

Charging N$25 at peak and N$15 off-peak earns N$7 500 + N$1 800 = N$9 300. The business keeps the high price from the buyers who would pay it while still making the sales it would otherwise lose.

The three conditions are all visible in that example. The groups separate themselves by the clock, so no checking is needed. They differ in price sensitivity, because the commuter has to travel and the midday passenger does not. And the cheap seat cannot be resold at peak, because a seat at 11 a.m. is not a seat at 7 a.m.

### The limits on discriminating

Discrimination can be resented where the basis for the difference looks unfair, and resentment is a commercial cost rather than only a moral one: a buyer who discovers the person beside them paid less may not return.

Where a price difference rests on a characteristic that national law protects, it may be unlawful. The precise rules differ between countries, so a business checks the law of the country it trades in before setting prices this way rather than assuming that what is done elsewhere is permitted.

There is also an administrative cost. Separating groups means checking documents, running two price lists, training staff and policing resale, and for a small business that cost can exceed the extra revenue.

### Dynamic pricing

Dynamic pricing changes the price of a product frequently in response to current demand, remaining capacity, the time of purchase or competitors' prices, usually through software that resets the price automatically.

It suits businesses whose prices can be changed cheaply and quickly, which in practice usually means selling online, and whose capacity is fixed and perishable - airline seats, hotel rooms, lodge beds, event tickets, ride-hailing journeys.

When demand is weak the price falls far enough to sell capacity that would otherwise earn nothing, and when demand is strong it rises to capture what buyers are prepared to pay, so the revenue earned from a fixed capacity rises relative to a single posted price. Two conditions sit on that gain: demand has to vary in a way the business can actually observe, and buyers must not simply postpone the purchase until the price falls - if they learn that waiting works, the high prices stop being paid.

The costs are the systems and data it needs, the risk that buyers treat frequent changes as unfair or stop trusting the posted price, and the speed with which competitors can see an online price and match it, which removes the advantage within minutes rather than months.

### Dynamic pricing is not price discrimination

The two overlap and are regularly confused.

Dynamic pricing varies the price with **when** a purchase is made and with the state of demand at that moment. Everybody buying an airline seat on Tuesday morning sees the same price; it is different from Monday's because the remaining seats and the days to departure have changed.

Price discrimination varies the price with **which group** the buyer belongs to. Two people buying at the same moment pay different amounts because one is a student and the other is not.

A lodge can run both at once: a resident rate and an international rate, each of which also moves with how full the lodge is. That is why the distinction has to be made on the basis of the difference, not on the fact that two prices exist.

### Cost-based pricing, and the mark-up trap

Cost-based pricing sets the price from the business's own cost figure plus an addition. The common form is cost-plus pricing:

**Price per unit = cost per unit + (cost per unit x mark-up percentage)**

The cost figure used may be full cost per unit, which covers the whole of the business's spending at an assumed level of output, or variable cost, which is used as a floor when quoting for a one-off order. Full costing and contribution costing are set out in 5.4.2.

Worked example. A workshop in Ondangwa makes steel gates. Materials and labour for each gate are N$640, and the workshop's share of rent, power and administration works out at N$160 a gate at its usual output, so full cost is N$800. At a 35% mark-up:

Mark-up = N$800 x 0.35 = N$280. Price = N$800 + N$280 = N$1 080.

Now the trap. A mark-up is a percentage of **cost**; a margin is the same money expressed as a percentage of the **price**. The N$280 is a 35% mark-up on cost and a 25.9% margin on the N$1 080 price. Take a simpler pair of numbers to fix it: a product costing N$40 sold with a 25% mark-up is priced at N$50, and the N$10 of profit in that price is a 20% margin. A business that sets a price believing it has secured a 35% margin when it has secured a 35% mark-up has quietly overstated what each sale earns.

### What cost-based pricing does and does not do

Cost-based pricing is simple, needs no market research, and gives every sale a margin over the cost figure used. For a small business quoting jobs, that is a genuine advantage: it can be applied consistently by somebody who is not a marketer, and it makes under-pricing by accident much less likely.

Two weaknesses limit it. The first is arithmetic. Cost per unit depends on an assumed level of output, because the fixed costs are divided by that output. Sell fewer units than assumed and the fixed cost carried by each one is higher than the figure used, so part of the fixed costs is left uncovered even though every sale was made at the calculated price. The gate workshop that priced on 400 gates a year and sells 280 has not earned the margin it thought it had.

The second is that the calculation never looks outside the business. It does not ask what buyers would pay or what rivals charge, so it can produce a price above the ceiling, where the product does not sell, or below it, where money is left on the table. That is the same limitation the costing chapter reaches from the other side in 5.4.3, and it is why cost-based pricing is most often used as the floor beneath another method rather than as the whole decision.

### Psychological pricing

Psychological pricing sets a price at a level chosen for how buyers read it rather than for what the arithmetic requires.

It takes two common forms. The first is pricing just below a round figure - N$99.95 rather than N$100, N$1 999 rather than N$2 000 - so the price is read as belonging to a lower band. The second is pricing deliberately high, so that the price itself is taken as a signal of quality where the buyer has no other way of judging it; an unfamiliar wine at N$260 is read as better than the same wine at N$60.

What separates it from the other methods is its reference point. Competitive pricing looks at the rival's price, cost-based pricing at the business's own cost, and psychological pricing at how the buyer interprets the number itself. It is usually applied last, as a final adjustment to a price another method has produced: the gate workshop's N$1 080 becomes N$1 079, or N$1 099.

The money involved in the first form is small - five cents below N$100 - but it applies to every unit sold and costs nothing to adopt, which is why it is so widespread. Its limits are that experienced buyers may see through it, that a price ending in .95 signals a value position which does not suit every product (a private clinic pricing a consultation at N$899.95 looks wrong), and that a high price signals quality for only as long as the product supports the claim.

### Choosing between the methods

How useful a method is depends on how sensitive demand is to price, how differentiated the product is, how many competitors there are and how quickly they can respond, the stage the product has reached in its life cycle, whether the business can separate groups of buyers or change its prices quickly, and what its costs are.

Work through those in order and most cases answer themselves. A distinctive new product with a patent and few rivals invites skimming. An undifferentiated product entering a market where buyers compare prices invites penetration, provided the finance is there. A service with fixed perishable capacity and an online booking system invites dynamic pricing or discrimination by time. A small jobbing workshop with no market data and custom work invites cost-plus.

The judgement that is usually wanted in an examination is not which method is best in the abstract but which fits this business's objective and constraints - and the strongest answers say what would change the recommendation. A penetration recommendation depends on the finance holding; a skimming recommendation depends on imitation being delayed; a cost-plus recommendation depends on the assumed output being achieved.

In practice businesses use more than one method at once and change method over a product's life: a launch price set to win share, a cost figure acting as a floor beneath it, a price that follows competitors once the market has settled, and a psychological adjustment on top. Treating the seven as mutually exclusive is the commonest way to get a pricing answer wrong.

### Common errors

**"Penetration pricing means a permanently low price."** It means a low launch price with the intention of raising it. A business that keeps the price low has chosen a low-price position, which is a different strategy with different economics.

**"Skimming means charging as much as possible."** It means starting high and coming down in planned stages as each group of buyers is served. A single high price that never moves is not skimming.

**"Price discrimination is illegal."** Charging different groups different prices is ordinary commercial practice - student fares, off-peak rates. What may be unlawful is discriminating on a basis a country's law protects, and that depends on the jurisdiction.

**"A 30% mark-up gives a 30% profit margin."** A mark-up is a percentage of cost and a margin is a percentage of price, so the margin works out smaller than the mark-up for the same money.

**"Cost-plus pricing cannot lose money."** It secures a margin over the cost figure used, at the output assumed. Selling fewer units than assumed leaves fixed costs uncovered even though the formula was applied correctly.

### Where this connects

The cost figures that set a floor under any of these methods are in 5.4: full and contribution costing in 5.4.2, cost-plus and special orders in 5.4.3, and break-even in 5.4.4, which shows how many units a chosen price has to sell. Launch pricing is a life-cycle decision, so it connects to 3.3.3. Separating groups of buyers is segmentation, which is 3.1.6. Filling perishable capacity is capacity utilisation, which is 4.3.

---

## Promotion: objectives, methods, packaging and branding

### Promotion

Promotion is the part of the marketing mix that communicates with the market: telling people the product exists, persuading them to buy it, and reminding those who already buy it.

One warning before anything else. In topic 2.2 the same word means moving an employee to a higher position, which is a different idea altogether. Nothing in this section is about staff. Where a case mentions promotion, read which sense the sentence is using before answering.

### What a campaign is trying to achieve

A promotion campaign has an objective, and the method follows from it rather than the other way round.

To **create awareness** at launch, where the problem is that nobody knows the product exists. To **inform** buyers about what the product does, what it costs and where to get it. To **persuade** buyers to choose it rather than a rival, which is the job once the market knows both. To **remind** existing buyers and defend share in maturity, where the product is familiar and the risk is being forgotten. To **support the price position** the business wants to hold, because a premium price that nothing explains is simply a high price. Or to **shift a stated quantity within a stated period**, such as clearing seasonal stock before the end of the quarter.

Objectives of that last kind are the easiest to judge afterwards, because the target is a number. Awareness and brand-building objectives are harder to measure, which does not make them less important but does make the spending harder to defend.

### Above the line and below the line

Above-the-line promotion is paid communication placed in media the business does not control, such as television, radio, press, outdoor sites and paid online advertising. The business buys space or time and takes whatever audience the medium delivers.

Below-the-line promotion is communication the business controls directly, such as sales promotions, direct mail, personal selling, sponsorship and point-of-sale display. There is no independent media owner in between.

The distinction matters for two practical reasons: above-the-line reaches more people for each hour of management effort but is harder to trace to a sale, while below-the-line reaches fewer people and can usually be measured.

Methods are normally combined into a promotional mix, because they do different jobs: advertising builds recognition over months while a sales promotion moves stock this week. A campaign is rarely one method.

### Advertising

Advertising is paid communication of a message about a product through a medium, addressed to many people at once, with the business controlling what the message says.

Informative advertising sets out facts a buyer needs - what the product does, what it costs, where to get it. Persuasive advertising works on preference and image rather than on information. Most campaigns carry some of both: a radio advertisement giving a price and an address is informative, and the voice and music doing the giving are persuasive.

### What advertising buys, and what it costs

Advertising reaches a large number of people for a low cost for each person reached, and repetition builds recognition, which makes later messages cheaper to land because they start from something the audience already knows.

The condition on that is the one most often left out. The low cost for each person reached holds where the audience the medium delivers matches the target market. A national radio campaign for a workshop that serves one town pays for reach it cannot use, so its cost for each person who could actually buy is high even though its cost for each listener is low. Choosing a medium is therefore a question about audience fit before it is a question about price.

Three limitations follow. Advertising is paid for before the result is known, so the business carries the risk. Its effect builds slowly and is hard to separate from other causes - a price change, a rival's supply problem, the weather - so attributing a sales rise to the campaign is rarely clean. And the sums involved put the main media out of reach for a small business. That is why a business measures what it can: recall, enquiries, vouchers returned, sales in the advertised area against sales elsewhere, rather than assuming the spending worked.

### Sales promotion

Sales promotion is a short-term incentive attached to a product to encourage an immediate purchase: a discount, a buy-one-get-one offer, a coupon, a free sample, loyalty points, a competition or a point-of-sale display.

It suits a defined short-term objective: getting trial of a new product, clearing stock before it dates, meeting a target within a quarter, or answering a rival's offer.

### Why the sales figure during an offer flatters it

An incentive lowers the cost, or raises the value, of buying now. Some buyers who were going to buy next month buy this month instead, and some buyers switch from a rival for the period of the offer.

That is the mechanism, and it contains its own warning. Sales measured during the offer overstate what the offer has won, because part of the increase is buying that would have happened later anyway. The honest test is what sales do over the offer period and the month after it together, compared with the same stretch without an offer.

The limitations follow from the same mechanism. The effect largely stops when the offer stops, so the gain is borrowed rather than earned unless the trial converts to repeat purchase. The discount is given on units that would have sold at full price as well as on the extra ones, so the cost is larger than the discount on the incremental sales alone. And repeated offers teach buyers to wait for the next one, which lowers the price the product can hold between offers - the reason a business that promotes every month finds its full price has quietly stopped being the real price.

### Direct promotion

Direct promotion is communication addressed to identified individuals rather than to an audience in general, and asking for a response: addressed mail, email, text messages, telephone calls, catalogues and personal selling.

Because each message goes to a named person whose response can be traced, the business can measure the response rate and the cost of each sale won, which makes direct promotion easier to judge than advertising and easier to improve by testing one version of a message against another.

It suits a high-value product, or a market where the buyers are few and identifiable, which is why it is used heavily where one business sells to another. A firm selling irrigation equipment to 200 commercial farms can name every one of them; a firm selling cooldrink to the public cannot.

Its cost for each person contacted is high beside advertising, poor data wastes the spending on people who have moved or were never buyers, and unsolicited contact may be treated as intrusive and damage the brand it was meant to build. Rules on holding personal data and on contacting people without their consent differ between countries, so a business checks what applies where it trades.

### Digital promotion

Digital promotion is promotion carried through internet-connected channels: the business's own website, search advertising and search optimisation, social media, video platforms, email, mobile apps and messaging, and arrangements with influencers and affiliates.

### What has actually changed

Four developments separate digital promotion from the media that came before it.

**Targeting.** Messages can be aimed by interest, location and past behaviour rather than bought by audience in bulk, so a workshop in Ongwediva can pay to reach people within 30 km of it rather than paying for a national audience.

**Measurement.** Responses are counted, so spending can be tied to clicks, enquiries and sales in a way a billboard never could.

**Two-way communication.** Buyers publish their own view of the product where other buyers see it, so the business no longer controls the whole message about itself. Reviews and comment threads are part of the promotion whether the business takes part or not.

**Low entry cost.** A small business can reach a national audience without a media budget, which is the single largest change for the kind of business most learners will work in.

One design point matters particularly here. Where most people reach the internet on a mobile phone, as they do across much of southern Africa, a campaign designed for a desktop screen reaches the device but not the reader. Digital promotion is therefore built mobile-first and kept light enough to load on a slow connection, or the targeting and the measurement are spent on a page nobody waits for.

### Where digital promotion falls short

Platform rules and ranking systems change without notice, and reach that was free can disappear, so a business that has built its whole audience on one platform holds an asset it does not control.

Negative comment spreads as fast as the message, and a poorly judged post can be circulating for days before the business notices.

A click counted is not a sale made. Digital measurement is precise about the wrong thing unless the business traces through to an order.

And the channel misses buyers who are not online, which in Namibia varies sharply between urban and rural areas and with the cost of mobile data. A campaign that is entirely digital may be excluding exactly the customers a rural retailer depends on, which is why radio remains a serious medium in much of the country.

### Packaging

Packaging is the material a product is contained in. It protects the product, holds a convenient quantity, identifies it, and carries the information the buyer and the law require.

Its promotional work is the identification part, and it is done at the point of sale. On a shelf of alternatives the pack is the last message a buyer sees before choosing, so its colour, shape and name act as a silent advertisement and connect the product to whatever the buyer already knows of the brand. That is why a business that changes a pack design without warning loses sales from regular buyers who cannot find the product they were looking for.

Packaging also differentiates and positions. A resealable pack, a portion size that suits a single household, or a heavier material that feels expensive each change what the product is worth to a buyer without changing what is inside it.

Against that, elaborate packaging adds cost to every unit and adds waste, and buyers and regulators in many countries now weigh that. A business balances the promotional gain against the cost for each unit and against the reaction to the waste it creates - which for some markets has turned into a reason to package less rather than more.

### Branding

A brand is the name, symbol, design and reputation that identify a product as one business's and separate it from competing products.

A recognised brand makes every other piece of promotion work harder, because the message starts from something the buyer already knows rather than from nothing, and it lowers the risk the buyer feels in choosing, because the brand carries a promise that this purchase will be like the last one. For a service, where nothing can be inspected in advance, that promise does a great deal of the selling.

Branding supports a price premium, makes retailers more willing to stock the product because customers ask for it by name, and lowers the cost of launching a related product under the same name - which is why a business with a strong brand extends it rather than starting again.

### What a brand costs to keep

A brand is built slowly and can be damaged quickly by a failure of quality or conduct, because what is broken is the promise the brand carries. The asymmetry is the point: years of consistent delivery build the promise, and one widely reported failure can undo a large part of it, because every buyer who trusted the name now has evidence against it.

A strong brand also attracts imitation - packaging that resembles it, names close enough to be confused with it - which costs money to police.

And its value rests on the product continuing to deliver what the brand claims. Where it stops doing so, the brand speeds up the loss of custom rather than slowing it, because more buyers had expected more. That is the decisive condition on every argument for spending on a brand: branding raises the return on a product that works and raises the cost of one that does not.

### Choosing the promotional mix

Which method is useful depends on what the campaign is for, what the budget is, who the audience is and which media reach it, whether the product is an everyday consumer good or a technical product sold to a few buyers, and whether the result can be measured well enough to judge the spending afterwards.

Take a small manufacturer launching a new pack of dried fruit in Windhoek supermarkets on a budget of N$60 000. Television is out on cost. A sales promotion and in-store sampling attack the immediate problem, which is that nobody has tasted the product. Targeted social media reaches the shoppers who use those supermarkets at a cost the budget can carry. Packaging does the work at the shelf, where the decision is actually made. Direct promotion is the wrong tool, because the buyers are numerous and unidentified.

The decisive criterion there was the objective - trial, not awareness in general - because it is trial that selects sampling and promotion over brand advertising. The strongest argument the other way is that sales promotion buys a short burst and builds nothing, so a business doing only that has to repeat it. The condition on the recommendation is therefore that some of the budget is kept back to convert triallists into repeat buyers, and that the result is measured by sales in the following month rather than by units moved during the sampling week.

### Common errors

**"Promotion means advertising."** Advertising is one method. Sales promotion, direct promotion, digital channels, packaging and branding are all promotion.

**"Promotion in a business case means staff being promoted."** In this topic it means marketing communication. In 2.2 it means an employee moving to a higher position. Read which sense the case is using.

**"A successful promotion is one that increases sales during the campaign."** Sales during an offer include purchases brought forward from later. The test is what happens across the campaign and the period after it.

**"Digital promotion is free."** The entry cost is low, not zero: paid reach, content, and the time to run it all cost, and free reach on a platform can be withdrawn by the platform.

**"Packaging is part of the product, not promotion."** It is both. It protects and contains, which is product, and it identifies and persuades at the shelf, which is promotion.

### Where this connects

Which media reach the target market is a research question, so this section runs on 3.2. Segmentation in 3.1.6 decides who the message is aimed at. Branding and packaging create the perceived differentiation discussed in 3.3.2, and support the premium a differentiated product can charge in 3.3.4. The employee sense of the word promotion is in 2.2.4.

---

## Place: channels of distribution, digital and physical

### A channel of distribution

A channel of distribution is the route a product takes from the producer to the final consumer, together with the businesses that handle it on the way.

Four channel shapes are commonly described:

- Producer direct to consumer - a farm stall, a factory shop, a website selling its own output.
- Producer to retailer to consumer - a bakery supplying a supermarket.
- Producer to wholesaler to retailer to consumer - a food manufacturer reaching hundreds of small shops.
- Producer to an agent or distributor, and then onward through wholesaler and retailer - the usual route into an export market, where the agent supplies the local knowledge and contacts the producer does not have.

### What an intermediary does, and what it costs

An intermediary holds stock, breaks bulk - buying by the pallet and selling by the case - reaches outlets the producer could not serve, and often extends credit to the retailers it supplies. All of that widens the reach of the product.

It is paid for out of the price. Each intermediary takes a margin, so the producer's revenue for each unit falls as the channel lengthens, and the producer also loses some control over the price the buyer sees and over how the product is presented on the shelf.

So the chain runs: adding an intermediary raises the number of outlets the product can reach, which raises volume; and it lowers revenue for each unit and weakens control. Whether the business ends up better off depends on which of those two moves further. A producer whose volume doubles through a wholesaler taking 12% is ahead; a producer whose volume rises slightly through a wholesaler taking 30% is not.

### What channel choice is trying to achieve

Channel choice serves objectives: making the product available where the target market shops, controlling how it is priced and presented, keeping down the cost of each unit delivered, getting the product to the buyer quickly, covering enough of the market, and receiving feedback from the people who sell it.

Distribution intensity is a separate decision on top of the channel shape. **Intensive** distribution places the product in as many outlets as possible and suits everyday goods bought on impulse, such as cooldrink or airtime. **Selective** distribution uses a limited number of outlets chosen for their fit with the product, such as a paint brand sold through trade merchants. **Exclusive** distribution appoints a single outlet or distributor for an area, which protects the brand's position and the dealer's margin at the cost of availability - the usual arrangement for vehicle franchises.

### Choosing a channel

Which channel suits a business turns on the value and perishability of the product, how technical it is and how much explanation it needs, how widely its customers are spread, and how much finance and control the producer has.

A high-value technical product that needs demonstration argues for a short channel and selective or exclusive distribution, because the sale depends on explanation the producer can control. A low-value everyday good argues for length and intensity, because the sale depends on being everywhere the buyer already goes.

Geography is the factor that dominates in Namibia. A producer in Windhoek selling to shops in Oshakati, Katima Mulilo and Luderitz may find a wholesaler covers ground it could not cover itself, and pays a margin for that reach. The decisive criterion is usually the cost of serving a scattered retail base directly against the margin the wholesaler takes: a producer that would need three vehicles and three sales staff to do its own distribution is comparing that whole cost, not only the margin, against what the wholesaler charges.

The strongest argument for going direct anyway is contact. A producer that never meets its retailers learns nothing about why the product is or is not selling, and finds out about a problem only when the wholesaler's order falls. Where a business chooses the wholesaler, the condition on that choice is that it keeps some direct contact with the trade for exactly that reason.

### Digital and physical distribution

Physical distribution moves the product to the buyer as a physical item, through transport, warehousing, stockholding and shops. Digital distribution delivers the product itself electronically over a network.

The distinction has to be made carefully, because it is the one most often got wrong. Selling online is not the same as distributing digitally. An order placed and paid for on a website for goods that are then driven to the buyer is physical distribution with a digital sales channel. Digital distribution means the thing bought - software, a recording, an e-book, an insurance policy, an online course - travels as data.

### What changes when the product travels as data

For a product that genuinely travels as data, three things follow. The cost of supplying one more copy is close to nothing, so the whole of the extra price is contribution. The seller cannot run out of stock, so a sudden rise in demand costs nothing to meet. And distance adds almost no cost, so a small business can serve a national or foreign market from one location.

Put together, that is why a Namibian business selling an online course can reach buyers in Botswana and South Africa without opening anything, while the same business selling printed manuals would need transport, stock and an agent in each country.

### Which to use

Digital distribution needs connectivity and a payment method the buyer holds, and the product is easy to copy without paying for it, which is a real cost for anything that can be forwarded.

Physical distribution reaches buyers who are not online and lets the buyer inspect the goods before committing, but its cost rises with distance and the stock it requires ties up cash.

Most businesses use both, and the question is rarely which one but how they fit together: an online catalogue with collection from a depot, or a shop that also ships. In a country with long distances between towns the cost of the final stage of the physical journey is often what decides whether an online order is worth fulfilling at all - which is why free delivery thresholds and collection points exist.

### Common errors

**"Selling on a website is digital distribution."** Only where the product itself is delivered over the network. Where a physical item is shipped, the website is a sales channel and the distribution is physical.

**"Cutting out the wholesaler always raises profit."** It raises revenue for each unit and removes a margin, and it hands the producer the cost and the work the wholesaler was doing. The question is which is larger.

**"Place means the location of the business."** It means the route to the buyer, including everyone who handles the product on the way.

### Where this connects

The stock an intermediary holds, and the cash it ties up, is inventory management in 4.2. The margin a wholesaler takes comes straight off the price, so this section runs into the pricing decisions in 3.3.4 and the cost figures in 5.4. Where the product is a service rather than a good, the channel question changes shape, which is 3.3.2.

# 5.3 Forecasting and managing cash flows

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain the meaning and purpose of a cash flow forecast: what it records, how it is laid out, the jobs a business uses it for, and what it cannot do.
- Calculate net cash flow, opening balances and closing balances in a simple cash flow forecast; interpret what the figures say about the business; and amend a forecast when one of its figures changes.
- Explain and analyse the methods a business can use to improve its cash flow, what each one does to the forecast, what it costs, and how to choose between them in a particular situation.

---

## What a cash flow forecast is, and what it is for

### Cash flow forecast

A cash flow forecast is a financial plan that sets out the cash a business expects to receive and the cash it expects to pay out over a future period, normally month by month, together with the balance of cash it expects to hold at the end of each of those periods.

Three words in that sentence carry the weight.

*Cash.* Only money that actually moves into or out of the bank account. A sale made on credit in March is not cash in March. An invoice received in March and paid in May is not cash in March either.

*Expects.* Every figure is an estimate of something that has not happened yet. A forecast is not a record of what the business did; it is a statement of what it thinks will happen.

*Month by month.* The forecast exists to show timing. An annual total would hide exactly the thing it is built to reveal - that the money arrives in November and the bills fall due in August.

### Inflows and outflows

A **cash inflow** is money actually received by the business in a period. The usual ones are cash sales, payments received from credit customers, capital introduced by the owner, money borrowed, the proceeds of selling an asset, and a grant received.

A **cash outflow** is money actually paid out in a period: payments to suppliers, wages and salaries, rent, insurance, electricity and water charges, interest, tax, repayment of borrowing, the purchase of equipment, and drawings or dividends.

Notice what appears in those lists that would not appear in a profit calculation, and what is missing from them. Money borrowed is an inflow, though it is nobody's income. The purchase of a delivery vehicle is an outflow in full, in the month the business pays for it, though a profit calculation spreads the cost of that vehicle over the years it is used. Depreciation, which is a cost without a payment, appears in neither list here because no cash moves.

### How the table is laid out

A cash flow forecast has one column for each future period and five rows.

| Row | What it holds |
|---|---|
| Total cash inflows | Everything expected to come in during the period |
| Total cash outflows | Everything expected to go out during the period |
| Net cash flow | Inflows less outflows for that period alone |
| Opening balance | The cash held at the start of the period |
| Closing balance | The cash expected at the end of the period |

Fuller forecasts break the first two rows into their separate items - cash sales, receipts from credit customers, wages, rent and so on - and add a subtotal. The five rows above are the skeleton, and every version of the table has them somewhere.

Read across a row and you see one item changing over time. Read down a column and you see one month. The closing balance at the foot of each column is the figure the whole table exists to produce.

### Why timing is the question

A business that cannot pay what is due has a problem whatever its profit figure says, because wages, suppliers and lenders are paid in cash and on dates. A business that is short of cash in one month and flush in the next has a timing problem, and a timing problem has a timing solution - an overdraft arranged in advance, a payment rescheduled, a customer asked to settle sooner.

That is the whole reason the forecast is built month by month rather than as a total. The total for the year can be comfortably positive while the business is unable to meet its payroll in August. Only the monthly column shows August.

### A profitable quarter that runs out of cash

Kunene Blocks is a sole trader in Opuwo making concrete blocks for building contractors. It sells on 30-day credit, so the cash from a month's sales arrives the following month. Its cash balance on 1 January is N$40 000.

Sales made: December N$80 000, January N$90 000, February N$100 000, March N$120 000. Materials are paid for in the month they are used. Wages are N$20 000 a month and rent N$8 000 a month. In February the owner pays N$70 000 cash for a second mixer.

| N$ | Jan | Feb | Mar |
|---|---:|---:|---:|
| Cash from customers | 80 000 | 90 000 | 100 000 |
| Materials | 45 000 | 50 000 | 60 000 |
| Wages | 20 000 | 20 000 | 20 000 |
| Rent | 8 000 | 8 000 | 8 000 |
| New mixer | - | 70 000 | - |
| **Total outflows** | **73 000** | **148 000** | **88 000** |
| **Net cash flow** | **7 000** | **(58 000)** | **12 000** |
| Opening balance | 40 000 | 47 000 | (11 000) |
| **Closing balance** | **47 000** | **(11 000)** | **1 000** |

*Brackets mean a negative figure.*

Now the profit for the same quarter. Sales of N$90 000 + N$100 000 + N$120 000 come to N$310 000. Materials come to N$155 000, wages to N$60 000 and rent to N$24 000, which is N$239 000 of cost. Profit for the quarter is N$310 000 - N$239 000 = N$71 000. The mixer is not in that figure, because it is capital expenditure and its cost is spread over the years the mixer is used rather than charged to this quarter.

So Kunene Blocks earns N$71 000 of profit in a quarter in which its bank account goes N$11 000 overdrawn. Two things did it. The credit terms mean each month's cash arrives a month late, and the mixer left the bank in one lump in February. Neither shows up in the profit figure, and both show up in the forecast - which is why the forecast is worth preparing.

### The four jobs a forecast does

**Warning.** The forecast shows, in advance, the periods in which the business expects to run short. Time is what that buys. An overdraft arranged in June for a shortage expected in September is a negotiation; the same request made in September, with wages due on Friday, is a rescue, and the terms available tend to be worse.

**Supporting a request for finance.** A lender or an investor considering a request is likely to ask to see a cash flow forecast, because it shows three things the application turns on: when the money is needed, how much is needed, and when the business expects to be able to repay. A request without one asks the lender to take the timing on trust.

**Testing a decision before committing to it.** Rewrite the figures the decision would change, recalculate, and read the new closing balances. Can the business afford to take on two more staff in April? Put the wages in and see what the closing balance does. The forecast turns an argument into an arithmetic question.

**Monitoring what actually happened.** Set the forecast beside the actual figures at the end of each month. Where they differ, and by how much, shows which assumption was wrong - the sales estimate, the payment dates, or a cost. That is how the next forecast gets better, and it is often how a business locates the part of its operations causing the shortage.

### What the forecast rests on

Every figure in a cash flow forecast is an estimate. The forecast is no more reliable than the assumptions put into it: how much will be sold, at what price, when customers actually pay, and what the costs turn out to be. Get the sales estimate wrong by a fifth and every closing balance after it is wrong too.

Reliability also falls with distance. Next month's receipts can be estimated from orders already placed and customers already invoiced. The receipts eleven months out rest on sales nobody has made yet, which is why a forecast is normally rewritten as each month's actual figures come in rather than being left to run to the end of the year.

Two further limits are worth stating plainly. External events - a drought, a fuel price rise, a customer failing - are not in the forecast at all, and they are exactly the events that cause shortages. And the forecast identifies when a shortage is expected without explaining why it arises or doing anything about it. It is a warning device. The decisions that follow from the warning are a separate piece of work, and they are the subject of the third section of this topic.

### Common errors

**"A profitable business has enough cash."** Profit counts a sale when it is made; the forecast counts it when the customer pays. Add spending on equipment, which leaves the bank in full on one date, and a profitable business can be short of cash for months. Kunene Blocks above made N$71 000 of profit and went N$11 000 overdrawn in the same quarter.

**"A cash flow forecast shows profit."** It shows the cash position. There is no cost of sales in it, no depreciation, and no adjustment for goods sold but not yet paid for. A forecast that ends the year with a healthy closing balance says nothing directly about whether the year was profitable.

**"Money borrowed is income."** Borrowing is a cash inflow and it belongs in the forecast, but it is not earnings. A closing balance held up by an overdraft is a balance that has to be repaid.

### Where this connects

The difference between cash and profit is introduced in 5.1.1 and is the idea this section runs on. Working capital, and the management of trade receivables and trade payables, is 5.1.2. The sources of finance a business turns to when the forecast shows a shortage are in 5.2, where the matching principle - short-term finance for short-term needs - decides which one fits. Completing, reading and amending the table is the next section of this topic, and the methods of closing a forecast shortage are the section after that. Budgets, which plan and control spending rather than track cash, are 5.5.

---

## Completing, reading and amending a forecast

### The two formulas, and every term in them

**Net cash flow = total cash inflows - total cash outflows** (currency, for one period)

**Closing balance = opening balance + net cash flow** (currency, at the end of one period)

The terms:

- *Total cash inflows* - every receipt expected in that period, added together.
- *Total cash outflows* - every payment expected in that period, added together.
- *Net cash flow* - the effect of that period alone on the cash held. Positive means more came in than went out; negative means the reverse.
- *Opening balance* - the cash held at the start of the period.
- *Closing balance* - the cash expected at the end of the period.

And the link that makes the table a table rather than a set of separate months:

**The closing balance of one period is the opening balance of the next.**

Both figures are amounts of money and both are written in the currency of the forecast, not as a number of units, a percentage or a rate.

### Completing a forecast, one column at a time

Work down each column before moving to the next, and the table completes itself.

1. **Start from what you are given** - the opening balance of the first period, and the expected receipts and payments of every period.
2. **Add the receipts** for the period to get total cash inflows.
3. **Add the payments** for the period to get total cash outflows.
4. **Subtract outflows from inflows** to get the net cash flow for that period. Carry the minus sign if it is negative.
5. **Add the net cash flow to the opening balance** to get the closing balance.
6. **Carry the closing balance across** into the next column as its opening balance, and repeat from step 2.

What you have at the end is a closing balance for each period and, with it, the periods where the business is expected to be short.

Two habits prevent most errors. Keep every figure in the same units - if the table is in thousands, N$70 000 is written as 70, not 70 000. And check that the first column's opening balance is the one the question gave; a forecast built from the wrong starting figure is wrong in every column.

### A four-month forecast, completed

Okahandja Timber Supplies is a private limited company selling timber to builders. Its cash balance on 1 April is N$25 000 and it has an agreed overdraft limit of N$40 000. It plans to buy a delivery vehicle for N$180 000 cash in June.

| N$ | Apr | May | Jun | Jul |
|---|---:|---:|---:|---:|
| Cash sales | 60 000 | 64 000 | 52 000 | 58 000 |
| Receipts from credit customers | 85 000 | 90 000 | 96 000 | 70 000 |
| **Total cash inflows** | **145 000** | **154 000** | **148 000** | **128 000** |
| Timber purchases | 78 000 | 82 000 | 74 000 | 70 000 |
| Wages | 36 000 | 36 000 | 36 000 | 36 000 |
| Rent and rates | 14 000 | 14 000 | 14 000 | 14 000 |
| Electricity and water | 6 000 | 6 000 | 6 000 | 6 000 |
| Delivery vehicle | - | - | 180 000 | - |
| **Total cash outflows** | **134 000** | **138 000** | **310 000** | **126 000** |
| **Net cash flow** | **11 000** | **16 000** | **(162 000)** | **2 000** |
| Opening balance | 25 000 | 36 000 | 52 000 | (110 000) |
| **Closing balance** | **36 000** | **52 000** | **(110 000)** | **(108 000)** |

The arithmetic, month by month.

**April.** Inflows N$60 000 + N$85 000 = N$145 000. Outflows N$78 000 + N$36 000 + N$14 000 + N$6 000 = N$134 000. Net cash flow = N$145 000 - N$134 000 = N$11 000. Closing balance = N$25 000 + N$11 000 = N$36 000.

**May.** Inflows N$154 000, outflows N$138 000, so net cash flow = N$154 000 - N$138 000 = N$16 000. The opening balance is April's closing balance, so closing balance = N$36 000 + N$16 000 = N$52 000.

**June.** Inflows N$148 000 against outflows of N$310 000, because the vehicle is paid for. Outflows exceed inflows by N$162 000, so the net cash flow is negative: -N$162 000. Closing balance = N$52 000 added to a net outflow of N$162 000, which leaves -N$110 000.

**July.** Inflows N$128 000 - N$126 000 = N$2 000 of net cash flow. Trading is positive again, but July opens N$110 000 overdrawn, so the closing balance is -N$108 000.

### Reading the four numbers at the bottom

N$36 000, N$52 000, -N$110 000, -N$108 000. A learner who says only "June is bad" has read one number out of four. What the row actually says, read across, is this.

**Trading generates cash.** Every month's net cash flow from trading is positive: N$11 000, N$16 000, N$18 000 before the vehicle is deducted, and N$2 000. This is not a business whose ordinary operations drain cash.

**One decision causes the whole problem.** The vehicle is N$180 000 against an accumulated balance of N$52 000. Nothing else in the table is close to that size.

**The shortage is bigger than the facility.** The June closing balance of -N$110 000 is compared against the agreed overdraft limit of N$40 000. The business is N$70 000 short of being able to make June's payments, and that is the number the forecast exists to produce.

**And it does not clear itself.** July's net cash flow is N$2 000, so the balance improves to -N$108 000. At roughly that rate the overdraft is not repaid within any period the forecast covers. The problem is not a dip; it is a step down that trading does not undo.

That last point is what turns interpretation into a decision. A shortage that trading reverses within a month or two is a timing problem. A shortage that trading does not reverse means either the decision that caused it has to change, or finance of a different kind has to be found for it.

### Recovering a missing figure

Questions often give three of the four quantities in a column and ask for the fourth. The same two relationships, rearranged, produce every one of them.

**Opening balance = closing balance - net cash flow.** A forecast shows an August closing balance of N$4 000 and an August net cash flow of -N$21 000. Because the net cash flow is negative, taking it away adds it back: N$4 000 + N$21 000 = N$25 000. The opening balance was N$25 000.

**Total cash inflows = net cash flow + total cash outflows.** Okahandja Timber's June column shows an opening balance of N$52 000, a closing balance of -N$110 000 and total outflows of N$310 000, but the inflow row has been left blank. The balance fell by N$162 000, so the net cash flow was -N$162 000. Inflows = N$310 000 - N$162 000 = N$148 000.

**Total cash outflows = total cash inflows - net cash flow.** With inflows of N$145 000 and a net cash flow of N$11 000: N$145 000 - N$11 000 = N$134 000.

Nothing new is being learned here. It is two relationships read in different directions, and recognising that is quicker than memorising six rules.

### Amending the forecast: one figure moves, four numbers change

Amending a forecast means changing the figures the new information affects, recalculating the net cash flow of those periods, and then recalculating the opening and closing balances of every period after them. The second half is where an amendment usually goes wrong: a change in June is not a June problem, because June's closing balance is July's opening balance.

New information reaches Okahandja Timber: a credit customer who was due to pay N$40 000 in June has asked to pay in July instead.

June inflows fall from N$148 000 to N$108 000. July inflows rise from N$128 000 to N$168 000. Nothing else changes.

| N$ | Apr | May | Jun | Jul |
|---|---:|---:|---:|---:|
| Total cash inflows | 145 000 | 154 000 | 108 000 | 168 000 |
| Total cash outflows | 134 000 | 138 000 | 310 000 | 126 000 |
| **Net cash flow** | **11 000** | **16 000** | **(202 000)** | **42 000** |
| Opening balance | 25 000 | 36 000 | 52 000 | (150 000) |
| **Closing balance** | **36 000** | **52 000** | **(150 000)** | **(108 000)** |

April and May are untouched, because nothing before June changed. June's outflows exceed its inflows by N$202 000, so its closing balance falls from -N$110 000 to -N$150 000. July's net cash flow is N$168 000 - N$126 000 = N$42 000, and July closes at -N$108 000.

Look at the last figure. July's closing balance is exactly what it was before the amendment. That is not a coincidence, and it is the most useful thing in this section: moving a receipt or a payment from one period to another changes the closing balances of the periods in between, but leaves the closing balance at the end of the whole span unchanged, because the same amount of cash still enters or leaves within that span. One customer paying a month later made June N$40 000 worse and July N$40 000 better, and left the business in the same place by the end of July.

A second amendment changes the timing of a payment rather than of a receipt. Suppose the vehicle supplier accepts N$60 000 in June, N$60 000 in July and N$60 000 in August instead of N$180 000 in June. June's outflows fall from N$310 000 to N$190 000, so June runs a net outflow of N$42 000 and closes at N$10 000 - positive, and the June problem is gone. July then carries an extra N$60 000, so its outflows are N$186 000 against inflows of N$128 000, a net outflow of N$58 000, and July closes at minus N$48 000. The shortage has moved from June into July and shrunk from N$70 000 beyond the overdraft limit to N$8 000 beyond it. A third N$60 000 still falls due in August, outside the four months shown, which is why an amended forecast is extended far enough to show what the amendment has pushed into the future.

### Common errors

**Treating negative net cash flow as a loss.** They are different measurements. Negative net cash flow means more cash left the business than entered it in that period. Okahandja Timber's June is negative because of a vehicle purchase, in a month it traded profitably. A loss is revenue below costs, and a forecast does not report it.

**Forgetting to carry the closing balance forward.** Recalculating one month and leaving the months after it as they were is the commonest way a correct amendment becomes a wrong answer.

**Putting a credit sale in the month of the sale.** A credit sale enters the forecast in the period the customer pays. If the question says 30-day terms, March's sales are April's cash.

**Losing the sign.** A closing balance of -N$110 000 is an overdrawn account. Written as N$110 000 it says the opposite of what the forecast found.

**Leaving the answer bare.** A calculated closing balance is worth stating with its currency and with one sentence saying what it means - whether it is within the facility the business has, and what has to be arranged if it is not.

### In the exam

Fill a forecast in column order, not row order, because each column needs the one before it.

Where an answer has to say what a figure means, compare it with something: the opening balance, the previous month, or the overdraft limit the case gives. A closing balance quoted on its own has not been interpreted.

Where new information changes a forecast, change only what the information touches, then recalculate every balance after it - and say which months are affected and which are not.

### Where this connects

The meaning and purpose of the forecast is the previous section; what to do about a shortage the table reveals is the next one. The credit terms that decide which month a sale becomes cash are managed under trade receivables and trade payables in 5.1.2. The capital expenditure that produces the large single outflows in these examples is distinguished from revenue expenditure in 5.1.2 as well. Break-even analysis in 5.4 answers a different question: it is about profit, and a business can be above break-even and still show a negative closing balance here.

---

## Improving cash flow

### Three places to act

A closing balance is made of inflows, outflows and what was there at the start. So a method of improving cash flow acts in one of three places: it brings cash in sooner, it delays or reduces the cash going out, or it obtains cash from a source outside the ordinary trading cycle.

Sorting a method into its place first is worth more than memorising a list, because the place tells you what the method can and cannot do. Bringing cash in sooner works once - the money was coming anyway. Delaying an outflow moves it rather than removing it. Only reducing an outflow, or genuinely selling more at a price above the cash cost of supplying it, changes the total amount of cash the business ends up with.

### Bringing cash in sooner

**Reduce the credit period, or chase overdue accounts.** A wholesaler with monthly credit sales of N$200 000 on 60-day terms is owed two months of sales at any moment. Move new customers to 30-day terms and, once the change works through, one month's sales - N$200 000 - arrives that would otherwise still be outstanding. That is a one-off gain: after the change the monthly pattern settles again at the new terms. The cost is commercial rather than financial. Customers value credit, and where competitors offer easier terms, pressing for faster payment may cost the business sales.

**Offer a discount for early settlement.** A 2.5 per cent discount for payment within ten days on N$200 000 of invoices gives up 0.025 x N$200 000 = N$5 000 to receive the money weeks sooner. Whether that is worth doing depends on what the business would otherwise pay to cover the gap and on how many customers take it up; a discount taken by customers who would have paid on time anyway is a pure cost.

**Debt factoring.** The business sells its trade receivables to a factor, which advances most of the invoice value immediately - commonly around 80 to 90 per cent - and keeps a fee. On N$200 000 of invoices at an 85 per cent advance, the business receives 0.85 x N$200 000 = N$170 000 straight away instead of waiting 60 days; at a 3 per cent fee it gives up 0.03 x N$200 000 = N$6 000 for that. Two forms exist and they are not the same: under a recourse agreement the business carries the loss if a customer never pays, while under a non-recourse agreement the factor carries that loss and prices the service higher for doing so.

**Take deposits, or sell for cash.** A builder taking 30 per cent with the order has 30 per cent of the contract before buying any materials. This is the strongest of the four where the trade allows it, because it moves cash ahead of the outflow rather than merely closer to it.

### Delaying or reducing what goes out

**Take longer to pay suppliers, or negotiate longer terms.** Cash stays in the business for longer at no direct interest cost, which is why it is usually the first thing a business under pressure does. It is also the method with the sharpest limits. Early-settlement discounts are given up. Relationships are damaged, and a supplier may respond by tightening terms, demanding payment in advance or withdrawing credit altogether - which would leave the business worse off than before. Negotiating longer terms openly is a different act from simply paying late, and it tends to cost the relationship far less.

**Hold less inventory.** Money sitting in stock is money not in the bank. Ordering in smaller quantities more often, or moving slow-selling lines out, releases cash once. Cut too far and the business runs out of stock and loses sales, and small frequent orders can lose a bulk discount.

**Postpone or scale down planned spending on non-current assets.** The largest single outflows in most forecasts are equipment and vehicles, so this is often the fastest way to remove a shortage - Okahandja Timber's June problem in the previous section is entirely a vehicle. The cost is that capacity is not added, and an old asset can raise maintenance costs and break down.

**Lease equipment rather than buying it outright.** One large outflow becomes a series of smaller ones spread across the period of use, which protects the closing balance in the period the equipment is obtained. What the arrangement is worth depends on what the agreement says: whether the charge includes maintenance, whether the business can return the asset early, and who carries the loss if the asset turns out to be worth less than expected. Over the whole term the total paid normally exceeds the purchase price.

**Cut costs.** This improves cash flow to the extent that the cost is actually paid in cash within the forecast period - cutting a cost that is not paid until next year does nothing for this month's balance. And the improvement can reverse: a cut in marketing, in staff or in quality that reduces sales takes the inflows down with the outflows.

### Bringing cash in from outside

**An agreed overdraft.** Interest is charged on the amount actually drawn, the facility can be used and repaid as the balance moves, and it can be arranged quickly. That flexibility is exactly what a short, predictable shortage needs. The rate is higher than on long-term borrowing, and the bank can usually reduce or withdraw the facility at short notice, which makes it a poor way to fund anything long-lived.

**A short-term bank loan,** secured on an asset or unsecured, fixes the sum, the rate and the repayment schedule instead. That suits a shortage of known size and known length, and it cannot be withdrawn at a week's notice. It is less flexible: interest runs on the whole sum whether or not the business needs it all.

**Sell an asset the business no longer needs.** This turns an idle asset into cash with no repayment obligation. It works once, only where such an asset exists, and an asset sold in a hurry often fetches less than it is worth.

**Sale and leaseback.** The business sells an asset it still uses - typically a building - and rents it back, releasing a large sum while carrying on trading in the same place. Ownership goes, any future rise in the asset's value goes with it, and the rent becomes a payment that falls due in poor periods as well as good ones.

**Capital introduced, or a grant.** The owner putting in personal money, or new share capital in a company, adds cash with no repayment and no interest, at the price of the owner's own funds or a share of ownership. A grant is cheaper still where the business qualifies, but it is competitive, conditional and slow to obtain, which makes it a poor answer to a shortage arriving in six weeks.

### Closing a N$70 000 gap

Okahandja Timber Supplies forecasts a June closing balance of minus N$110 000 against an agreed overdraft limit of N$40 000, so it is N$70 000 short of being able to meet June's payments. The cause is a delivery vehicle costing N$180 000. Consider three responses.

**Pay the vehicle in instalments.** The supplier accepts N$60 000 in June, N$60 000 in July and N$60 000 in August. June's outflows fall by N$120 000, so June closes at N$10 000 instead of minus N$110 000 and the June breach disappears. July then carries the extra N$60 000 and closes at minus N$48 000, which is N$8 000 beyond the facility, and a third N$60 000 falls due in August, outside the four months shown. A N$70 000 breach in June has become an N$8 000 breach in July with a payment still to come: a large improvement rather than a solution. Its price is whatever interest or higher price the supplier attaches to paying in three parts.

**Factor the July receivables.** N$70 000 is due from credit customers in July. Sold to a factor at an 85 per cent advance, that produces 0.85 x N$70 000 = N$59 500 in June, at a fee of 3 per cent, which is 0.03 x N$70 000 = N$2 100. June's closing balance improves to minus N$50 500, so the amount beyond the facility falls from N$70 000 to N$10 500. July then receives from those invoices only the retained balance less the fee - N$10 500 less N$2 100, which is N$8 400 - instead of N$70 000, so July closes at minus N$110 100. Taking the two months together the business ends N$2 100 worse off than it started, and N$2 100 is the fee: factoring moved cash out of July into June and charged for moving it.

**Postpone the vehicle.** June's outflows fall by N$180 000, so June closes at N$70 000 and July at N$72 000, both comfortably positive. It costs nothing in interest or fees. What it costs is whatever the vehicle was going to earn or save - if it was bought to serve a contract starting in July, postponing it may cost more than the other two options together.

Three responses to the same N$70 000 gap, at three different prices. The first two change when cash moves and are paid for in interest or fees; the third is free in cash terms and may be the dearest of all in trading terms.

### Analysis: why most of these methods buy time rather than money

Take the wholesaler that moves its customers from 60-day to 30-day terms. Cash arrives a month sooner, so the balance in the month of the change is N$200 000 better. In the month after that, receipts are one month's sales, exactly as they were before - the business is collecting the same N$200 000 a month, just one month closer to the sale. The gain was a single step up in the balance, not a rise in the rate at which cash comes in.

The same shape applies to selling an idle asset, to reducing inventory, and to factoring. Each produces cash once, or pulls forward cash that was coming anyway. Delaying a payment to a supplier is the same thing in the other direction: the money is still owed and still leaves, one month later.

So the consequence for the business depends entirely on what kind of shortage it has. Where the forecast shows a dip that trading reverses - a seasonal trough, a single large purchase - a one-off gain of the right size at the right moment is exactly the right tool, and the business survives a period it would otherwise not have survived. Where the forecast shows the closing balance falling in every period, a one-off gain postpones the problem by one period and the business arrives at the same place with its receivables already sold, its suppliers already stretched and its idle assets already gone. A shortage that persists points to prices too low, costs too high or too little demand, and a change of timing does not fix any of those.

That is the judgement worth carrying into an exam answer: identify from the forecast whether the shortage is a dip or a slope, and let that decide whether a timing method is a solution or a delay.

### Choosing between the methods

There is no best method of improving cash flow: which one fits depends on the business and the shape of its shortage, which is why the choice is made case by case. Five criteria decide it.

**How big the gap is.** A shortfall of N$10 000 is a conversation with the bank. A shortfall of N$500 000 rules out most of the timing methods immediately, because they cannot produce that much.

**How long it lasts.** A dip of one or two periods suits an overdraft, a delayed payment or factoring. A shortage running through the whole forecast needs either finance matched to its length or a change in the business itself.

**What it costs.** A factoring fee, a settlement discount and overdraft interest are all real and all quantifiable, and they should be compared with each other rather than each judged on its own. A method that is free in cash terms, such as postponing equipment, may carry the largest cost of all in lost trading.

**How fast it can be arranged.** A grant application takes months. An overdraft extension takes days where the relationship and the security are already in place. When the shortage is six weeks away, speed can outrank cost.

**What it does to relationships.** Paying suppliers late and pressing customers hard both work on the forecast and both spend goodwill the business may need later. Factoring puts a third party in front of customers, and some read that as a sign of difficulty.

A complete judgement names which criterion decides in this case and why, says what the strongest argument on the other side is, and states the condition that would change the answer - typically a figure from the forecast itself, such as whether the balance recovers before the next large payment falls due.

### Common errors

**"Increasing sales improves cash flow."** Not by itself, and sometimes not at all in the short run. A sale on 60-day credit is cash in two months' time, while the materials and wages to supply it are paid now. A business growing quickly on credit terms can find its cash position getting worse as sales rise, which is why growth is a common cause of cash shortage rather than a cure for one.

**"Cutting costs improves cash flow."** It improves cash flow where the cost is paid in cash inside the forecast period, and the improvement can reverse if the cut reduces sales. Cutting a cost that is not paid until next year does nothing for this month's balance.

**"An overdraft solves the problem."** It funds the gap; it does not close it. The balance is still negative and interest is now being paid on it. Where the forecast shows the shortage persisting, an overdraft buys the time to fix the cause and is not itself the fix.

**Listing methods without a mechanism.** "Debt factoring" is not an answer. "Selling the July receivables to a factor brings N$59 500 into June, which narrows a N$70 000 gap to N$10 500 at a fee of N$2 100" is one.

### Where this connects

The forecast that identifies the shortage is the previous two sections. Every external method named here is a source of finance, set out fully in 5.2 with its own benefits and limitations, and the matching principle there - short-term finance for short-term needs - is the same reasoning applied to the choice. Managing trade receivables and trade payables, which is where the internal methods live, is 5.1.2. Business failure through lack of finance is 5.1.1. Budgets, which control spending period by period, are 5.5, and inventory control is 4.2.

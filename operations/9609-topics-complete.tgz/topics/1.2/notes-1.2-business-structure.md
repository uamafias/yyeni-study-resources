# 1.2 Business structure

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Identify and explain the primary, secondary, tertiary and quaternary sectors and the private and public sectors, and analyse why the relative importance of sectors changes and what follows from it.
- Explain the main features of sole traders, partnerships, private and public limited companies, franchises, co-operatives, joint ventures and social enterprises; explain limited and unlimited liability and why they matter; and analyse and evaluate which form of ownership suits a business and whether it should change.

---

## Economic sectors, and why the balance between them moves

### The four economic sectors

Economic activity is sorted by how far a good or service has travelled from the ground towards the person who finally uses it.

**Primary.** Extracting or harvesting raw materials from natural resources. Mining, farming, fishing, forestry, quarrying.

**Secondary.** Processing raw materials or components into finished or part-finished goods. Manufacturing, food processing, assembly, construction.

**Tertiary.** Providing services rather than physical output, to consumers or to other businesses. Retailing, transport, banking, insurance, tourism, education, health care.

**Quaternary.** Knowledge-based activity: research and development, information services, data processing, consultancy, software development. The output is knowledge rather than a service handed over on the spot, which is why some classifications separate it from the tertiary sector and others leave it inside.

### A sector is an activity, not a company

The commonest mistake here is to ask which sector a business is in, as though a business had one. A sector classifies an activity. One business may carry out several.

A Walvis Bay firm that owns trawlers, runs a freezing and canning plant and sells through its own shops is doing primary work at sea, secondary work in the plant and tertiary work in the shops. A question about its sector has to say which activity is being classified, and a good answer says so rather than choosing one and hoping.

The same firm is a useful way to see the four definitions working, because the raw fish, the canned fish, the sale over the counter and the stock-assessment research the company pays for are four different kinds of output from one business.

### Namibia by sector

Mining and fishing are the largest primary activities in Namibia. Fish and meat processing and beverage production are the main secondary activities. Tourism, retailing, transport, banking and government services make up most tertiary activity, and together they employ more people than the other sectors combined. Quaternary activity is small but growing, in geological survey work, software and telecommunications.

That shape matters for the rest of the topic. An economy whose exports are concentrated in extraction is exposed to world commodity prices it does not set, which is one reason governments try to move activity into the secondary and tertiary sectors.

### The private sector and the public sector

This second classification cuts across the first. It asks who owns the organisation, not what it produces, so a mine, a bank and a bus company can each sit in either sector.

The **private sector** consists of businesses owned and controlled by private individuals or by other private organisations. Objectives are set by the owners, and profit is usually among them.

The **public sector** consists of organisations owned and controlled by the state on behalf of the population, funded mainly from taxation and government borrowing. Objectives are set by government and any surplus belongs to the state. Government ministries, state hospitals and schools, and the national water and electricity utilities sit here.

### What each sector is trying to do

Ownership is the formal difference. Purpose is the difference that changes behaviour.

A private-sector business answers to owners who have put their own money in, so profit, growth and the return on that money tend to dominate its objectives. It usually withdraws from a route, a product or a region that loses money.

A public-sector organisation answers to government, so access, coverage and the price users pay tend to dominate. It may be kept running on a route or in a district where a commercial operator would make a loss, because reaching those users is the point of it. That is the reason public-sector organisations are often judged on service measures rather than on profit alone.

The boundary is not always sharp. A state-owned enterprise is owned by government but trades commercially and may be expected to cover its costs. A public-private partnership has a private firm build or operate a facility under a government contract. In each case the sector follows who holds ownership and control.

### Public sector, public limited company

These are different things and the shared word costs learners credit every year.

A public limited company is owned by its shareholders, who are private people and private institutions. It sits in the **private** sector. The word public in its name means that its shares may be offered to the general public, not that the state owns it.

A useful test: ask who would receive the profit. If the answer is shareholders, it is private sector, whatever the name says.

### What relative importance means

Relative importance is a sector's share of national output, or its share of total employment. It is a proportion, not a total.

That distinction does the work in most answers on this objective. A sector can fall in relative importance while its output is still rising, because the rest of the economy grew faster. Namibian mining output can increase in a year in which mining's share of national output falls. Writing that a shrinking share means a shrinking industry is the single most common error on this objective.

### Why the balance shifts

**The primary share tends to fall as income per head rises.** Mechanisation raises output for each worker, so the same tonnage needs fewer people. Reserves of a mineral are depleted and what remains costs more to extract. And households spending extra income spend proportionally less of it on food and raw materials and more on services.

**The secondary share tends to rise during industrialisation.** Investment in plant, technology brought in from abroad, a supply of labour at wages below those of established manufacturing countries, and government support through infrastructure or protection all raise the return on manufacturing inside the country, which draws capital and workers into it.

**Deindustrialisation** is the fall in the secondary share in an economy where manufacturing was already established. Producers elsewhere have lower costs, domestic wages rise faster than productivity, firms move production abroad, and demand shifts towards services.

**The tertiary and quaternary shares tend to rise as incomes rise**, because spending on travel, health care, finance and entertainment rises more than proportionally with income. Two forces add to it. Communications technology makes many services tradeable over distance, so they can be produced in one country and sold in another. And manufacturers contract out cleaning, logistics and information technology that used to be counted inside the secondary sector, which moves the same work across the boundary without anybody doing anything new.

### What a sector shift does to people and to businesses

The cost of a shift falls hardest on workers whose skills were specific to the declining sector. A rock-drill operator whose mine closes does not become a software developer. The jobs created in a growing sector may therefore not be open to the people the shrinking sector released, and the result is structural unemployment: vacancies and unemployed workers existing side by side because the skills do not match.

The loss is also concentrated geographically. Extraction and heavy manufacturing sit in particular towns, so when they contract the whole town contracts, while the new service jobs appear in the capital. Retraining, relocation allowances and attracting a replacement industry are the usual responses, and all three take years.

For an individual business, a sector shift changes four things it has to plan around: where its customers' spending is going, how easily it can recruit the skills it needs and what it must pay for them, what its suppliers can still supply locally, and where government attention and support are directed. A supplier of drilling consumables to a shrinking mining sector faces falling orders whatever it does well, which is why firms tied to one sector watch these figures rather than only their own.

### Worked example: reading a shift

Suppose mining's share of Namibian output falls from 12% to 9% over five years while total national output grows by 30%. Two questions follow, and they have different answers.

Has mining shrunk? Not necessarily. If output was N$12 billion out of N$100 billion and is now 9% of N$130 billion, mining output is N$11.7 billion: slightly down in money terms, but nothing like the quarter that the share figures suggest. The share fell mainly because everything else grew.

What should a mining-services business do with that? The relevant number is not the share but the orders. A fall of that size in real mining output is small, so the immediate threat is limited; the planning question is whether the trend continues, because a services firm that depends on one sector has to build capability for a second one before it needs it, and that takes longer than the decline does.

### The short version

Four sectors by how far the output is from the ground: primary extracts, secondary processes, tertiary serves, quaternary produces knowledge. Two sectors by ownership: private, owned by individuals and organisations; public, owned by the state. A public limited company is private sector.

Relative importance is a share, so it can fall while output rises. The primary share tends to fall with rising income, the secondary share rises with industrialisation and falls with deindustrialisation, and the service share rises with income and with technology. The cost of the shift is structural unemployment concentrated in the places the old sector occupied.

---

## Types of business ownership, liability, and changing form

### The four questions that separate the forms

Eight types of ownership sounds like eight lists to memorise. It is not. The types differ on four questions, and almost every advantage and disadvantage in this topic is one of those four answers seen from a particular angle.

Who owns the business? Does the business have a legal identity separate from its owners? Who is liable for its debts? And which ways of raising capital does the form allow?

Answer those four for a form and the advantages fall out on their own. A form with no separate legal identity gives no protection from debts and has no shares to sell, so it is cheap to start and hard to grow. A form with a separate identity costs money and paperwork to create and gives protection and a route to capital in exchange. Learning the four questions is quicker than learning eight lists, and it works on a form you have never seen.

### Unincorporated and incorporated

This is the deepest division in the topic, and the one most other differences hang from.

An **unincorporated** business has no legal identity separate from its owners. The owners make the contracts personally, they carry unlimited liability for the debts, and in law the business ends when they leave it. Sole traders and ordinary partnerships are unincorporated.

An **incorporated** business is a separate legal person. It owns assets in its own name, makes its own contracts, sues and is sued as itself, its members have limited liability, and it goes on existing when a member sells out or dies. Private limited companies and public limited companies are incorporated.

Everything that follows about protection from debts, about continuity, and about issuing shares is a consequence of which side of this line a business sits on.

### Four of the eight are not legal forms

Of the eight types the syllabus names, four are legal forms of ownership in themselves: sole trader, partnership, private limited company, public limited company. Those are the answers to the question what is this business in law.

The other four answer a different question. A franchise is a trading agreement between two businesses. A joint venture is an agreement between businesses to work on one project together. A co-operative is a way of dividing ownership and votes among members. A social enterprise is defined by its purpose and by what happens to its surplus. A business can be any of these and still be, in law, a private limited company.

This is worth being clear about because a question that asks for the legal form of a franchised outlet wants sole trader or private limited company, and a question that asks what kind of business it is wants franchise. Those are two answers, not one.

### Sole trader

A sole trader is a business owned and controlled by one person, who provides the capital, keeps the profit after tax and is personally liable for the debts. The business is unincorporated, so in law the owner and the business are the same person.

The word sole refers to ownership, not to staffing. A sole trader may employ people, and many do. What makes the business a sole trader is that one person owns it, controls it and carries the liability alone.

### What the sole trader form gives, and what it costs

It is the quickest and cheapest way to start. There is no separate legal person to register, and beyond any trading licence the activity itself requires, little formal paperwork. The owner decides everything without consulting anybody, keeps all of the profit, and does not publish accounts, so competitors cannot read the figures.

Four things limit it, and they are the four that push successful sole traders into another form.

Liability is unlimited, so personal assets are exposed to business debts. Capital is restricted to what the owner can put in or borrow, because there are no shares to sell. The business has no continuity in law: if the owner dies or stops trading it ends, and the assets pass through the estate, which makes it hard to build something to hand on. And one person carries every function, so illness stops the business, and skills the owner lacks are either bought in or done badly.

The form suits a business that is small, low-risk, personal to the owner and not trying to grow fast: a hairdresser, a plumber, a market trader, a consultant working from home.

### Partnership

A partnership is a business owned by two or more people who share the capital, the profits and the control of it. An ordinary partnership is unincorporated, so the partners carry unlimited liability for the debts of the business. Many jurisdictions cap the number of partners, commonly at twenty, with exceptions for professions such as accountancy and law.

### The agreement, and the trade-off

A **partnership agreement**, sometimes called a deed of partnership, is the written contract between the partners. It normally sets out how much capital each partner puts in, how profits and losses are divided, what each partner's role and authority is, how decisions are taken, and how a partner may be admitted or may leave.

Where there is no agreement the default rules of the jurisdiction apply instead, and those rules may divide profit equally however unequal the contributions were. That is why the agreement is the first thing a well-run partnership does and the first thing a failing one turns out not to have.

Against a sole trader, a partnership brings in more capital, more skills, someone to share the workload and the decisions with, and the chance for each partner to specialise. Against that, the profit is divided, decisions have to be agreed so the business moves more slowly, and each partner can bind the others: an ordinary partner's contracts and debts are the responsibility of all of them, so one partner's mistake can reach the personal assets of the rest. Partnerships therefore suit people who trust each other and whose skills differ, which is why they are common in professional practices.

Many jurisdictions also allow a **sleeping partner**, who puts in capital and shares profit but takes no part in running the business, and some allow a **limited partner** whose liability is capped at the amount contributed provided that partner does not manage the business. Whether either is available, and on what terms, depends on the law of the country the partnership is registered in.

### Private limited company

A private limited company is an incorporated business owned by shareholders whose shares are issued privately, to people the company chooses. Its shares may not be offered for sale to the general public. It is a separate legal person from its shareholders, and their liability is limited.

Directors run the company on the shareholders' behalf. In a small company the directors and the shareholders are usually the same people, so incorporation changes the legal position without changing who actually decides anything from day to day.

### What incorporating privately gives, and what it costs

It gives the shareholders limited liability. It gives the business continuity that does not depend on any one owner, so it can be sold or inherited as a going concern. And it opens a route to capital that an unincorporated business does not have, because shares can be issued to new investors. Because those shares go to people the existing shareholders agree to admit, control stays inside a known group, which is why the form suits a family business that wants outside money without outside command.

It costs formation expense and legal formality. Accounts and details of directors have to be filed and are then open to inspection, so the privacy a sole trader enjoys is gone. And the shares are hard to sell: there is no public market for them and the other shareholders commonly have to approve a transfer, so a shareholder who wants out may wait a long time to find a buyer at a price they accept.

### Public limited company

A public limited company is an incorporated business whose shares may be offered for sale to the general public, and are commonly traded on a stock exchange. Its shareholders have limited liability and it is a separate legal person. Company law sets a minimum share capital for the form and requires fuller disclosure than it does of a private limited company.

**Flotation**, also called an initial public offering, is the process by which a company becomes a public limited company and offers its shares to the general public for the first time.

### What flotation gives, and what it costs

It puts sums of capital within reach that the other forms of ownership do not provide, which is the largest single difference in this topic. It also gives existing shareholders a market: a founder who wants to realise part of what they have built can sell shares to somebody they have never met, which in a private limited company is close to impossible to arrange.

The costs are substantial and they are permanent. Flotation itself carries legal, accounting, underwriting and marketing fees. The company must publish full accounts and announce information that competitors can read. Ownership is dispersed among many shareholders, so no founder holds the authority they held before. Anyone may buy the shares, so the company is exposed to a takeover it does not want. And shareholders who can sell at any moment tend to press for results in the current year, which makes an investment that pays back over ten years harder to defend.

**Divorce of ownership and control** is the name for what dispersed ownership does. Shareholders own the company but do not manage it; directors manage it without owning much of it. Their interests may then diverge, with directors pursuing growth, prestige or their own security where shareholders want dividends and a rising share price.

### Franchise

A franchise is an agreement under which one business, the **franchisor**, grants another, the **franchisee**, the right to trade under its brand name and to use its business format in a defined area. In return the franchisee normally pays an initial fee and a continuing royalty, commonly a percentage of sales revenue, and agrees to run the outlet the franchisor's way.

A franchise is a contract, not a legal form of ownership. The franchisee still has to be something in law, and is commonly a sole trader or a private limited company, so the liability the franchisee carries is decided by that choice and not by the franchise agreement.

### The two sides of a franchise

**For the franchisee.** The format has been tested already, so the risk of failure is lower than starting an unknown business from nothing. The brand brings customers from the first day, and training, a supply chain and national advertising come with it, none of which a single outlet could pay for alone. The price is a permanent share of revenue, payable whether the outlet is profitable or not, and the loss of freedom over what is sold, how it is priced and how the outlet looks. An entrepreneur with a better idea for the local market is contractually unable to try it. Selling the business on usually needs the franchisor's consent.

**For the franchisor.** Expansion is financed by other people's capital, and each outlet is run by an owner with their own money at stake, which tends to produce more care than a salaried manager gives. Royalty income grows with the network. The price is weaker direct control: quality depends on people the franchisor does not employ, and one franchisee's poor hygiene or rudeness damages the brand in every other outlet, because customers cannot tell the outlets apart. That is why franchise agreements are long and prescriptive.

### Co-operative

A co-operative is a business owned and democratically controlled by its members, who are the people who use it: its workers, the producers who supply it, or the customers who buy from it. Voting is normally one member one vote, whatever each member has contributed, and the surplus is shared among members in proportion to their use of the business rather than to the capital they put in.

### Kinds of co-operative, and the trade-off

Three kinds are common. A **worker co-operative** is owned by the people employed in it. A **producer co-operative** is owned by producers who pool processing, transport or marketing, which is the usual form in agriculture: communal farmers who market cattle together, or a marula oil group that presses and sells jointly. A **consumer** or retail co-operative is owned by the customers who shop in it.

The strength of the form is bargaining power and shared cost. Members who could not afford cold storage, a truck or a relationship with a supermarket buyer on their own can afford them together, and members who own the business have a reason to keep supporting it rather than selling to whoever offers a shilling more this week.

The weaknesses come from the same structure. One member one vote makes decisions slow, because agreement has to be reached across a large membership. It also makes it hard to reward a member who contributes more capital, since extra capital buys no extra say, so capital is scarce and growth is slow. And a business run by its members may lack specialist management unless it pays to bring some in, which members who work for modest returns are often reluctant to do.

### Joint venture

A joint venture is an agreement between two or more businesses to pool resources for a particular project, or to form a jointly owned business, sharing the cost, the risk, the control and the returns. The businesses stay separate and independent in everything outside the venture, which is what distinguishes a joint venture from two firms becoming one.

### Why businesses form them, and what goes wrong

Businesses form joint ventures to get something the partner already has and they would take years to build: local knowledge of a market, an established distribution network, a technology, a licence, or a permit a foreign firm cannot obtain alone. A joint venture also splits the cost and the risk of a project too large or too uncertain for one firm to carry, which is why they are common in mining exploration and in large construction. In some countries a partnership with a local business is a condition of being allowed to operate at all.

They fail for predictable reasons. The partners want different things from the venture, so decisions that suit one damage the other. One contributes less than it promised. Management styles and decision-making cultures clash, particularly across countries. Profits and responsibility are argued over when the project runs late. And there is a longer risk worth naming: a partner may learn the technology or the market during the venture and afterwards use what it learned to compete.

### Social enterprise

A social enterprise is a business that earns its revenue by trading, but whose primary objective is a social or environmental purpose rather than a return to owners. Most or all of its surplus is reinvested in that purpose instead of being distributed as profit.

It is defined by its purpose and by what happens to the surplus, not by one legal form: it may be registered as a private limited company, as a co-operative or as a trust. It is distinct from a charity, which does not principally trade for its income, and from a conventional business that supports a good cause out of profit it otherwise keeps.

### The triple bottom line, and the tension inside it

Social enterprises are often described as working to a **triple bottom line**: they measure themselves on economic performance, on social benefit such as employment, training or access to a service, and on environmental effect. Performance against all three is reported, and that reporting is what separates the form from a conventional business that gives some of its profit away.

The advantage is that the purpose is built into the business rather than depending on donations, which makes it durable, and that purpose attracts committed staff who accept lower pay for work they believe in, customers who prefer to buy from it, and grant funding a conventional firm could not apply for.

The difficulty is the same purpose pulling against survival. Prices are held down for the people the enterprise exists to serve, which thins the surplus. Surplus is reinvested rather than paid out, so investors seeking a financial return have little reason to put money in, and capital is harder to raise than for a comparable commercial business. A social enterprise that runs out of cash helps nobody, so the management task is holding the two objectives together rather than choosing between them.

### Unlimited and limited liability

**Unlimited liability** means the owner and the business are the same in law, so the owner is personally responsible for the debts of the business without any limit. If the business cannot pay, the owner's personal assets, including a house, a vehicle or savings, may be sold to settle what is owed.

**Limited liability** means a shareholder's responsibility for the company's debts is limited to the amount that shareholder has agreed to pay for the shares. The company is a separate legal person, so the debt belongs to the company; a shareholder who has paid for the shares in full stands to lose that investment and no more of their personal wealth.

The difference between the two comes from incorporation and from nothing else. Registering a company creates a legal person separate from the people who own it, and it is that separation which puts the debt on the company rather than on the owners. Where there is no separate legal person there is no limit on liability, which is why sole traders and ordinary partners carry it.

### Why liability matters, and to whom

**To owners.** Limited liability caps the downside of a venture before it starts. A person who knows that failure costs the money invested, and not the family home, will take on a project they would otherwise refuse, and outside investors will put money into a business whose management they cannot supervise. More capital reaches new and risky ventures as a result than would reach them if every shareholder were liable for everything. That is the economic argument for the concept, and it is the one an evaluation question usually wants.

**To creditors.** The same rule shifts risk onto the people the company owes money to, because their claim stops at the company's own assets. Lenders and suppliers respond to that. A bank asked to advance money to a small company with few assets may require security over property, or a personal guarantee from the directors; a supplier may ask for payment in advance until a trading record exists. Where a director signs a personal guarantee, the protection of limited liability is given up for that particular debt, which is why the protection is often thinner in practice for a young company than it looks on paper.

**The limits of the protection.** Limited liability is not a shield against every personal consequence. It does not cover a debt a director has personally guaranteed, and company law in most jurisdictions allows a director to be held personally responsible where a company was allowed to go on trading and taking on debts once there was no reasonable prospect of paying them. The precise rules, and the thresholds that trigger them, depend on the jurisdiction, so an answer should teach the principle and say that the detail is national.

### Choosing a form: what actually decides it

Appropriateness is decided by a short list of questions, and a good answer works through the ones that matter for the business in front of it rather than reciting all of them.

How much capital does it need, and how soon? How much personal risk are the owners willing to carry? How much control do they want to keep? What are their objectives - income, independence, growth, a social purpose? How fast do they intend to grow? How much set-up cost and continuing formality can they carry? And does the law require this particular activity to be conducted in a particular form?

Two of those pull against each other, and that tension is where most of the marks in an evaluation sit. Raising more money from outside usually means admitting somebody who then has a claim on profit and a say in decisions. A partner brings capital in exchange for a share of profit and of control. A new shareholder in a private limited company takes both. A flotation spreads both among thousands of people. An owner who will not give up control is therefore choosing to be limited to what can be borrowed or retained out of profit.

The second question that decides real cases is exposure. The value of limited liability rises with what the owner has to lose and with how risky the trade is. A consultant working from home with few debts risks little by remaining a sole trader. A builder who signs contracts worth many times the value of the business, and who owns a house, is exposed to a loss that could take everything, so incorporation is worth its cost to that owner and may not be to the first.

There is no form of ownership that suits every business. Appropriateness is judged against one business's own circumstances and objectives, and those change, which is why a form that was right at the start can be the wrong one five years later.

One caution. Size and legal form are separate things. Some private limited companies employ thousands of people and some public limited companies are small, so a business cannot be classified by its turnover or its headcount. What decides the form is how the business is owned.

### Worked example: two businesses, two answers

**Ndapewa** repairs laptops from a room at home in Ongwediva. Turnover is about N$180 000 a year, she has no staff, she buys parts for cash, and her largest liability at any moment is a customer's machine. She wants a steady income and no paperwork. Sole trader fits: the exposure that limited liability would protect her from is small, and the formation cost, filing and accountancy fees of a company would take a real share of a modest income for protection she has little use for.

**Kunene Structural** builds steel frames on contract. It has eleven employees, it signs contracts worth N$4 million, and a single structural failure could produce a claim far larger than the business is worth. The two owners own houses. Here the calculation reverses: the exposure is large, it arrives without warning, and the annual cost of running a private limited company is small beside a claim that could take both houses. Incorporating is worth its cost.

The two businesses differ on one variable - the size of the loss the owners are exposed to - and that single difference is enough to change the recommendation. An answer that lists the advantages of incorporation without asking what this owner is exposed to has not applied anything.

### Changing from one form to another

The choice of ownership is not permanent, and moving between forms costs money, time and paperwork, so it is a decision in its own right rather than an automatic consequence of getting bigger.

Four changes are common. A sole trader takes in a partner and becomes a partnership. A sole trader or a partnership incorporates and becomes a private limited company. A private limited company floats and becomes a public limited company. And a public limited company returns to private status by buying its shares back from the general public.

**Incorporating** brings limited liability, continuity independent of any one owner, the ability to issue shares, and often a firmer standing with suppliers and lenders who can now inspect filed accounts. It costs formation and continuing compliance expense, the publication of accounts that competitors and customers can read, more administration than the owner did before, and a share of future profits wherever new shareholders are admitted.

**Flotation** brings capital on a scale the other forms do not reach, a tradeable share that lets founders realise part of what they have built, and public profile that helps in recruiting and in selling. It costs the expense of the issue itself, full disclosure of results, the dilution of the founders' control, exposure to a takeover once anyone may buy the shares, and pressure from shareholders for results in the current year rather than in five years' time.

**Going the other way** happens too. A public limited company may buy its shares back and return to private status to escape the cost of disclosure, the pressure for short-term results and the threat of a takeover, accepting in exchange that raising large sums quickly becomes harder again.

### What dilution actually does

Dilution is the arithmetic behind the loss of control, and writing it out stops the vague answer that issuing shares means losing control somehow.

A founder holds 8 000 of a company's 10 000 shares, which is 80% of the votes and 80% of any dividend. The company needs capital and issues 6 000 new shares to an investor. The founder still holds 8 000 shares - nothing has been taken away - but there are now 16 000 shares in issue, so the holding is 8 000 / 16 000 = 50% of the votes.

Follow the consequence. At 80% the founder decided everything. At 50% the founder can block a proposal but can no longer carry one alone, so every decision now needs somebody else to agree. Issue another tranche and the holding falls below half, at which point decisions can be carried against the founder, and below the level company law sets for special resolutions the founder can no longer block a change to the company's constitution either.

The effect on the business is not automatically bad. The capital raised may fund the growth that makes the smaller share worth more in money than the larger share was. That is the trade the owners have to judge: a smaller proportion of a business that can now grow, against a larger proportion of one that cannot.

### How to weigh a change of form

A change of ownership form is worth making when what it brings in is worth more to the owners than what it takes away, judged against their own objectives. Capital and protection from liability are bought with control, privacy, cost and a share of profit.

That makes the decisive question in most cases the same one: what is the money for, and is there a cheaper way to get it? A business that needs N$300 000 for a vehicle is not a flotation candidate; a business that needs N$300 million has few alternatives. Between those, the judgement turns on how urgent the need is, how much control the owners are willing to trade, and whether the profit the new capital generates exceeds the share of profit given away to get it.

The strongest argument on the other side is that the costs of a change are certain and permanent while the benefits are forecast. Compliance cost, disclosure and dilution start immediately; the growth the capital is meant to fund may not arrive. That is why the same change can be right for a business with a firm order book and wrong for one with a hopeful projection, and why a judgement here should name the evidence that would settle it - committed orders, a signed contract, a tested product - rather than resting on the general merits of limited liability.

### The short version

Four questions separate the forms: who owns it, whether it is a separate legal person, who is liable, and how it can raise capital. Unincorporated forms - sole trader, ordinary partnership - are cheap to start and carry unlimited liability. Incorporated forms - private and public limited companies - cost more, protect the owners and can issue shares, and a public limited company may sell those shares to the general public.

Franchises, joint ventures, co-operatives and social enterprises describe how a business is run or what it is for, and sit inside one of the legal forms.

Limited liability caps an owner's loss at what was invested, which encourages enterprise and shifts risk to creditors, who respond by asking for security or guarantees. Which form suits a business depends on capital need, risk exposure, the owners' appetite for control and their objectives, and a change of form is worth making when the capital and protection gained are worth the control, privacy and profit given up.

# 5.5 Budgets

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Define a budget and explain how budgets measure performance; explain the benefits and drawbacks of budgeting; explain the meaning and use of incremental budgets, flexible budgets and zero budgeting; and explain how budgets allocate resources, control spending and monitor a business.
- Define a variance, explain what makes a variance favourable or adverse, calculate revenue, cost and profit variances, and interpret what a set of variances means for a business.

---

## Budgets: the plan, the purpose and the method

### A budget

A budget is a financial plan for a future period, agreed in advance and set out in numbers - money, quantities, or both - for the business as a whole or for one part of it.

Two words in that sentence carry the weight. *Future*: a budget is written before the period it covers, not after it. *Agreed*: it is the plan the business has committed to, and that commitment is what makes it fair to hold someone to the figure later. A sales budget of N$480 000 for the Ondangwa branch in March is what the branch has undertaken to sell, not a guess about what might happen.

### Measuring performance needs a yardstick

Measuring performance means comparing what the business actually achieved with a stated yardstick for the same period. An actual figure on its own is neither good nor bad. Sales of N$505 200 in March is a fact; whether it was a good March depends on what it is set against.

A budget supplies that yardstick, and it can supply one for whatever the business wants to judge: revenue, an individual cost, profit, output, or cash. The manager given responsibility for a particular budget is the budget holder, and it is the budget holder who is answerable for the difference between plan and outcome.

That is fair to the extent that the figures are ones the manager's own decisions can move - what is called controllability. A branch manager can influence staffing, stock ordering and local promotion. The same manager cannot influence a national fuel price rise, and holding the branch to a budget written before that rise measures the accuracy of the forecast as much as the work of the manager.

### Putting a number on the gap

**Performance against budget = actual figure - budgeted figure**, for the same item and the same period.

**Difference as a percentage of plan = (actual - budget) / budget**

The Ondangwa branch budgeted March sales of N$480 000 and sold N$505 200.

Difference = N$505 200 - N$480 000 = N$25 200 above budget.

As a percentage: 25 200 / 480 000 = 0.0525, which is 5.25% above plan.

The N$25 200 says how much. The 5.25% says how much it matters. A difference of N$25 200 against a plan of N$480 000 is a modest overshoot in a branch of that size. The same N$25 200 against a plan of N$60 000 would say the plan itself was wrong.

### A budget is not a forecast

A forecast is a prediction: the best estimate of what will happen. A budget is a commitment: what the business has decided to aim for and to spend. The two are related, because the sales budget usually starts from the sales forecast, but they are not the same document and they are not used in the same way.

The difference shows in what happens when the outcome differs from the figure. Where a forecast turns out wrong, the business updates it. Where a budget is missed, the budget holder is asked to explain the difference, and something is usually done about it.

### What budgeting gives a business

**Planning.** Writing the plan in numbers forces the business to be specific, and the arithmetic exposes problems while there is still time to act. A projection showing payments above receipts in August is a reason to arrange finance in June.

**Co-ordination.** Departments are committed to the same set of numbers, so the volume the workshop plans to make is the volume the sales team plans to sell, and the buyer orders materials for that same figure. Without a shared plan each department works to its own view of demand, which ends either in finished goods nobody has sold or in orders the workshop cannot fill.

**Delegated authority.** A budget lets a manager commit spending up to an agreed limit without asking permission for each decision. Decisions are made faster, and they are still made inside a total the business has chosen.

**Motivation.** A target can pull effort towards it where it is achievable and where the people held to it had a say in setting it. A target imposed from above and beyond reach tends to be abandoned rather than pursued, because missing it by a little and missing it by a lot feel the same to the person being measured.

### What it costs, and where it goes wrong

**Time and management cost.** Budgeting is work. In a small business where one person sells, buys and keeps the books, hours spent on the budget are hours not spent with customers.

**It rests on assumptions.** A budget is built on expected prices, demand and costs. Where one of those turns out differently - a fuel price rise, a competitor opening nearby - the comparison that follows can mislead, because part of the difference is the world changing rather than the business performing.

**Budgetary slack.** A manager who expects to be judged against the budget has a reason to pad it: overstate the costs, understate the revenue, and the target becomes comfortable. Slack makes performance look better than it is and ties up resources another part of the business could have used.

**Rigidity.** A budget can become a reason not to act - refusing worthwhile spending because it is not in the plan. It works the other way at the year end, where a manager spends what is left of an allowance to protect next year's figure. That is spending caused by the system rather than by need.

### Three ways of setting the numbers

The syllabus names three approaches. They differ in where the figures come from.

**Incremental budgeting** takes the previous period's figure and adjusts it by an amount or a percentage - for inflation, or for a planned change in output. A department that spent N$400 000 last year and expects 6% inflation is given N$400 000 x 1.06 = N$424 000.

It is quick, cheap and easy to explain, and it suits conditions that are stable. Its weakness is built into the method: because it starts from what was spent last time, it carries that spending forward without re-examining it. A cost that stopped serving a purpose three years ago is still in the base, and can stay there for years.

**Flexible budgeting** recalculates the budget at the level of output actually achieved. Variable items are recomputed at the actual volume; fixed items stay at the budgeted amount, because they do not move with output. It exists to make a comparison like for like, and it is worked through below.

**Zero budgeting**, also called zero-based budgeting, starts every item at zero each period. Nothing is carried forward by right: a manager who wants the money sets out the activity afresh and what the business gets for it.

It suits spending that is discretionary - marketing, training, head-office services - where the amount is a matter of judgement rather than a contract already signed, and it is the direct answer to costs that incremental budgeting has carried forward unexamined. It costs far more management time, it needs managers who can build a case, and it can end up funding the manager who argues best rather than the activity worth most.

### Flexing a budget: a worked example

Oshakati Bakery budgeted for 20 000 loaves in June. The budget allowed N$7.50 a loaf for ingredients, which is a variable cost, and N$96 000 for rent and salaried staff, which are fixed. June was busy: the bakery made 23 000 loaves, spent N$179 400 on ingredients and N$98 000 on rent and salaries.

Against the original budget, ingredients are N$179 400 - N$150 000 = N$29 400 over. But the budget was written for 20 000 loaves and the bakery made 23 000, so part of that gap is nothing more than the extra 3 000 loaves.

Flex the budget first. At the actual output:

Ingredients: 23 000 x N$7.50 = N$172 500.

Fixed costs: N$96 000. They are not flexed, because rent and salaries do not move with the number of loaves.

Now the comparison is like for like:

Ingredients: N$179 400 - N$172 500 = N$6 900 more than the flexed budget allowed.

Fixed costs: N$98 000 - N$96 000 = N$2 000 more than budgeted.

The ingredient figure is now readable. Actual ingredient cost per loaf was N$179 400 / 23 000 = N$7.80 against N$7.50 allowed - 30 cents a loaf, which over 23 000 loaves is the N$6 900. That is a question about buying prices or waste. Of the N$29 400 the unflexed comparison produced, N$22 500 was simply the cost of baking 3 000 more loaves, and an owner who chased the larger figure would have been looking in the wrong place.

### Allocating, controlling and monitoring

**Allocating resources.** A business has a limited amount of cash, labour and material to hand out, and more claims on it than it can meet. The budget is where that choice is made: the total is divided between departments before the period starts, against what the business is trying to achieve. Making the choice once, in advance, is what stops it being re-argued each time a request lands on a desk - and approving requests one at a time compares each with nothing, so the money can be gone before the strongest claim arrives.

**Controlling.** Budgetary control is the routine that follows: compare the actual figures with the budget at regular intervals, identify the differences, investigate the significant ones, and act on what is found. The budget doubles as a spending limit - authority to commit money up to the agreed figure, and no further without approval.

**Monitoring.** The comparison is made during the period, not only at the end of it, and that is where its value lies. A cost running above plan in month two leaves ten months in which to correct it. The same information at the year end reports a result that is already fixed.

**Management by exception.** Attention goes to the items that differ materially from plan; the rest are noted and left. The business sets its own threshold for what counts as material - a difference above 5% of the budgeted figure, say, or above N$10 000 - because investigating every small difference costs more management time than it recovers.

All four depend on two conditions: that the budget holder can actually influence the figures, and that the comparison arrives soon enough to act on. A monthly report delivered six weeks after the month it covers records history.

### One budget doing four jobs

Karibib Stone cuts and polishes granite. For the coming year it has N$1 800 000 to divide between three departments whose requests total N$2 300 000, and the objective it has set itself is to lift export sales. The owner allocates against that objective: cutting gets N$900 000, polishing N$600 000 and the office N$300 000, with the office request cut hardest because it is the one furthest from the export objective. The N$500 000 gap had to fall somewhere, and spreading it evenly would have protected the department least connected to what the business is trying to do.

That single decision then does three further jobs. The polishing manager may order abrasives up to N$600 000 without asking. The monthly comparison shows, by the end of March, polishing spending N$170 000 against a plan of N$150 000 for the quarter - a difference of N$20 000, or about 13%, which is above the 5% the business treats as material, so it is investigated rather than noted. And the investigation, not the figure, finds the cause: a new abrasive that cuts faster and costs more per pack. Whether that is a problem depends on whether the faster cutting shows up as a lower labour cost per slab, which is a comparison the business can also make against its budget.

### Common errors

**"The budget is what the business expects to happen."** That is the forecast. The budget is what the business has committed to, and the difference between the two matters as soon as somebody is held to it.

**"A budget met every period is a budget well set."** A target met comfortably every period may be padded. Slack is invisible in the comparison, because the comparison is made against the padded figure.

**"Fixed costs are flexed too."** They are not. Flexing recalculates the items that move with output; the fixed items stay at the budgeted amount, which is the whole reason for separating them.

---

## Variances: reading the gap between plan and outcome

### A variance

A variance is the difference between a budgeted figure and the actual figure for the same item over the same period.

Both halves of "the same" do work. A materials variance compares budgeted materials with actual materials, not with total costs, and it compares one month with the same month, not with a quarter. A difference between unlike figures is not a variance; it is an arithmetic mistake.

### Favourable and adverse

Every variance carries a label, and one question decides it: which way does this difference push profit?

A variance is **favourable (F)** where the difference leaves profit higher than the budget allowed for. For revenue, that means actual above budget. For a cost, it means actual below budget.

A variance is **adverse (A)** where the difference leaves profit lower than the budget allowed for. For revenue, that means actual below budget. For a cost, it means actual above budget.

So the same direction of movement carries opposite labels depending on what is being measured. Revenue N$12 000 above plan is N$12 000 favourable. Wages N$12 000 above plan is N$12 000 adverse. Writing "over budget" instead of the label is where that distinction gets lost.

Two things follow about the labels. They describe the direction of the effect on profit, not the quality of anyone's work. And they are not a verdict on the outcome.

A favourable variance is not automatically good news. Materials bought N$18 000 below budget may be a lower grade that raises waste this month and returns next month. A maintenance cost N$40 000 under budget may be maintenance postponed rather than saved.

An adverse variance is not automatically a fault. Overtime paid to finish an unexpectedly large order pushes the wage cost above budget at the same time as it pushes revenue above budget. Read alone it looks like poor control; read beside the revenue line it looks like the right decision.

And where actual output differs from planned output, part of any variable cost variance is that difference in volume alone. That is why a business flexes the budget to the actual output before reading what is left as a matter of price or usage.

### The three calculations

**Sales revenue variance = actual revenue - budgeted revenue.** A positive result is favourable, a negative one adverse.

**Cost variance = budgeted cost - actual cost.** A positive result is favourable, because less was spent than planned; a negative one is adverse.

**Profit variance = actual profit - budgeted profit.** A positive result is favourable.

Written those ways round, a positive answer means favourable in each of the three. If subtracting in the other order is easier, work out the size of the gap as a positive amount and then label it by asking which way it pushes profit. The label is what carries the meaning: a variance reported without one is incomplete.

The three are connected. The profit variance equals the sales revenue variance plus the cost variances, counting favourable amounts as additions and adverse amounts as subtractions. That relationship is worth using, because it shows how the individual differences combine into the one the owner cares about.

Every variance is a money amount and carries the currency. Expressed as a percentage of the budgeted figure it says something the money amount does not: how large the difference is relative to the plan it is measured against.

### A full variance statement

Okahandja Tileworks budgeted June on 12 000 boxes of tiles at N$35 a box. The budget allowed N$14 a box for materials, N$8 a box for wages, and N$72 000 for rent, insurance and salaried staff.

In June it sold 12 400 boxes at N$36, spent N$179 800 on materials and N$92 500 on wages, and its fixed costs came to N$74 000.

**The budget.** Revenue 12 000 x N$35 = N$420 000. Materials 12 000 x N$14 = N$168 000. Wages 12 000 x N$8 = N$96 000. Fixed costs N$72 000. Total costs N$336 000. Budgeted profit = N$420 000 - N$336 000 = N$84 000.

**The outcome.** Revenue 12 400 x N$36 = N$446 400. Materials N$179 800. Wages N$92 500. Fixed costs N$74 000. Total costs N$346 300. Actual profit = N$446 400 - N$346 300 = N$100 100.

| Item | Budget | Actual | Variance | |
| --- | --- | --- | --- | --- |
| Sales revenue | N$420 000 | N$446 400 | N$26 400 | F |
| Materials | N$168 000 | N$179 800 | N$11 800 | A |
| Wages | N$96 000 | N$92 500 | N$3 500 | F |
| Fixed costs | N$72 000 | N$74 000 | N$2 000 | A |
| Profit | N$84 000 | N$100 100 | N$16 100 | F |

The reconciliation is the check that the statement holds together: N$26 400 favourable, less N$11 800 adverse, plus N$3 500 favourable, less N$2 000 adverse, gives N$16 100 favourable - the profit variance. Favourable added, adverse subtracted.

### Reading the statement

The business made N$16 100 more profit than it planned, and each line explains part of why.

**Revenue, N$26 400 favourable.** As a share of plan, 26 400 / 420 000 = 0.0629, about 6.3% above budget. Two things produced it: 400 more boxes sold than planned, and a selling price N$1 above the budgeted N$35.

**Materials, N$11 800 adverse.** That is about 7% above plan - but output was above plan too, so the comparison is not yet like for like. Flexed to 12 400 boxes the budget allows 12 400 x N$14 = N$173 600. Against that, the overspend is N$179 800 - N$173 600 = N$6 200, and the rest, N$173 600 - N$168 000 = N$5 600, is the cost of making 400 extra boxes, which the extra revenue paid for. The N$6 200 is the part worth asking about: N$6 200 / 12 400 = N$0.50 a box more material than allowed.

**Wages, N$3 500 favourable.** Against the flexed budget it is larger than it looks. At 12 400 boxes the flexed allowance is 12 400 x N$8 = N$99 200, against N$92 500 paid: N$99 200 - N$92 500 = N$6 700 below allowance. Something in the wage cost per box has fallen, and it is worth knowing whether that is faster working or fewer hours than the work really needed.

**Fixed costs, N$2 000 adverse.** Fixed costs are not flexed, so this is a straight overspend on items that were not supposed to move with output. Small in money, and the clearest question of the four.

Two general points follow. The size worth investigating is not the money figure alone; it is the size relative to the plan, and whether anyone in the business can influence it. And a variance says what the difference was, not why it happened: the N$6 200 on materials could be a supplier price rise, more breakage, or a budget written at a clay price that was never realistic. Only an investigation separates those, and the action that follows is different in each case.

### Variances that explain each other

Variances are read together, because a difference on one line is often the cause of a difference on another.

A favourable materials variance from buying a cheaper grade can appear beside an adverse labour variance, where the cheaper material is harder to work and takes longer, and can appear again a month later as an adverse revenue variance if customers return the finished work. The saving in month one was then not a saving at all: it was a cost moved into month two and spread across three lines of the statement.

The reverse pattern is just as common. An adverse wage variance caused by overtime sits beside a favourable sales revenue variance, because the overtime was worked to fill orders the budget did not expect. Line by line, the overtime looks like a failure of control. Read together with the revenue line, it looks like a decision that earned more than it cost - and the arithmetic settles which: overtime of N$18 000 against extra contribution of N$26 000 leaves the business N$8 000 better off.

### What a variance does not tell you

A variance is a comparison, and it inherits the weaknesses of both figures it compares.

It does not give a cause. It gives a size and a direction; the reason has to be found by asking.

It is only as good as the budget behind it. Measured against a budget built on a materials price that was already out of date, an adverse materials variance says more about the plan than about the buying.

It does not say whether anyone could have influenced it. A fuel price set nationally and a delivery route chosen locally land in the same distribution cost line.

And it arrives with a delay. A variance calculated six weeks after the month it describes is a fact about the past; how useful it is depends on how much of the year is left to act in.

### Common errors

**"A favourable variance is good and an adverse one is bad."** They describe the direction of the effect on profit. Whether the news is good depends on the cause and on what it costs later.

**"The profit variance is small, so nothing needs looking at."** Offsetting differences hide each other. Revenue N$26 400 favourable beside materials N$11 800 adverse nets down to something modest on the profit line while both underlying differences are large enough to matter.

**"Costs are above budget, so spending is out of control."** Check the output first. Where more was produced than planned, higher variable costs are expected, and the budget has to be flexed before the remainder can be read as price or usage.

**"The label is optional."** A variance of N$6 200 is not an answer. N$6 200 adverse is.

### The order of work

Set the plan. Record what happened on the same basis. Flex the budget where output moved. Subtract, and label every figure favourable or adverse. Then ask why, on the differences big enough relative to plan to be worth the asking. The subtraction is the easy part; the label and the question are where the meaning is.

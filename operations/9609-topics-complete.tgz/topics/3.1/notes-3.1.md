# 3.1 The nature of marketing

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain what marketing objectives are, and explain how they are linked to the corporate objectives of the business.
- Explain the factors that influence the demand for and the supply of a business's products, and analyse how demand, supply and price interact.
- Analyse how markets differ - consumer and industrial, local, national and international - explain the difference between product and customer orientation, and calculate and interpret market share and market growth.
- Explain how products are classified, and explain how marketing differs for consumer products (B2C) and industrial products (B2B).
- Analyse the features of mass and niche markets, and evaluate the advantages and disadvantages of mass marketing and niche marketing.
- Explain geographic, demographic and psychographic segmentation, and evaluate the advantages and disadvantages of segmenting a market.
- Explain the aims of customer relationship management, and evaluate its costs and its benefits to a business.

---

## Marketing objectives and where they come from

### Marketing objectives

A marketing objective is a goal set for the marketing function of a business, stating what marketing is to achieve and by when.

The words "for the marketing function" are doing the work. A business has goals of many kinds; a marketing objective is one that marketing can itself deliver. The ones used most often are raising sales volume or sales value, raising market share, entering a new market or a new segment, improving brand awareness or brand image, launching a stated number of new products, and raising the proportion of customers who buy again.

### What makes an objective usable

"Sell more" is a wish. "Raise our share of the Windhoek bottled-water market from 12% to 15% by the end of next year" is an objective, because it names a measure, a quantity and a deadline, and somebody can say afterwards whether it was met.

That matters for two reasons. Before the event, the objective tells the marketing department which decisions are consistent with it: which customers to aim at, what to charge, where to sell, how to promote. After the event, it is the standard the results are judged against. An objective with no measure and no date cannot do either job.

### A common error

"Increase profit by 10% next year" is not a marketing objective. Profit depends on what the business spends as well as what it sells, and most of that spending sits outside marketing. It is a corporate objective: a goal for the whole business.

The test is whether the marketing function could be held responsible for the result on its own. Share, awareness, sales volume and customer retention pass that test. Profit, return on capital and the value of the business do not.

### Corporate objectives and functional objectives

A corporate objective is a goal for the whole business, set by its senior managers. Underneath it sit the functional objectives - marketing, operations, human resources and finance - each set so that achieving it contributes to the corporate objective.

The order is deliberate. The corporate objective is decided first, and the functional objectives are worked out from it. A corporate objective of growth points marketing towards volume, share and new segments. A corporate objective of survival through a downturn points the same department towards holding the customers it already has and protecting the price. Same business, same market, different marketing objective, because the corporate objective changed.

### Why marketing cannot deliver a marketing objective by itself

Suppose Erongo Tiles, a medium-sized tile maker in Walvis Bay, takes a corporate objective of raising annual revenue by 25% over three years, and turns it into a marketing objective of lifting its share of the national tile market from 9% to 13% in the same period.

Marketing can win the orders. It cannot fire the kilns. Extra sales of that size need operations capacity to produce the tiles, staff to handle the deliveries, and finance to pay for the clay and the glaze before customers pay for the tiles - and for the credit the builders' merchants may expect. If any one of those is missing, the orders arrive and the business cannot serve them, which costs it the customers as well as the sales.

That is why functional objectives are set together rather than separately. A marketing objective is a claim on the rest of the business, and it is checked against what the rest of the business can do before it is agreed.

### When the two pull in opposite directions

Alignment can fail in the other direction too. A business whose corporate objective is to build a premium position may find its marketing department chasing volume with discounts, because volume is the easier target to hit. The discounts may meet the marketing objective and undo the position the business is paying to build, so the same money works against itself.

The practical rule is that the alignment is checked when the objective is set, not when the results come in. A marketing objective which can be met in a way that damages the corporate objective is the wrong objective, however carefully it is measured.

---

## Demand, supply and price

### Demand and supply

Demand is the quantity of a product that customers are willing and able to buy at a given price over a period of time.

Supply is the quantity of a product that businesses are willing and able to offer for sale at a given price over a period of time.

Two parts of those definitions are easy to skim past. "Willing and able" means wanting the product is not enough - the customer has to have the money. And "at a given price over a period" means a demand figure without a price and a period attached is meaningless: 400 crates a week at N$95 is a fact, 400 crates is not.

### What moves demand

The price of the product is the first influence, but it is only one. The others matter because they move demand while the price stays where it is.

Customer incomes. More income usually means more spending, though for the cheapest version of a product demand can fall as incomes rise and buyers trade up.

The price of substitutes, and of complements. A cheaper rival product draws customers away; a cheaper complement - data bundles for a phone, fuel for a vehicle - pulls demand for the main product up.

Tastes, fashion and season. A coastal guesthouse in Swakopmund sees demand rise in the December holidays whatever it charges.

The size and age structure of the population served, which changes slowly but decisively for products tied to an age group.

Promotion by the business itself, which is the one influence on this list that it controls directly.

Expectations about future prices, which can pull purchases forward or push them back, and the availability and cost of credit, which decides whether a large purchase is possible at all this year.

### What moves supply

Supply moves for different reasons, most of them about cost and capacity rather than about customers.

The cost of inputs - materials, labour, energy, and imported components whose price in N$ moves with the exchange rate. The productivity of the methods and technology used, because a business that gets more output from the same inputs can offer more at any given price. The number of businesses offering the same product, since supply in a market is the total of what they all offer. Weather and harvest, which dominate supply of agricultural products such as maize and beef. Taxes and subsidies, which change what the seller keeps from a sale. And the price obtainable, since a higher price makes it worth supplying more.

The mechanism behind the input-cost link is worth stating: a cost rise makes a given output less profitable at the existing price, so businesses tend to offer less at that price unless they can pass the cost on or cut it back. How far output actually falls depends on how much of the rise customers will absorb and on how quickly the business can change what it makes.

### How the two meet

The equilibrium price is the price at which the quantity customers want to buy equals the quantity businesses want to sell, so nothing is pushing the price either way.

Markets spend most of their time away from it. Where the quantity demanded at the current price is greater than the quantity supplied, stock runs down and some customers go unserved; sellers find they can raise the price, and some do. Where the quantity supplied is greater, stock builds up and sellers start to discount to clear it. Price is the signal that carries the information in both directions: a higher price tends to reduce the quantity customers buy and encourage businesses to offer more, and a lower price does the reverse. How strongly each side responds varies between products, which is why the same 10% price rise empties one business's order book and barely touches another's.

### Telling a demand change from a supply change

A rise in demand while supply is unchanged tends to raise both the price and the quantity traded. A fall in supply while demand is unchanged tends to raise the price and reduce the quantity traded.

Notice that the price does the same thing in both cases. The quantity is what separates them, and that is how a business reads its own market. A butcher in Otjiwarongo seeing the price of beef rise while the volume passing through the market also rises is looking at stronger demand, and can plan to buy and sell more. A butcher seeing the price rise while volumes fall is looking at a supply problem - a drought, a border closure, a processor out of action - and the right response is different: secure supply, warn customers, or accept lower volumes for a period.

Reading it the wrong way round is expensive. Treating a drought-driven price rise as evidence of rising demand leads a business to commit to volumes it cannot buy.

### What a business does with this

The practical value is planning. A period in which demand is expected to run ahead of what the business can supply is one in which it may raise the price, take deposits, book extra capacity or bring forward a delivery. A period of the opposite kind carries the risk of discounting and unsold stock, so orders and production are cut back before the stock arrives rather than after.

In an answer, the mark of understanding is the link from the change to the decision. Naming the factor is the start; saying what the business should therefore do differently, and why, is the point.

---

## Markets: how they differ, how a business faces them, and how they are measured

### Consumer markets and industrial markets

A consumer market is one in which the buyers are households purchasing for their own use. An industrial market is one in which the buyers are businesses purchasing to use the product in what they themselves produce, or to resell it.

The difference is not only who signs the order. Industrial markets tend to have fewer and larger buyers, purchases written to a technical specification, prices settled by negotiation rather than displayed on a shelf, and decisions taken by several people over weeks rather than by one person in a minute.

One feature of industrial markets has no counterpart in consumer markets. Demand there is derived demand: it arises from demand for something else. A business supplying wiring to a vehicle assembler sells as many harnesses as the assembler's own sales of vehicles require, and not one more. Its marketing can be excellent and its sales can still halve because its customer's market fell - which is why suppliers in industrial markets watch their customers' markets as closely as their own.

### Local, national and international markets

Markets also differ by how far they reach. A local market is the customers within reach of one town or region; a national market is the whole country; an international market is customers in other countries.

Four things change as the reach widens: the number of customers available, the distance and cost of getting the product to them, the number of sets of rules the business has to satisfy, and whether it is paid in its own currency.

Selling internationally widens the number of possible customers, which may raise sales and reduce dependence on one country's economy - a Namibian business that sells into Angola, South Africa and Zambia is not exposed to a single domestic downturn. Against that, it adds transport cost and time, customs procedures, the risk that an exchange-rate movement changes the value of a sale already made, and the cost of meeting another country's rules and adapting the product to local tastes and languages. A business weighing the move compares the extra revenue it can realistically win against those costs, and against the management time that running a second market takes.

### Product orientation and customer orientation

Product orientation is an approach in which a business starts from the product it can make, concentrating on its quality and technical performance, and then looks for customers to buy it.

Customer orientation, also called market orientation, is an approach in which a business starts from what its research shows customers want, and designs the product, the price and the promotion to fit what it finds.

The practical difference is the order of two questions. A product-oriented business asks what it can make well and then who will buy it. A customer-oriented business asks what customers want and then whether it can make it.

### Which is better, and when

Starting from customer research tends to reduce the risk of launching a product nobody wants, because the need is checked before the money is committed. It does not remove that risk. Research can be badly designed, the answers people give a researcher can differ from what they later pay for, and a market can move between the research and the launch.

Product orientation is not simply an error either. Where a business holds a genuine technical lead, or where customers cannot describe a product they have never seen, starting from what the business can build may open a market that asking customers would never have found. The risk it carries is real: development money is committed before any customer need has been confirmed, so a failure is discovered late and costs more.

For most businesses in most markets the customer-oriented order is the safer one, and the sensible reading of the two is as ends of a range rather than as a choice between opposites. A business can research demand carefully and still lead with what it is unusually good at making.

### Measuring market share and market growth

**Market share (%) = (sales of the business / total sales in the market) x 100**, with both figures taken over the same period and measured on the same basis.

**Market growth (%) = ((market size this period - market size in the previous period) / market size in the previous period) x 100.**

Each of the three quantities - market size, market share, market growth - can be measured by value in N$ or by volume in units. Market size and sales are money or units; share and growth are percentages. The basis has to be stated with the figure, because the two bases can give different answers about the same business.

### Worked calculation

Kunene Dairy sold N$18 600 000 of yoghurt last year in a Namibian yoghurt market worth N$124 000 000. The year before, the market was worth N$110 000 000.

Market share by value = N$18 600 000 / N$124 000 000 = 0.15, and 0.15 x 100 = 15%.

Market growth = (N$124 000 000 - N$110 000 000) / N$110 000 000 = N$14 000 000 / N$110 000 000 = 0.1273, and 0.1273 x 100 = 12.7% to one decimal place.

Now the volume basis. Kunene sold 1 240 000 tubs in a market of 12 400 000 tubs, so its share by volume = 1 240 000 / 12 400 000 = 0.10, which is 10%.

The same business holds 15% of the market by value and 10% by volume. Nothing is wrong with either figure. Kunene sells fewer, dearer tubs than the average seller, so each tub it sells carries more value. Quoting the 15% without saying it is a value share would overstate how many customers it actually reaches.

### What the share figure does not tell you

A market share figure rests on a total-market figure, and that total is usually an outside estimate rather than a measured sum. It also rests on where the boundary of the market has been drawn. Kunene holds 15% of the yoghurt market; of the dairy market it would hold far less, and of the drinking-yoghurt market alone it might hold far more. Nothing in the business changes as the definition moves.

So a share figure is used for comparison over time on a fixed definition, and it is quoted with that definition attached. A share that rises because the business redrew the market is not a gain.

### Reading a change in share or growth

A rising market share means the business is winning sales faster than the market as a whole is growing. That may strengthen its bargaining position with suppliers and with retailers, because it is buying more from the one and offering more turnover to the other, and larger production runs may lower the cost of making each unit.

But share and sales can move in opposite directions. A business whose sales fall by 5% in a market that falls by 15% has gained share while selling less. Its position improved and its revenue did not, and a report that gives only the share is telling half the story. The two figures are read together.

Growth in the market changes the arithmetic again. Where the market is growing, a business can raise its sales without taking a single customer from a rival, which usually costs less than winning them in a static market. Growth also attracts new entrants, so a business can be selling more every year while its share falls.

That gives the two cases that matter. A falling share in a fast-growing market may still leave sales rising; it is a competitiveness problem the sales figure hides, and there is time to deal with it. A falling share in a static or shrinking market usually means falling sales as well, and is the more urgent of the two.

### A common error

Rising sales are not proof of rising market share. If a business grows sales by 8% in a market that grew by 20%, its share has fallen and its competitors have taken the difference. The sales figure says how the business did; the share figure says how it did compared with everybody else selling the same thing.

---

## Classifying products, and marketing to consumers or to businesses

### How products are classified

The first split is by who buys the product and why. Consumer products are bought by households for their own use. Industrial products, also called producer products, are bought by businesses to use in production or to resell. The same physical item can be either: a bag of cement bought by a household to lay a path is a consumer product, and the same bag bought by a contractor to build a wall is an industrial product.

Within consumer products, a further split is by how customers go about buying them. A convenience product is bought often, cheaply and with little thought - bread, airtime, a cold drink. A shopping product is compared on price and quality across several sellers before it is bought - a fridge, a school uniform, a set of tyres. A speciality product is one for which buyers seek out a particular brand and are prepared to travel further or pay more to get it.

Two further splits cut across both. Products are goods or services, and they are durable or non-durable: a durable product is used repeatedly over a long period, a non-durable one is used up quickly.

### Why the classification matters

Classifying is not filing. The class a product falls into shapes how it is sold.

A convenience product has to be wherever the customer happens to be at the moment they want it, because nobody makes a journey for a loaf of bread. That means as many outlets as possible, small packs, and a price the customer does not have to think about. A speciality product can be sold through a few outlets, because buyers who want that brand are prepared to come to it, and the money that would have gone on wide distribution can go into building the reputation that makes them want it.

Get the class wrong and the spending goes to the wrong place. A business that treats a convenience product as a speciality one restricts where it can be bought and loses sales to whatever is on the nearest shelf.

### Marketing to consumers and marketing to businesses

Business-to-consumer marketing (B2C) aims at households buying for themselves. Business-to-business marketing (B2B) aims at organisations buying for their own operations. Four differences follow from the number and size of the buyers.

How much one customer matters. In B2C the buyers are many and each purchase is small, so losing one matters little. In B2B the buyers are fewer and each order is larger, and the loss of a single customer can remove a material part of the year's revenue. The seller therefore invests far more in keeping each one, often with a named account manager.

How the decision is taken. Business buying tends to be formal and technical: a written specification, quotations or a tender, a negotiated price, agreed credit terms, and several people involved - the user, the technical assessor, the buyer, the finance approver. Consumer buying is usually quicker, decided by one person or a household, and more open to influence by brand, packaging and impulse.

How the product is promoted. A consumer product is promoted through media that reach many people at once - radio, outdoor advertising, social media. An industrial product is promoted through personal selling, trade fairs, trade publications and technical demonstrations aimed at buyers the seller can name.

How it reaches the customer. Industrial products more often move directly from producer to customer, because orders are large and the product may need installation or technical support. Consumer products more often pass through wholesalers and retailers, because the producer cannot deal with every household individually.

### Worked example

Namib Cable assembles wiring harnesses. It sells to two vehicle assemblers, which together take 80% of its output, and it has begun selling a boxed set of jump leads to hardware shops.

The two sides of the business need different marketing. The harness business has two customers, and each is worth 40% of output, so an account manager visiting monthly, tight quality records and reliable delivery are worth more than any advertising. Price is negotiated once a year against a specification the assembler writes. The jump-lead business has thousands of buyers who have never heard of Namib Cable; it needs to be on the shelf in the hardware shops where people go when a battery has failed, in packaging that explains the product in three seconds, at a price close to whatever is beside it.

Same factory, same competence, two marketing approaches - because the number and size of the buyers differ, not because the wire does.

---

## Mass markets and niche markets

### Mass and niche

A mass market is a large market for a product with wide appeal, which a business serves with a standardised product aimed at most of the customers in it.

A niche market is a small part of a larger market, made up of customers whose particular needs the wider market does not serve well.

These describe the market a business aims at, not the product category. Bottled water sold nationally at a low price is mass marketing. Bottled water drawn from one spring and sold to buyers who want that source is niche marketing. Same category, two markets, two ways of competing.

### Features of each

Mass marketing usually shows large sales volumes, a standardised product with little variation, wide distribution, promotion through media that reach large audiences, several competitors selling something similar, and competition that turns largely on price.

Niche marketing usually shows small sales volumes, a specialised product, promotion aimed at an identified group rather than at the public, a price that reflects the specialism, few direct competitors at first, and close contact between the business and its customers.

The pattern behind both lists is the same trade-off: volume against distinctiveness. Standardising the product is what makes the large volume possible and what makes the business hard to tell apart from its rivals. Specialising is what lets the business charge more and what limits how much it can sell.

### What each approach offers

Mass marketing offers the size of the revenue available, a lower cost of making each unit when output is large and the product is standardised, and the recognition that comes from wide distribution and heavy promotion - which itself makes it harder for a new entrant to be noticed.

Niche marketing offers a market a small business with limited capital can actually serve, few direct competitors at first, and customers who value the specialism and may accept a higher price, which can give a wider margin on each unit sold. For a business without the finance to build capacity, that is not a second-best option; it is the only one of the two it can afford to attempt.

### What each approach costs

Mass marketing needs capital for capacity and promotion before any of the revenue arrives, faces competition from other large sellers which tends to hold prices and margins down, and is slow to change direction once the whole business is built around one standardised product.

Niche marketing is limited by the size of the niche, however well it is served. The business depends on one group of customers whose tastes may change, a larger competitor may enter once the niche is shown to work, and there are fewer products and fewer customers across which to spread the risk. A niche business that loses its two largest customers in a month has lost a great deal more than a mass marketer losing the same two.

### Choosing between them

The choice is not settled by which list of advantages is longer. It turns on what the business has and what the market already contains: the capital and capacity available, what the business is better at than its rivals, and how crowded the market is.

A new clothing maker in Katutura with N$200 000 of capital and eight machinists cannot attack a mass clothing market held by importers competing on price; it has neither the output to lower its cost per garment nor the money to be noticed. A niche - school uniforms for a group of schools, or workwear for a mining contractor - is within reach, and the higher margin on each garment is what makes the small volume viable.

The judgement changes with the same business five years later. If the niche has funded capacity and a reputation, moving towards a wider market becomes possible - and the decisive question then is whether the business can hold the margin it is used to once it is competing on price. Niche and mass are stages a business can move between, not permanent identities.

---

## Market segmentation

### What segmentation is

Market segmentation is the division of a market into groups of customers who share characteristics or needs, so that the business can aim a different offer, message or price at each group.

The point is not the dividing. It is what the division lets the business do afterwards: make a product that fits one group better than a compromise product fits everybody, and spend its promotional money where the people who might buy actually are.

### The three methods

The syllabus names three methods of segmenting a market.

**Geographic segmentation** divides a market by where customers are: by country, region, town, urban or rural area, or climate zone.

**Demographic segmentation** divides a market by measurable characteristics of the people themselves: age, gender, income, occupation, family size and stage, education, religion or ethnic group.

**Psychographic segmentation** divides a market by how customers live and think: lifestyle, values, attitudes, interests and personality.

A business may use more than one together - women aged 25 to 40 in Windhoek who cycle at weekends uses all three at once. The methods are ways of describing the same customers, not rival theories.

### Geographic segmentation in practice

Geographic segmentation earns its place where location changes what customers need or how they can be reached. In Namibia that is often the case: the climate differs between the coast and the interior, the language of the advertising differs between regions, distances to a shop differ between Windhoek and a settlement in Kavango, and whether a household is connected to mains electricity changes which appliances can be sold to it at all.

A food processor selling across the country might therefore sell smaller pack sizes in areas where households shop daily on foot and larger ones where they shop monthly by car, and advertise on different radio stations in different regions.

Where location does not change buying, geographic segmentation separates customers without separating demand, and the business pays for two campaigns that could have been one.

### Demographic segmentation in practice

Demographic segmentation is the method used most widely, for a practical reason: the characteristics are easy to measure and much of the data already exists in census and official statistics, so it costs comparatively little to use. Age and income in particular divide many markets well - a bank offering a low-fee account to students and a different account to salaried households is segmenting demographically.

Its weakness follows from the same simplicity. Two people of the same age with the same income can buy quite differently, so the group can be sharply defined and still not behave as one. A business that finds its demographic segments buying in much the same way has learned that the characteristic it chose is not the one driving purchases in that market.

### Psychographic segmentation in practice

Psychographic segmentation goes after what demographics miss. Two households in Windhoek with the same income and the same ages may still differ because one is concerned about the environment and the other is not, and that difference is what decides whether a solar geyser is bought.

The cost of that extra explanatory power is that the characteristics cannot be read from official statistics. Attitudes and values have to be gathered by the business itself, which makes this method the most expensive of the three to use and the hardest to keep current, since attitudes move faster than ages do. It is used most where products are bought for what they say about the buyer - clothing, vehicles, holidays - and least where a product is a commodity bought on price.

### What segmentation gains

Aiming a product and its message at a defined group raises the proportion of the audience with a reason to buy, so less of the promotional money reaches people who were never going to buy it. That saving depends on the business knowing which group a given medium reaches, which is why the segmentation and the choice of media are decided together rather than one after the other.

Segmentation can also show a group whose needs nothing on the market meets. That is where a new or adapted product can be sold with less direct competition, and it is how small businesses find room in markets that look full. And it lets a small business concentrate limited resources on the customers it can serve well, instead of spreading them thinly across a whole market and being invisible everywhere.

### What segmentation costs

Segmentation costs money in three places. Finding the segments takes research. Serving them takes more product variants, more packaging and more separate promotion. And making several variants instead of one means shorter production runs, which tends to raise the cost of making each unit.

Those costs are incurred whether or not the segments turn out to buy differently. A segment can also be too small to cover the cost of serving it separately, and segment boundaries move as incomes, ages and tastes change, so a division that fitted the market three years ago may not fit it now. A business that divides its market too finely ends up with many small production runs and a marketing budget spread so thin that it is not noticed in any segment.

### When segmentation is worth doing

Segmentation pays where three conditions hold together. The differences between segments have to be large enough to change what customers will buy or what they will pay. Each segment has to be big enough to cover the cost of serving it separately. And the business has to be able to reach that segment with a distinct product or message.

Where any one of the three is missing, the extra cost arrives and the extra sales do not. A bakery in Oshakati that finds its customers want the same bread whatever their age would be paying for variants and separate promotion to serve a difference that does not exist.

The judgement is therefore not "should we segment?" but "is this basis the one that divides buying in our market, and is each group we would create worth serving on its own?" Where the business cannot answer both, the honest position is to serve the whole market with one offer and spend the money on making that offer better.

---

## Customer relationship management

### What CRM is

Customer relationship management (CRM) is the way a business manages its dealings with the customers it already has - usually supported by a record of who they are and what they have bought - in order to keep them and to increase what they buy.

The phrase covers two things at once: an approach, which is treating the existing customer as an asset to be kept rather than a sale already banked, and the system that makes the approach practical, which is the record itself. A shopkeeper who remembers a hundred customers is doing CRM without software. A business with twelve thousand customers needs the database to do the same thing.

### What CRM aims at

The aims are to retain existing customers; to increase how often and how much each of them buys; to use what is recorded about them to make offers that fit; to improve the service they receive and the way complaints are handled; and to collect feedback that guides what the business sells next.

Retention comes first because of the arithmetic behind it. Selling again to somebody who has already bought usually costs less in promotion than persuading a stranger to buy for the first time - the business already knows what they bought, and has permission to contact them. Long-standing customers may also recommend the business to others, which brings in sales it did not pay to promote.

The recorded history is what makes an offer specific rather than general. A service reminder sent when a machine is actually due, or a refill offer timed to when the last one should be running out, is more likely to be acted on than the same message sent to every name on the list.

### What CRM costs

The costs are easy to underestimate because only the first of them appears on a quotation.

The software has to be bought or subscribed to. The customer data has to be entered and cleaned, which on an established business with years of paper records is the largest single task. Staff have to be trained. Then, every day afterwards, staff spend time recording each contact instead of serving the next customer - a cost that never ends and never appears as an invoice. And the personal data has to be kept secure and used within the law.

That last item is an obligation, not an option. Data has to be kept safe and used for the purpose customers were told about. A business that loses customer data, or uses it in a way its customers did not expect, can lose exactly the trust the system was bought to build, so the security and permission costs belong inside the decision rather than beside it.

### What CRM returns

Against those costs sit repeat revenue from customers who stay, lower promotional spending for each sale made to them, better information for segmenting the market and timing offers, faster handling of complaints, and the chance to sell a related product to somebody who has already bought once.

The second of those is where most of the value usually sits. A business that raises the share of customers who buy again is buying fewer first sales at full promotional cost, and the effect compounds over years rather than showing up in one month's figures.

### Whether it is worth it

The benefits depend on three conditions that a business can check before it spends.

The data has to be accurate and kept up to date, because offers built on wrong records annoy the customers they reach. Staff have to use the system rather than work around it, which is a question of training and of whether recording a contact is quick enough to be done while the customer is still there. And the customers have to be in a market where they buy repeatedly.

That third condition is the one that decides most cases. A vehicle-parts supplier whose garage customers order every week has a great deal to gain from knowing what each of them buys. A firm that fits a borehole pump once and may not hear from that household for fifteen years has much less, and would do better to spend the same money on winning new customers - though even there a record of what was installed has some value when a repair is eventually needed.

# 1.1 Enterprise

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain the purpose of business activity and the four factors of production it uses; define and calculate added value; explain economic activity, the problem of choice and opportunity cost; explain how the business environment changes and why businesses succeed or fail; and distinguish local, national, international and multinational businesses.
- Explain the qualities entrepreneurs and intrapreneurs need for success, the role of entrepreneurship in creating and starting up a business and of intrapreneurship in keeping an established business successful, the barriers to entrepreneurship, the difference between business risk and uncertainty, and the part business enterprise plays in the development of a country.
- Explain what a business plan is and what it is for, set out the elements a plan contains and why each is there, and analyse and evaluate the benefits and limitations of writing one.

---

## Business activity: purpose, resources, value and change

### Business activity

Business activity is the process of combining resources - natural, human and man-made - to produce goods or services that satisfy the wants and needs of customers.

The word *combining* is doing the work. Sand, cement, a mixer, a bricklayer and somebody deciding what to build are worth something separately. Put together in the right order they become a house, which is worth more than the parts. That difference is the reason business activity exists at all.

It exists in a second sense too. People specialise: a nurse nurses, a mechanic repairs vehicles, and neither grows their own maize or sews their own clothes. Each sells one kind of effort and buys the rest, which is why a bakery in Ongwediva can sell two thousand loaves a day when no household could eat more than a few. Specialisation creates the exchange that business activity lives on.

### Purpose is not the same as profit

The purpose of business activity is to satisfy wants and needs by turning resources into output customers value more highly than the money they give up for it. That is the general purpose. The particular purpose of any one business depends on who owns it.

Privately owned firms usually pursue profit for their owners. State-owned and public-sector organisations - a national broadcaster, a water utility, a state hospital - pursue a service objective set by government, and may be required to serve routes or areas a profit-seeking firm would leave. Social enterprises pursue a social or environmental aim, such as employing people with disabilities or restoring rangeland, while still needing to cover their costs, because an organisation that spends more than it takes in cannot continue whatever its aims.

What every one of them has in common is the need for revenue. Revenue from customers is what pays for the resources a business uses. So a business producing something customers do not want, or cannot afford at the price charged, tends to exhaust its money and stop trading - and that is true of a social enterprise and a state corporation as much as of a shop, even where a subsidy postpones the day it happens.

### The four factors of production

Everything a business uses to produce is classified into four factors.

**Land** means the natural resources a business uses: the site it occupies and the water, minerals, timber, grazing, fish stocks and climate it draws on. For a Namibian pilchard cannery, land is the fishing grounds off Walvis Bay as much as the plot the factory stands on.

**Labour** means the human effort, physical and mental, that people supply in producing goods and services. The welder and the accountant are both labour.

**Capital** means the man-made resources used to produce other goods and services: machinery, vehicles, buildings, tools and equipment. In this sense capital is equipment, not money. Money is what a business uses to buy capital, and confusing the two is the most common error on this objective.

**Enterprise** means the willingness and ability to bring land, labour and capital together, decide what to produce and how, and carry the risk that the venture makes a loss. Enterprise is the factor that organises the other three.

Production needs all four together. A site, equipment and workers with nobody willing to organise them and bear the risk produce nothing. But the proportions differ sharply by activity: a Namibian cattle farm is land-intensive, a call centre is labour-intensive, and a zinc refinery is capital-intensive. Knowing which factor dominates tells you where that business's costs sit and what kind of shock hurts it most.

### The four factors in one small business

A charcoal producer outside Otjiwarongo harvests invader bush, burns it in kilns and bags the charcoal for export.

Land: the bush itself and the farm it grows on. Labour: the eight harvesters and the two people who pack. Capital: the kilns, the chainsaws, the bagging equipment and the trailer. Enterprise: the owner, who decided that invader bush - a problem for grazing - could be sold as a product, found the buyer, raised the money for the kilns, and stands to lose that money if the buyer withdraws.

Take away any one and there is no output. Without the kilns the bush stays bush. Without the owner the bush, the workers and the kilns sit on the same farm producing nothing, because no one has decided what to do with them or accepted the loss if it goes wrong.

### Added value

Added value is the difference between the price a business charges for its output and the cost of the bought-in materials, components and services used to produce it.

**Added value per unit = selling price per unit - cost of bought-in materials and components per unit.** For a period, **total added value = sales revenue - cost of bought-in goods and services.**

A leather workshop in Okahandja buys hides, thread and fittings costing N$260 for each bag it makes, and sells the bag for N$690. Added value is N$690 - N$260 = N$430 a bag. If it sells 180 bags in a month, total added value is N$430 x 180 = N$77 400.

### Added value is not profit, and how a business raises it

The N$430 is not profit. Out of it the workshop pays the cutter and the stitcher, the rent on the workshop, the power, the insurance and the cost of getting the bags to the shops that sell them. Wages, rent, power, marketing, insurance and interest are all paid out of added value, and profit is what remains after all of them. A business can add a great deal of value per unit and still lose money, if what it pays for its own labour and premises is larger than the value it adds.

There are two routes to more added value, and they behave differently.

The first is to raise the price customers are willing to pay - through branding, quality, design, convenience or service. The workshop could stamp its name on the bag, guarantee the stitching for five years, or sell direct to tourists at the craft market rather than wholesale. This route works where customers see a difference worth paying for. Where they do not, higher prices tend to cost sales volume, and total added value can fall even though added value per unit has risen. If the price goes to N$760 and value added per bag to N$500, but monthly sales drop from 180 bags to 120, total added value moves from N$77 400 to N$500 x 120 = N$60 000. Per unit it looks like an improvement; in total it is a loss of N$17 400 a month.

The second route is to lower the cost of what is bought in: buying hides by the batch, cutting waste from the pattern, or finding another tannery at the same grade. This route does not depend on persuading customers of anything, which usually makes it the safer of the two, but it is limited by how low the input cost can realistically go.

### Scarcity, choice and opportunity cost

Economic activity is the use of scarce resources to produce goods and services. Resources are scarce in the sense that there are not enough of them to satisfy every want. That is not a statement about poverty - it is true of a mining company and of a household. Because resources are scarce, any use of a resource rules out another use, and choice cannot be avoided by consumers, businesses or governments.

**Opportunity cost is the benefit of the next best alternative given up when a choice is made.**

Three things follow from that wording, and each of them is a mark somewhere. Opportunity cost is the *next best* alternative, so it is one alternative, not the sum of all of them. It is the *benefit* given up, not the money spent. And it applies to every scarce resource, not only to money: a manager's time, a delivery vehicle and a shop's floor space all have opportunity costs.

### Identifying an opportunity cost

A hardware retailer in Rundu has N$400 000 available. It can buy a delivery vehicle, which it estimates would add N$150 000 a year in sales it currently loses to a competitor who delivers, or it can refit the shop floor, which it estimates would add N$95 000 a year, or it can settle a supplier account early and save N$40 000 in charges.

It buys the vehicle. The opportunity cost is the refit and the N$95 000 it would have brought - the next best alternative given up. It is not N$400 000, which is the money spent; and it is not N$95 000 plus N$40 000, because the retailer could not have had both.

Naming the alternative correctly is what makes the concept useful. If the retailer had ignored it and simply noted that the vehicle brings in N$150 000, it would have accepted any option showing a positive return. The question opportunity cost forces is a different one: not *does this earn something*, but *does this earn more than the best thing I could do instead*. A business that skips that question raises profit less than an alternative would have done, and the shortfall does not appear anywhere in its accounts - which is exactly why it is easy to miss.

### The dynamic business environment

The business environment is dynamic, meaning that the conditions a business trades in change over time rather than staying fixed. The conditions worth watching are these.

**Customers.** Tastes move and incomes move. A drought year cuts farm incomes, and a furniture shop in Grootfontein feels it two months later.

**Technology.** Mobile payment and online ordering have changed what a small retailer has to offer to stay convenient.

**Competitors.** A new entrant, a price cut or a merger changes what a business can charge.

**Law and regulation.** Minimum wage rules, licensing, food-safety standards and environmental conditions alter costs and sometimes what may be sold at all.

**The economy.** Interest rates change the cost of borrowed money; inflation raises input prices; exchange rates change what imports cost and what exports earn.

**Society.** Attitudes to plastic packaging, to how workers are treated and to where a product comes from move over years rather than weeks, and they move in one direction for long periods.

**The natural environment.** Rainfall, disease and fish stocks are trading conditions for a large part of Namibian business, not background scenery.

### How a change in the environment reaches a business

A change in the environment reaches a business through one of two doors: its revenue or its costs. Working out which door, and how wide it is, is the whole of the analysis.

The Namibian dollar is pegged one-for-one with the South African rand. A Namibian retailer buying stock from a Johannesburg wholesaler is therefore not exposed to a rate movement between those two currencies at all. But when the rand falls against the US dollar or the euro, goods bought from outside the Common Monetary Area - a Chinese-made appliance, a European spare part - cost more in Namibian dollars, and that comes through the cost door.

How much it matters depends on exposure. Take two Windhoek businesses in the same week. A hair salon buys almost everything locally and employs eight people; a 15% rise in the cost of imported appliances touches a small part of one year's spending. An electronics dealer whose entire stock is imported sees the same 15% land on most of its cost base, and either raises prices into a market that may not follow or absorbs it and watches its margin narrow.

So the chain runs: the external change occurs, it reaches the business through revenue or costs, the size of the effect is set by how much of that business's sales or spending is exposed to it, and the consequence for profit follows from there. A business that monitors the change and adjusts what it offers - resourcing locally, repricing, hedging a contract - tends to keep more of its customers than one that does not.

### Why businesses succeed or fail

Businesses that succeed tend to have five things: a product customers want at a price they will pay, enough cash to meet obligations as they fall due, managers with relevant experience, costs low enough to leave a margin, and the willingness to change what they offer as the market changes. None of the five is sufficient alone, and the second is the one most often underestimated.

The common causes of failure are the mirror image, with one addition. Running out of cash. A weak or mis-researched market - the product is fine and not enough people want it. Inexperienced management. Uncontrolled costs. Expanding faster than the business can finance, which is how a *growing* business fails. And an external shock: the loss of a major customer, a sharp fall in demand, a new competitor with deeper pockets.

Two qualifications matter more than the lists. First, failure usually has several causes acting together rather than one, which is why a single remedy - more finance, or a price cut - often does not save a failing business on its own; the finance buys time that is wasted if the market research was wrong. Second, new businesses fail more often than established ones, and for structural reasons: they have no trading record to raise finance against, no established customers to carry a bad month, and owners who are learning the market while spending money in it.

### Profitable and still failing: the cash chain

A business can be profitable and still fail, and the mechanism is worth being able to write out.

Profit is recorded when a sale is made, not when the money arrives. A small construction firm in Swakopmund completes a N$900 000 contract in March and records the profit on it in March. The client is a government department that pays at sixty days, so the cash arrives in late May. Meanwhile the firm paid its workers every Friday through February and March, and its builders' merchant expects payment at thirty days.

The chain: the cash goes out before it comes in; the bank balance falls below what is needed for wages; the merchant is paid late and puts the account on hold; without materials the next contract cannot start; without the next contract there is no further revenue to close the gap. The firm is profitable on paper the whole way down. It fails because it cannot pay what it owes when it is owed.

That is why cash and profit are treated as two separate questions about the same business, and why a cash-flow forecast is a survival document rather than an accounting formality.

### Local, national, international and multinational

A **local business** sells to customers in one town, settlement or district and usually operates from a single site - a butchery in Katutura, a guesthouse in Lüderitz.

A **national business** sells across the whole of one country, usually from several sites or through national distribution - a supermarket chain with branches in Windhoek, Walvis Bay, Oshakati and Katima Mulilo.

An **international business** is based in one country and sells to customers in other countries, typically by exporting. A Namibian beef processor shipping to the European Union is international: its abattoir is still in Namibia.

A **multinational business** owns or controls production or service operations in more than one country, rather than only selling into them. The test is where the operations are, not where the customers are. A business exporting to thirty countries from one factory is international; a business with two factories in two countries is multinational even if it sells in only those two.

These four are separated by the same dimensions, which is what makes them comparable at all: how far their customers are spread, whether they produce in more than one country, how much finance and management the operation needs, and how much exposure they carry to exchange rates, foreign law and foreign competition.

### What changes when a business crosses a border

Follow one business up the scale. A meat processor starts as a butchery serving one suburb of Windhoek: one site, local customers, the owner doing the buying. It opens branches in four towns and becomes national: it now needs refrigerated transport, a buying office, managers it does not see every day, and enough finance to hold stock in four places.

It wins an export contract into the European Union and becomes international. New demands arrive at once: veterinary certification to a foreign standard, a foreign customer whose payment terms it cannot dictate, and revenue in euro against costs in Namibian dollars, so a movement in the exchange rate changes the value of a sale already made.

It then buys an abattoir in Botswana and becomes multinational. Moving from exporting to producing abroad raises both the potential market and the demands on the business: more finance, more managers, more than one legal and tax system to comply with, and exchange-rate exposure on costs as well as on revenue. The upside is real - closer to Botswana cattle, inside a second country's trade arrangements, less dependent on one national market. So is the downside: a management problem in a country the owners visit four times a year, and the risk that a decision taken in Windhoek does not fit conditions in Lobatse.

### Common errors

**"Capital means money."** Not as a factor of production. There capital means the man-made resources used in producing something else - the kiln, the vehicle, the building. Money is how a business obtains capital, and calling money a factor of production loses the mark.

**"Added value is profit."** It is what is left after the cost of bought-in materials and services, before wages, rent, power and everything else the business pays. Profit is what remains after those too.

**"Opportunity cost is what you spent."** It is the benefit of the next best alternative you gave up. Spending N$400 000 on a vehicle has an opportunity cost of whatever the best other use of that money would have returned, which may be far less than N$400 000 or far more.

**"A multinational is just a big exporter."** A multinational owns or controls operations in more than one country. Selling into a country is exporting; producing in it is what makes the business multinational.

**"A profitable business is a safe business."** Profit is recorded when a sale is made. Cash arrives when the customer pays. A business can record profit every month and still be unable to pay wages on Friday.

### Where this connects

Added value is used again in 4.1, where operations are judged by how much value they add. The four factors of production reappear there as the inputs a production process organises. Opportunity cost runs through every investment and finance decision in topic 5. The dynamic environment is developed in 1.5, external influences on business activity, and the difference between cash and profit is set out formally in 5.1. Business size and the local-to-multinational scale connect to 1.3, enterprise size and growth.

---

## Entrepreneurs, intrapreneurs, risk and the development of a country

### Entrepreneur and intrapreneur

An **entrepreneur** is a person who sets up and runs a business, supplying the enterprise factor of production and bearing the financial risk of whether it succeeds.

An **intrapreneur** is an employee who develops new products, processes or ventures inside an existing business, using the employer's resources, with the employer carrying the financial risk.

The two definitions differ in one place: who stands to lose the money. That single difference explains most of what follows about them.

### The qualities, and what each one is for

The qualities associated with success in both roles are much the same list: spotting an opportunity others have missed, creativity, willingness to take calculated risks, determination through setbacks, self-confidence, organisation, and the ability to persuade other people. A list on its own earns very little. What each quality is *for* is the part worth learning.

**Spotting an opportunity** is noticing an unmet want, or a want met badly. The Otjiwarongo charcoal producer saw a product in invader bush that other farmers saw as a problem.

**Creativity** turns the opportunity into something specific that can be sold - a service, a price, a way of delivering it.

**Calculated risk-taking** is a business quality where it is calculated rather than blind. Committing money without researching whether customers want the product is gambling, and what distinguishes successful entrepreneurs is judgement about which risks are worth taking, not appetite for risk in general.

**Determination** matters because early trading is mostly refusals: a supplier who will not open an account, a landlord who wants three months in advance, customers who say they will come back.

**Self-confidence and persuasion** are what convert other people's resources into the venture - a supplier's credit, an employee's willingness to join something unproven, a provider of finance's money.

**Organisation** is the unglamorous one and the one that keeps a business alive: stock ordered before it runs out, invoices sent the week the work is done, tax returns filed on time.

### The same qualities, different obstacles

The two roles need the same qualities pointed at different obstacles.

An entrepreneur has to persuade people outside the business: customers who have never heard of it, suppliers deciding whether to grant credit, providers of finance deciding whether to commit. If it fails, the entrepreneur stands to lose personal savings, and often assets pledged as security.

An intrapreneur has to persuade managers inside the business to release budget and time, which means arguing against other internal claims on the same money and working within procedures written for the existing business rather than the new one. If the project fails, the intrapreneur risks reputation and promotion rather than personal savings.

Two consequences follow. The intrapreneur's tolerance has to include internal politics and delay, which the entrepreneur can simply overrule. And the entrepreneur's appetite for risk has to be matched by a capacity to absorb loss that the intrapreneur does not need, because the employer absorbs it instead.

### What entrepreneurship does at start-up

Entrepreneurship is what turns an idea into a trading business. Concretely, the entrepreneur identifies an unmet want, decides what to produce and how, assembles land, labour and capital, provides or raises the finance, and takes responsibility for the outcome. After suppliers, employees and lenders have been paid, the entrepreneur takes what is left - which may be a profit, nothing, or a loss. That last position, being paid last, is what is meant by bearing the risk.

The economic point behind it is that entrepreneurship raises output that would otherwise not exist. A vacant plot, an unemployed school-leaver and an idle vehicle produce nothing while they sit apart. They produce only once somebody combines them and accepts the consequences of the combination not working. That is why enterprise is described as the factor of production that organises the other three rather than as simply a fourth item on the list.

Finance shapes the whole of the start-up phase. Because a start-up has no trading record, the entrepreneur's own savings, family money and personal reputation often carry the business until sales are established, and providers of external finance may ask for security or evidence of demand before committing.

### From idea to trading business

The usual route runs in this order, and the order matters because each stage supplies what the next one needs.

1. **Identify the opportunity** - the unmet want and the customers who have it.
2. **Research the market** - how many such customers there are, what they pay now, who already serves them.
3. **Write a business plan** - the research turned into forecasts of sales, costs and cash.
4. **Raise the finance** - own savings, family, a bank, a development fund or an investor, in the amount the plan showed was needed.
5. **Choose and register a legal form** - sole trader, partnership or company, with the registrations, licences and tax numbers that go with it.
6. **Obtain premises, equipment, stock and staff** - the land, capital and labour the plan costed.
7. **Begin trading**, and compare what happens with what the plan forecast.

Stages 2 and 3 are the ones most often skipped, and skipping them moves the moment of discovery. The flaw that market research would have found in week three is then found in month eight, after the equipment has been bought.

### Intrapreneurship and the ongoing success of a business

Intrapreneurship contributes to the ongoing success of an established business by producing new products, services and working methods from employees who already understand its customers, its operations and its constraints. That knowledge is the advantage: an outsider with the same idea has to learn in a year what the employee already knows. It also helps to retain ambitious employees who might otherwise leave to start their own business - and who, if they leave, may compete.

The defensive argument is as strong as the creative one. A business selling the same products year after year is exposed when tastes or technology move, so innovation generated inside the business reduces the risk of being overtaken by a competitor that moves first.

There is also a cost argument. Developing an idea inside an established business spreads its cost across an operation that already has customers, premises and cash flow, so a failed experiment is absorbed rather than fatal. That is the real difference between an intrapreneur's failed project and an entrepreneur's failed business: the same wrong idea ends a career step in one case and a livelihood in the other.

None of this is automatic. Intrapreneurship happens where management provides time, a budget and tolerance of experiments that do not work. Where every failure is punished, employees tend to stop proposing anything untried, and the business keeps the appearance of innovation - a suggestion scheme, an innovation day - without the substance.

### Intrapreneurship at a Namibian insurer

A short-term insurer in Windhoek settles motor claims by asking customers to bring three written quotations to a branch. A claims assessor who has handled the queue for six years proposes that customers photograph the damage on a phone and send it to a single assessment desk, with approved repairers quoting from the photographs.

The idea comes from inside for a reason. The assessor knows which claims are small enough to settle on a photograph, which repairers can be trusted to quote honestly without seeing the vehicle, and that the three-quotation rule was written when photographs were not available. Nobody outside the claims hall knows all three of those things.

What the insurer had to supply is equally specific: eight weeks of the assessor's time away from the queue, a budget for the assessment desk, and a decision in advance that if the pilot raised fraud losses it would be stopped without the assessor being blamed for it. Take away the third and the assessor would rationally have kept the idea to themselves.

### Barriers to entrepreneurship

The main barriers are these: lack of finance and of security to offer against it; lack of business skills and experience; lack of a researched idea; fear of failure, which is stronger where failure carries social stigma; the time and cost of meeting registration, licensing and tax requirements; competition from established businesses; and weak infrastructure such as unreliable power, transport or internet.

Three of them repay a closer look because they carry mechanisms rather than just names.

**Finance.** A new business has no trading record. A provider of finance judges repayment on evidence, and with little evidence it may decline, may offer less than the amount needed, or may ask for security the entrepreneur does not have. Being offered part of what is needed can be worse than being refused, because a half-financed venture buys the premises and runs out of money before the stock arrives.

**Established competitors.** Their larger scale gives them a lower cost per unit, recognised brands and existing supply agreements, so a new entrant may have to accept a thinner margin or find a segment the incumbents serve poorly. That second route - the segment served badly - is how most small entrants actually get in.

**Opportunity cost.** Starting a business means giving up a known income for an uncertain one. This weighs most heavily on a person supporting a household, which is one reason entrepreneurship is commoner among the very young, who have fewer dependants, and among people with a second income in the home.

Barriers can be lowered rather than removed - through training and mentoring, government or development-bank finance schemes aimed at start-ups, simplified registration, and incubators that share premises and advice. Which barrier binds hardest differs from one entrepreneur to the next, and that is what makes a general remedy less effective than it looks: finance schemes help the person whose only obstacle was money, and do nothing for the person who has not tested the idea.

### Risk and uncertainty

**Risk** is a possible outcome whose likelihood can be estimated from experience or data, so it can be planned for, insured against or reduced.

**Uncertainty** is a possible future event whose likelihood cannot meaningfully be estimated, because there is no comparable experience to judge it from.

The two are separated by whether a likelihood can be attached. A bakery whose records show that about 6% of loaves go unsold each day faces a risk it can price for: it bakes with that 6% in the costing, or reduces it by baking twice. The chance that a new disease closes the border next year is an uncertainty, and no percentage can honestly be put on it.

**Business risk** has a narrower meaning again: the variability of a business's returns caused by the ordinary conditions of trading - demand, competition, costs and operations. It falls on the owners, because they are paid after suppliers, employees and lenders. An employee's wage does not move with this month's sales; the owner's return does.

### Risk and uncertainty for one tour operator

A tour operator running four-day trips into the Namib has both, and treats them differently.

Risks it can estimate: a vehicle breakdown, from its own maintenance records; a proportion of bookings cancelled late, from three seasons of data; a guide falling ill. It reduces the first with a service schedule, prices the second into a deposit policy, and transfers part of the third by keeping a freelance guide on call. Where a likelihood can be estimated, the tool is calculation - insurance premiums, deposits, spare capacity.

Uncertainties it cannot: whether a border closure, a currency collapse in a source market, or a change in European flight routing removes a third of its customers next year. There is no record to put a percentage on any of them. The tools are different in kind - cash reserves large enough to survive a season at half capacity, short vehicle-hire agreements rather than long ones, and a second market developed among domestic customers so that no single source country carries the business.

The general rule follows. Businesses handle risk by reducing it through research, maintenance and quality control, transferring it through insurance and fixed-price contracts, spreading it across several products or markets, and holding cash reserves. Uncertainty cannot be estimated, so it is handled by keeping flexibility and reserves rather than by calculation.

### How enterprise contributes to the development of a country

Business enterprise contributes to a country's development by creating jobs and incomes, raising output, generating tax revenue, using local resources, earning or saving foreign currency, and building skills in the workforce. Two of those repay being traced through.

**The income chain.** Employment created by new businesses raises household incomes. Those incomes are spent in local shops and services, which supports further businesses and further jobs, whose wages are spent in turn. The initial effect is multiplied through the local economy, and the multiplication is larger where the money is spent locally rather than on imports.

**The revenue and value chain.** Enterprise widens the tax base: profitable businesses pay tax and their employees pay tax on earnings, which funds the schools, clinics and roads a developing economy needs. Alongside that, a business that processes a local raw material instead of exporting it unprocessed keeps more of the added value inside the country. Exporting raw hides earns the price of hides; tanning them and exporting finished leather earns that price plus the value the tannery adds, and the wages of the people who add it.

The size of all this depends on conditions, and the conditions are where the analysis earns its marks. The effect is larger where the businesses survive and grow rather than closing within two years, where they employ and train local people rather than importing staff, where profits are reinvested in the country rather than removed from it, and where the activity does not exhaust the resources other livelihoods depend on - the grazing, the fish stock, the water.

### Common errors

**"Risk and uncertainty are two words for the same thing."** They are separated by whether a likelihood can be estimated. A risk can be priced, insured or reduced by calculation; an uncertainty can only be prepared for by keeping reserves and flexibility.

**"An intrapreneur is just a good manager."** A manager runs the existing operation well. An intrapreneur develops something the business was not doing before, using the employer's resources and at the employer's financial risk.

**"Entrepreneurs are people who like taking risks."** The quality that is rewarded is judging which risks are worth taking. Committing money without researching demand is gambling, and it fails more often than it succeeds.

**"The barrier to entrepreneurship is money."** Finance is one barrier and it binds hard, but a person with money and no researched idea, no skills and no time is not closer to trading than a person with the idea and no money. Which barrier binds hardest differs by person.

**"Any new business helps the country develop."** The development effect depends on survival, on who is employed, on whether profits stay in the country, and on whether the activity exhausts the resources other people live on.

### Where this connects

The finance a start-up needs and the forms it can take are the subject of 5.2. Legal forms - sole trader, partnership, company - are in 1.2. Motivation of the people an intrapreneur has to work with is in 2.2, and organisational structures that encourage or block internal innovation are in 2.1. Business enterprise and national development connects forward to 1.5, external influences on business activity, and the qualities discussed here reappear in 2.3 as leadership.

---

## Business plans

### What a business plan is

A business plan is a written document setting out what a business intends to do, how it intends to do it, who will do it, and what financial results it expects, usually covering the first one to three years.

It is a forecast, not a record. Nothing in it has happened yet, which is both what makes it useful and what limits it.

### What a business plan is for

A business plan serves two audiences, and a plan written for only one of them usually serves that one badly too.

**Inside the business** it forces the owner to think the idea through and provides targets to manage against. Writing 'we will sell 400 units a month' obliges somebody to say who is buying them and at what price, and that question is much harder to avoid on paper than in conversation.

**Outside the business** it gives providers of finance the evidence they need to judge the proposal. A bank, a development fund or an investor is deciding whether the business can repay or return what it takes, and the plan is the document that argument is made in.

Writing the plan reduces risk because the research it requires can expose a fatal flaw - no market at the price assumed, a cost not allowed for, a month when cash runs out - while that flaw still costs only the time spent finding it. A plan that ends with the founder deciding not to proceed has done its job.

A plan is also a control document. Once trading begins, actual sales, costs and cash are compared with the forecasts in it, and a gap between the two is a signal to investigate rather than a verdict on its own: sales 20% below forecast may mean the market is smaller than assumed, or that the promotion started a month late. The plan tells the owner where to look, not what the answer is.

### The key elements, and why each is there

A business plan normally contains:

- an **executive summary**;
- a **description of the business** - its name, location, ownership, legal form and objectives;
- the **product or service** and what distinguishes it from what customers can already buy;
- **market research** on customers, market size and competitors;
- a **marketing plan** - price, promotion, distribution and product decisions;
- an **operations plan** - premises, equipment, suppliers, production method and staffing;
- the **management team** and the experience they bring;
- **financial forecasts**;
- the **finance required** and what it will be used for;
- the **main risks** and the steps planned to handle them.

The financial forecasts normally include start-up costs, a forecast of revenue and costs, a cash-flow forecast month by month, and a break-even calculation. The month-by-month cash-flow forecast is the part a provider of finance reads most closely, because it shows the month in which the business is at its lowest point and therefore how much finance it actually needs.

The executive summary is written last and read first: in about a page it states what the business is, what it needs and what it expects, so that a reader can decide whether to read further. Writing it first produces a summary of a plan that does not exist yet.

### Why the market research section carries the plan

The sections are not equally load-bearing. The market research section carries the weight of the plan because the sales forecast rests on it, and the sales forecast drives the revenue figure, the cash-flow forecast and the amount of finance requested. A sales figure with nothing behind it makes every later number unsupported too.

Trace it. A car wash planned for a Windhoek industrial area forecasts 40 vehicles a day at N$90. That gives daily revenue of 40 x N$90 = N$3 600, and monthly revenue over 26 trading days of N$3 600 x 26 = N$93 600. The cash-flow forecast uses that N$93 600 to show the business covering wages, water and rent from month two, and the plan therefore asks for N$185 000 of finance rather than N$260 000.

Now suppose the 40 vehicles came from the founder's impression rather than from counting. If the real figure is 26 vehicles a day, monthly revenue is 26 x N$90 = N$2 340 a day, so N$2 340 x 26 = N$60 840 a month - a shortfall of N$32 760 every month against the forecast. The cash-flow forecast that showed break-even in month two now shows a deficit in every month, and the N$185 000 requested was never enough. One unsupported number at the top made four numbers below it wrong, and the business discovers this after the equipment is installed.

That is the argument for counting vehicles for a fortnight before writing the figure down.

### The benefits of writing a plan

Four benefits, each worth stating with its mechanism rather than as a heading.

**It forces research before money is committed.** The discipline is in the order: the plan cannot be finished without a sales figure, and a sales figure cannot be written honestly without finding out who buys and at what price.

**It strengthens the case put to providers of finance.** A provider of finance is assessing whether the business can repay. A plan showing researched demand, costed operations and a month-by-month cash-flow forecast gives them evidence on which to judge, and its absence leaves them judging on very little - which usually means a smaller amount offered, a higher price for it, or more security demanded.

**It sets targets for monitoring.** Forecast figures become the benchmark against which the first year is measured, so problems are noticed in month two rather than at the year end.

**It coordinates the people involved.** Where two or three people start a business together, the plan is where they discover that they had different businesses in mind - before they have spent money on both.

### The limitations of a plan

**Its forecasts rest on assumptions that may be wrong.** A plan is a set of estimates about the future, and the arithmetic inside it is only as reliable as the market research underneath it. Confident presentation does not make an assumption true.

**It dates quickly in a changing environment.** A competitor opens, a supplier's price moves, a regulation changes, and the forecasts were built on conditions that no longer hold. A plan that is not revised becomes a description of a business that was never started.

**Preparing it takes time and money a small start-up may not have.** Several weeks of the founder's time is a real opportunity cost: it is time not spent selling, and for a very small venture that trade-off can go either way.

**A well-written plan can create confidence the underlying business has not earned.** The document and the venture are different things, and a plan written mainly to obtain finance tends to carry optimistic figures. Those figures then make a poor benchmark for managing the business, so the same document can satisfy the provider of finance and mislead the owner - who compares actual sales against a forecast that was never a serious estimate, and concludes the business is failing when it is merely behind a number invented to impress.

### Is a full written plan worth the effort?

Whether a full written plan is worth the effort depends on what it is for.

Where external finance is sought, the question mostly answers itself: a plan is usually required, and the effort is unavoidable. The judgement there is not whether to write one but how honest to make the figures, and the honest version is the more useful of the two afterwards.

Where the business is small, self-financed and able to change direction quickly, the case is genuinely open. A short plan kept current may be more useful than a long one that goes out of date and is never revisited. The decisive consideration is the size of the commitment being made: a venture that ties up N$400 000 and two years of a founder's life deserves the weeks of research, because the cost of discovering the flaw afterwards is the whole N$400 000. A venture that can be started on a weekend with N$8 000 of stock can test the idea in the market faster than a plan could test it on paper.

The strongest argument on the other side is that the weakest founders are the ones most confident they can skip the research, so the plan is most valuable precisely where it is least likely to be written. That is a reason to keep the discipline even for small ventures - but in the form of the three questions that do the work, which are who buys, at what price, and in which month does the cash run lowest.

What would change the judgement: a lender's requirement, a partner joining who needs to see what they are joining, or a commitment large enough that the loss from a wrong assumption exceeds the cost of the research.

### Common errors

**"A business plan is a forecast of profit."** Financial forecasts are one section of several. A plan that contains only numbers leaves the reader unable to judge whether the numbers mean anything, because the evidence for them sits in the market research.

**"A business plan makes the business certain to succeed."** It does not. It reduces the chance of proceeding on a flawed idea, and it improves the case put to providers of finance, but the forecasts in it are assumptions about a future nobody has seen.

**"Once the plan is written the job is done."** A plan dates. Its value after start-up comes from being compared with what actually happened and revised.

**"The executive summary is the introduction."** It is a summary of the finished plan, written last, and it is what decides whether the rest is read.

### Where this connects

The marketing section of a plan is topic 3 in miniature - market research in 3.1, the marketing mix in 3.3. The operations section draws on topic 4, and the financial forecasts on topic 5: cash-flow forecasting in 5.1, sources of finance in 5.2, budgets in 5.3 and break-even in 5.4. The risks section returns to the distinction between risk and uncertainty made in 1.1.2.

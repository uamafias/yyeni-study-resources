# 2.2 Motivation

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain what motivation is, and explain why a business needs motivated employees if it is to achieve its objectives.
- Explain in simple terms what a human need is and how an unmet need affects behaviour, and explain how work may or may not satisfy the needs of the people who do it.
- Explain the ideas of the content theories of Taylor, Mayo, Maslow, Herzberg and McClelland and of Vroom's process theory, and analyse what each of them implies for how a business should treat its employees.
- Apply the motivation theories to practical situations; explain and evaluate the payment methods a business can use - time based, salary, piece rates, commission, bonuses, profit sharing, performance-related pay and fringe benefits; explain and evaluate the non-financial motivators - training, promotion opportunities, development, status, job re-design, team working, empowerment, participation and job enrichment; and analyse the ways in which employees can participate in the management and control of business activity.

---

## Why a business needs motivated employees

### What motivation means

**Motivation** is the willingness of a person to put effort into their work, and the set of reasons behind that willingness.

Two halves are doing work in that sentence. The willingness is what the employer sees - how hard someone works, how carefully, how readily they deal with a problem nobody told them about. The reasons behind it are what the employer has to change if the willingness is to change, and they are not visible at all.

### Why this matters more for labour than for anything else the business buys

A business buys several inputs, and labour behaves differently from the rest.

A machine hired for eight hours delivers eight hours of capacity. A tonne of cement delivers a tonne. But an employee paid for eight hours delivers somewhere between the least that avoids trouble and the most they are capable of, and where in that range they actually work is what motivation decides. That range is the whole reason the subject exists: it is the one input whose output the business cannot fix by writing a cheque.

### How motivation reaches the business objectives

Motivation does not touch profit directly. It travels through channels, and each channel has a figure attached to it that a business can actually read:

- **Productivity** - output per employee per period.
- **Absenteeism** - the working days lost to unplanned absence.
- **Labour turnover** - the proportion of the workforce leaving and needing replacement.
- **Quality of work** - reject rates, rework, customer complaints.
- **Improvement ideas** - proposals from employees that the business can use.

They move separately. A bonus for output may lift productivity and leave absence exactly where it was, so a business that introduces one method and reads only one figure has not found out very much.

The productivity channel carries clear arithmetic. A workshop paying N$96 000 a month in wages and producing 4 000 units has a labour cost of N$96 000 / 4 000 = N$24 a unit. Raise output to 4 800 units with the same workforce and the same wage bill and the figure becomes N$96 000 / 4 800 = N$20 a unit. Where the extra 800 units can be sold, that N$4 a unit widens the gap between price and cost.

The turnover channel carries its own costs: advertising and selecting a replacement, training them, and the output lost while the new person learns the job. Those costs arise each time a post turns over, so a business with persistently high turnover pays for the same post repeatedly.

### A call centre in Windhoek

A contact centre employs 40 agents on permanent contracts. Unplanned absence runs at 9% of scheduled days, and the centre works 22 days a month, so the days lost are 40 x 22 = 880 scheduled days, of which 880 x 0.09 = 79.2 days are lost each month. Cover is bought from an agency at N$950 a day, which costs 79.2 x N$950 = N$75 240 a month.

After the centre gives team leaders responsibility for their own rosters and starts publishing each team's service figures, absence settles at 5%. Days lost become 880 x 0.05 = 44, and the agency bill becomes 44 x N$950 = N$41 800 - a saving of N$33 440 a month.

Notice what carried the saving. Not the abstraction 'happier staff', but one measured channel, absence, with a rate and a price attached to it. That is what an answer about motivation has to reach to be worth marks: a named channel, a mechanism, and where possible a figure.

### What motivation cannot do on its own

Willingness raises output where the employee also has the skill, the equipment, the materials and the authority to act on it. A motivated machinist whose machine is broken produces nothing. A motivated clerk who must refer every decision upwards works at the speed of the person above.

So motivation is one determinant of productivity among several, and a business that raises it while leaving training, equipment and decision rights untouched may see very little change in the figures. In an evaluation question this is usually the strongest counterargument available: the proposed motivation method may be answering a need that was not the binding constraint.

The objectives being served also depend on what the organisation is for. A private firm may be pursuing survival, profit, growth or market share. A state-owned utility or a public hospital may be pursuing service targets and cost control with no profit objective at all. The link runs the same way in both: employee effort determines how much of the work gets done, and to what standard.

### Common errors

**"A satisfied workforce is a motivated workforce."** Not the same thing. A contented employee may be comfortable precisely because the job asks little of them, and a highly motivated one may be dissatisfied with their pay while still working hard at a task they care about. A survey of how happy staff say they are has not measured effort.

**"Pay people more and they work harder."** Money answers the needs that can be bought. It leaves untouched the need to be respected, to belong and to grow, which is why a business can raise wages and still watch its most capable people leave for work that interests them more.

**"Motivation is the manager's personality."** Motivation methods are decisions about pay, job content, responsibility and voice. They can be described, costed and evaluated, which is what this topic asks for.

### Where this connects

The needs that motivation works on are set out in 2.2.2, the theories that explain them in 2.2.3, and the methods a business actually uses in 2.2.4. Labour productivity as an operations measure belongs to 4.1, and the business objectives that motivation serves are defined in 1.3.

---

## Human needs, and how work meets them

### What a need is

A **human need** is something a person requires or strongly desires, whose absence creates a tension the person acts to remove.

The second half is the part that matters to a business. A need is not simply a preference sitting in someone's head; it produces action. What an employer observes as behaviour at work - turning up, working hard, applying for another job, asking for a transfer - is a person acting to remove a tension.

### How a need drives behaviour, and then stops

An unmet need directs behaviour towards meeting it, and the stronger the need, the more of a person's attention and effort it takes up. Someone who cannot pay rent thinks about money in a way that someone whose rent is paid does not.

The second half of the mechanism is the one businesses forget. Once a need has been largely met it tends to lose its power to direct behaviour, and another need moves into its place as the one pressing hardest. This is why a reward that changed someone's behaviour two years ago may do little today: nothing about the reward has changed, but the need it answered has been met, and the employee's attention has moved on.

### The range of human needs

Human needs run across a range, and it is useful to hold the range in mind before meeting any theory that arranges it:

- The **physical** requirements of staying alive - food, water, warmth, shelter, rest.
- The need to feel **safe and secure** - shelter from danger, and some confidence about tomorrow.
- The need to **belong** - company, acceptance by a group, friendship.
- The need for **respect** - to be thought well of by others, and to think well of oneself.
- The need to **grow** - to develop and use one's abilities.

Which of these presses hardest differs between people and changes across a life.

One distinction is worth keeping straight. A need in this sense is a requirement a person acts to satisfy; a **want** is a preference about how to satisfy it. Two employees may share the same need for security and want quite different things - one a permanent contract, the other a medical aid scheme for a sick relative. An employer works with wants, because wants are what can be offered; but it is the need underneath that explains why the offer changes behaviour.

### How work satisfies needs - by two different routes

Work meets needs by two routes, and keeping them apart prevents a lot of confusion.

**Indirectly, through pay.** The money itself meets nothing. It buys food, housing, transport and school fees, and it can be saved against future trouble. Everything pay does for a person's needs, it does outside the workplace.

**Directly, through the job.** The company of colleagues, the standing a role carries, the interest of the work and the sense of having done something well are received at work. No wage buys them elsewhere.

Matching the features of a job to the needs they answer:

- Wages and a guaranteed minimum of hours answer **physical** needs.
- A permanent contract, safe conditions, sick pay and a pension answer **security** needs.
- Working alongside others, team tasks and social facilities answer the need to **belong**.
- A job title, recognition and promotion answer the need for **respect**.
- Demanding work, training, responsibility and freedom over how the job is done answer the need to **grow**.

### How work may fail to satisfy needs

The failures line up against the same list, which makes them easy to diagnose.

Pay below what local prices require leaves physical needs unmet. Short or casual contracts, and conditions that are unsafe, leave security needs unmet. Isolated or heavily supervised work leaves social needs unmet. Work whose results go unnoticed leaves the need for respect unmet. A job that repeats one narrow task with no route out of it leaves the need to grow unmet.

A single job may do some of these well and others not at all: a well-paid, permanent post can leave someone with no company and nothing to stretch them, and a fascinating job on a three-month contract can leave someone unable to plan.

Two further points complete the picture. First, the same job meets needs differently for different employees, because each arrives with a different need pressing hardest. A student working weekends at a lodge may value the flexible hours and the company of other young staff and care little about a pension; a parent supporting a household from the same job may value the guaranteed hours and the medical aid above everything else. One reward offered to both is likely to change one person's behaviour more than the other's.

Second, work is not the only place needs are met. An employee may find company through family, church or sport, and may use their abilities fully in something they do outside working hours. Where that is so, the same workplace reward - a social club, a demanding project - carries less weight for them than for someone whose main source of company or challenge is the job.

### Two employees, one lodge

A lodge outside Swakopmund employs 30 staff on the same terms: N$7 200 a month, shared accommodation, one meal a shift.

Petrus is 19, lives in town with his family and is saving for a college course. What is unmet for him is the need to grow and the wish to get on. An offer of paid training in food preparation, and the prospect of a supervisor's post, reaches something the wage does not.

Selma is 41 and the only earner for four dependants. Her binding constraint is the household budget and the fear of the contract ending. For her, the same training offer is pleasant but secondary; what would change her behaviour is a permanent contract, medical aid, or hours she can rely on.

One employer, one wage, one set of conditions, two different unmet needs. That is the practical content of this section, and it is the reason the next section has six theories in it rather than one rule.

### Common errors

**"Needs and wants are the same."** They are not. The want is the particular thing asked for; the need is what it is asked for. Offering a different thing that answers the same need often works.

**"If the pay is good the needs are met."** Pay answers the needs that money buys. Company, standing and growth are received at work or not at all.

**"Everyone at the same pay grade has the same needs."** People at identical rates of pay can have quite different circumstances, which is why one motivation method rarely does the same work across a whole workforce.

### Where this connects

Maslow's hierarchy in 2.2.3 takes the range of needs set out here and claims an order for it. Herzberg's two-factor theory takes the distinction between what surrounds a job and what the job contains. The methods set out in 2.2.4 are attempts to answer one or another of the needs described here.

---

## The motivation theories

### Two different questions

The six theories in this section answer two different questions, and knowing which question a theory is answering stops most of the confusion between them.

A **content theory** asks *what* motivates people - which needs or rewards make effort worthwhile. Taylor, Mayo, Maslow, Herzberg and McClelland are content theories.

A **process theory** asks *how* motivation comes about - the thinking that turns a reward on offer into effort actually given. Vroom's expectancy theory is the process theory this syllabus names.

The distinction is useful in practice as well as in an exam. A content theory tells a business what to put on the table; a process theory tells it whether what it has put on the table will be picked up.

### Taylor - scientific management

**The central idea.** Work should be studied and measured rather than left to custom; there is one most efficient way to perform any manual task; and employees are motivated mainly by money, so pay should be tied directly to measured output.

**The method, in order.** Observe and time how the task is done at present. Break it into its simple repeated elements and identify the quickest sound way to do each. Set a standard output from that. Select employees suited to the task and train them to the one method. Pay a piece rate that rewards output above the standard, and supervise closely to see the method is followed.

**Where it works.** Where a task is repetitive and its output can be counted and checked, the approach can raise output quickly: earnings rise with units produced, and the method has been simplified so that producing more is possible. It also makes the labour cost of each unit predictable, because pay moves with output rather than with hours.

**Where it fails.** It treats employees as instruments, so it takes no account of the need to belong, to be respected or to grow. It assumes money dominates, which holds better where pay is low relative to living costs than where it is not. Paying for speed can pull quality down unless inspection is added, and inspection costs money in its turn. Repetitive simplified work is associated with boredom and resentment. And the approach does not fit work whose output cannot be counted - nursing, teaching, design.

### Mayo - the human relations school

**Where the ideas came from.** The Hawthorne studies, carried out at an American electrical factory between 1924 and 1932. Groups of employees were observed while conditions such as lighting, rest breaks and hours were varied. Output rose under several different changes, and in some groups it stayed high when conditions were put back as they had been - so the physical changes alone did not explain the results.

**The central idea.** Employees are motivated by social needs as well as by pay: by belonging to a working group, by the attention and interest of managers, and by having a say in how their work is arranged. Work groups develop their own standards of what a fair day's output is, and those standards influence what individual members do.

**What follows for a business.** Organise work in teams rather than isolating individuals. Consult employees about changes that affect them. Give managers a role in listening as well as directing. Provide places and occasions for people to mix. Pay attention to the informal groups that form, not only to the formal structure.

**The limitations.** Group norms cut both ways: a group that decides a certain output is enough may hold back its faster members as firmly as it pulls up its slower ones, so team working can restrict output as well as raise it. The studies also rested on small numbers of employees in one factory in one country, and what caused the changes has been disputed ever since. They are better used as a reason to take social needs seriously than as a measured rule.

### Maslow - the hierarchy of needs

**The five levels**, drawn as a pyramid with the most basic at the bottom:

1. **Physiological** - food, water, rest, shelter.
2. **Safety** - security, freedom from danger, some confidence about tomorrow.
3. **Love and belonging** - acceptance by a group, friendship.
4. **Esteem** - respect from others, and self-respect.
5. **Self-actualisation** - the full use of a person's abilities.

**The rule that makes it a theory of motivation.** A level becomes a motivator once the levels below it are largely satisfied, and a need that has been satisfied loses its power to motivate. On this view, offering more of what an employee already has enough of changes little; offering the level they have not yet reached can change a great deal.

**Applied at work.** Identify the level an employee has reached and offer the matching reward: adequate wages and rest breaks for physiological needs; a permanent contract, safe conditions and a pension for safety; team work and social occasions for belonging; job titles, recognition and promotion for esteem; demanding work, training and freedom over how the job is done for self-actualisation.

**The limitations.** There is no reliable way to tell which level an employee has reached, so the diagnosis is a judgement. Not everyone moves up in the stated order: an artist or an entrepreneur may pursue self-fulfilment while security is still uncertain. Self-actualisation has no measure, so a business cannot tell whether it has provided it. And a single reward often answers several levels at once - a pay rise meets safety needs and, where it is publicly awarded, esteem as well.

### Maslow read against a real pattern

A supermarket chain in Windhoek has two problems at once. Its shelf-fillers, paid above the local going rate on permanent contracts, barely respond to a further wage offer. Its longest-serving supervisors, on the same terms, are leaving.

Read through the hierarchy, the shelf-fillers' physiological and safety needs are largely met, so more money is being added to a level that is already full and adds little. Belonging or esteem is the level to work on - team responsibilities, recognition for the section that runs best.

The supervisors say they have nowhere further to go. That is esteem and self-actualisation, not pay, and a further wage offer would answer a question they are not asking. What would answer it is a larger role, a project of their own, or a development programme leading to a management post.

The diagnosis is the work. Two sets of employees, one employer, one pay structure, two different levels - and therefore two different answers.

### Herzberg - the two-factor theory

**The split.** Herzberg separated the things at work that cause dissatisfaction when they are wrong from the things that produce positive motivation when they are present. The first group he called **hygiene factors**, sometimes called maintenance factors; the second group he called **motivators**.

**Hygiene factors**: pay, working conditions, company policy and administration, the quality of supervision, job security, relationships with colleagues. Getting them wrong causes dissatisfaction. Putting them right removes that dissatisfaction, which is not the same as producing enthusiasm - on this theory it brings an employee to neutral rather than to positive effort.

**Motivators**: achievement, recognition for achievement, the nature of the work itself, responsibility, advancement, personal growth. These arise from what the employee does rather than from the conditions surrounding it.

**The claim that gives the theory its force.** Satisfaction and dissatisfaction are not two ends of one scale but two separate scales. The opposite of dissatisfaction is no dissatisfaction, not motivation. It follows that a business which fixes the canteen, the conditions and the pay and then finds effort unchanged has not failed to spend enough - it has spent on the wrong scale.

**What Herzberg told businesses to do.** Enrich the job: give the employee a complete and identifiable piece of work rather than a fragment, the authority and responsibility to decide how it is done, and direct feedback on the result, so that achievement, responsibility and growth are built into the job itself. He distinguished this from simply adding more tasks of the same kind, which he regarded as changing the quantity of work rather than its quality.

**The limitations.** The evidence came from interviews with around two hundred professional employees, mostly accountants and engineers, so extending it to manual, casual or low-paid work is uncertain. The interview method invited people to attribute good episodes to themselves and bad ones to their surroundings, which may have produced the split rather than discovered it. And the line between the two lists is not clean: where pay is below what an employee needs to live on, pay behaves like a motivator, and pay awarded publicly for an achievement carries recognition with it.

### Herzberg tested against a disappointment

A fish-processing plant in Walvis Bay spends N$1 400 000 on a new canteen, new changing rooms and a 6% wage increase. Twelve months later, output per shift is where it was and the complaints have simply changed subject.

Herzberg's reading is that the money was spent on hygiene factors. Conditions and pay were genuinely poor, so the spending removed real dissatisfaction - which is worth having, and the plant should not conclude it wasted the money. But removing dissatisfaction is not the same as creating effort, and nothing in the programme touched achievement, responsibility, recognition or growth.

What the theory points to next costs far less: give each line team responsibility for its own quality checks and the authority to stop the line, publish each team's results, and let experienced packers train new ones. Whether that works is a separate question - if the plant's wages were still below what a household in Walvis Bay needs, the diagnosis would be wrong and pay would still be the binding constraint.

### McClelland - acquired needs

**The three needs.** McClelland held that three needs shape behaviour at work: the need for **achievement**, the need for **affiliation** and the need for **power**. He called them acquired because he held that they are learned through a person's experience and culture rather than being present from birth.

**What each looks like.** Someone in whom achievement is strong looks for goals that are demanding but reachable, wants personal responsibility for the result, and wants concrete feedback on how they did; the accomplishment matters to them more than the reward attached to it. Someone in whom affiliation is strong wants to be accepted and to keep relationships harmonious, and works well where cooperation matters. Someone in whom power is strong wants influence over outcomes and over other people.

**A mix, not a type.** All three are present in each person in some combination, so the theory is about which is dominant rather than about sorting people into boxes. The dominant need shapes both what motivates someone and the roles they are likely to do well in: a strongly achievement-driven employee may be an excellent individual performer and an impatient manager, while a manager who seeks influence for the organisation's sake rather than for personal standing may be more effective at directing others.

**Applied at work.** Match tasks and rewards to what drives the individual - a stretching individual target with quick, specific feedback for someone driven by achievement; a team role, mentoring or customer contact for someone driven by affiliation; responsibility for a project, a budget or a group of staff for someone driven by influence.

**The limitations.** Identifying which need dominates is difficult and subjective, so a manager may assign work on a misreading. The dominant need can change as circumstances change, so a diagnosis made once may not hold. And a small business may have no role available that matches what an employee is driven by, in which case the theory diagnoses a problem it cannot solve.

### Vroom - expectancy theory

**What kind of theory it is.** Vroom's expectancy theory does not list what people want. It explains how an employee decides how much effort to give: a person puts in effort when they expect that effort to produce the performance required, expect that performance to be rewarded, and place value on the reward offered.

**The three elements.**

- **Expectancy** - the belief that effort will actually produce the required level of performance. *Can I do it?*
- **Instrumentality** - the belief that reaching that performance will actually bring the reward. *Will they pay it?*
- **Valence** - how much the employee values that particular reward. *Do I want it?*

**How they combine.** By multiplication, not addition:

**motivational force = expectancy x instrumentality x valence**, each treated as a figure between 0 and 1.

Multiplying is the whole point. A near-zero value on any one element pulls the result to near zero. A generous reward the employee has no expectation of reaching motivates almost nothing; a reachable, reliably paid reward the employee does not want motivates almost nothing either.

**Using it on a scheme.** Test the three links separately. Is the target reachable by someone working hard, given their training and equipment? If not, raise expectancy by adjusting the target or the training. Does the reward reliably follow, and can the employee see the connection? If not, raise instrumentality by making the rule explicit and paying it when it is earned. Is the reward one this employee values? If not, raise valence by offering something they do.

**The limitations.** All three elements are beliefs held inside someone's head, so a business cannot measure them directly and has to infer them from what people say and do. The theory assumes a fairly deliberate weighing-up, which fits a decision about chasing an annual bonus better than it fits day-to-day effort. And it explains how a reward works without saying which rewards people value, so it is normally used alongside a content theory rather than instead of one.

### Vroom with numbers on it

A logistics firm in Walvis Bay offers its drivers a monthly bonus of N$3 000 for a delivery record with no late loads.

Drivers think the target is reachable in perhaps eight months out of ten, and the yard's scheduling is what costs them the other two, so expectancy is about **0.8**. The bonus has been paid whenever it was earned, so instrumentality is about **0.9**. The drivers value the money highly, so valence is about **0.7**.

Multiplying: 0.8 x 0.9 = 0.72, and 0.72 x 0.7 = 0.504. On a scale where 1 is the most the scheme could pull, that is real pull.

Now let the yard's scheduling worsen, so drivers believe the target is reachable only three months in ten. Expectancy falls to about 0.3. Nothing about the money has changed: 0.3 x 0.9 = 0.27, and 0.27 x 0.7 = 0.189. The same N$3 000 now carries about a third of the force it had.

The lesson for a business is that the cheapest repair is often not to the reward. Fixing the yard's scheduling costs nothing in bonus payments and restores most of the scheme's pull.

### What the six say about money

Comparing the theories on one question is the quickest way to hold them apart, and money is the question that separates them most sharply.

- **Taylor** - the main lever, provided pay is tied to measured output.
- **Mayo** - it matters, but social belonging and the attention of managers matter as well.
- **Maslow** - it answers the lower levels and loses force once those are met.
- **Herzberg** - a hygiene factor: its absence causes dissatisfaction, its presence does not by itself produce motivation.
- **McClelland** - one reward among three, and it suits an achievement-driven person mainly where it is read as a score.
- **Vroom** - it motivates where the target is believed reachable, the payment is believed to follow, and the money is valued more than the effort costs.

In practice a business uses them together rather than choosing between them: from Herzberg the instruction to correct pay and conditions before expecting enthusiasm; from Mayo and Maslow the case for team working and belonging; from McClelland the idea of matching tasks to what an individual is driven by; and from Vroom a test of whether the reward chain actually holds together.

### Using a theory outside the setting it came from

Each of these theories was developed from a particular workforce at a particular time - Taylor from steelworks labouring, Mayo from an American factory in the 1920s and 1930s, Herzberg from interviews with professional staff. How useful a theory is in a given business depends on how closely that business resembles the setting the theory came from.

That is not a reason to discard them. It is a reason to say, in an evaluation, which features of the business make the theory fit or not fit: whether output can be counted, whether pay is comfortably above what a household needs, whether the work is done alone or in groups, whether there is anywhere to be promoted to. An answer that names the theory and stops has done half the work; an answer that says why this business is or is not the kind of place the theory describes has done the other half.

### Common errors

**"Herzberg proved that pay does not motivate."** The claim is narrower than that. Correcting pay removes a reason for dissatisfaction without by itself producing positive effort. Where pay is below what an employee needs to live on it behaves quite differently, because the need it answers is still pressing.

**"Maslow says you must satisfy one level completely before the next one counts."** The stated condition is that the lower levels are *largely* satisfied, and the order is not fixed for everybody.

**"McClelland sorts people into three types."** All three needs are present in each person; the theory is about which is strongest.

**"Vroom is just another list of what motivates people."** It is the opposite: it says nothing about which rewards people want, and everything about whether a reward on offer will be chased.

### Where this connects

These theories are the reasoning behind the methods in 2.2.4: Taylor behind piece rates, Herzberg behind job enrichment, Mayo behind team working, Vroom behind the design of any bonus scheme. The needs they arrange were described in 2.2.2. The way managers behave day to day is treated in 2.3, which does not repeat these theorists.

---

## Motivation in practice: pay, non-financial methods and participation

### Putting a theory to work

A motivation theory earns its place when it changes what a business actually does. The sequence is the same each time.

1. **Establish what the problem is, in figures.** Absence days, labour turnover, output per employee per shift, reject rates, customer complaints. 'Morale is low' is not a starting point; '19% of the packing staff left last year, against 6% in dispatch' is.
2. **Work out which need the evidence points to as unmet.** People leaving for similar pay elsewhere points somewhere different from people taking days off, which points somewhere different again from people producing careless work.
3. **Choose the method that answers that need and that the business can afford.**
4. **Check the reward chain before spending anything.** Is the target reachable? Will the reward follow reliably? Do these employees value it? That is Vroom used as a test rather than as a description.
5. **Decide in advance which figure will show whether it worked**, and read it again afterwards.

Step 5 is the one most often skipped. Where the figure does not move, the business has learned that the need it diagnosed was not the binding one - which is information, not waste.

### The same problem, three different businesses

**A fish processor in Walvis Bay** with 240 employees on shift rates just above the legal minimum, in a town where rent has risen sharply. Absence is 11%. The unmet need here is physiological and security: the wage decides whether the household eats. Enriching the jobs before correcting pay is likely to change little, because it answers a need that is not the one pressing.

**A six-person architectural practice in Windhoek** losing its best draughtsperson every two years. There is no promotion ladder to offer - with six people there is nowhere to go. What it can offer is recognition, a named responsibility, client contact and paid study towards a qualification. The absence of a ladder does not mean the absence of esteem.

**A road-freight firm** whose drivers work alone for days at a time and whose problem is careless vehicle checks. Social needs are plainly unmet, but the problem is quality of work, not belonging, so the first move is feedback the driver can see - each driver's own defect record - together with authority to take a vehicle off the road, which supplies responsibility.

Same word, 'motivation'; three different diagnoses; three different methods. An application answer that names the business and then gives a general advantage has not used the facts. An application answer that says *because these employees are paid near the minimum in an expensive town* has.

### Payment methods: what they have in common and what separates them

A **payment method** is the rule a business uses to turn an employee's time, output or results into the money it pays them. This syllabus names eight: time-based pay, salary, piece rates, commission, bonuses, profit sharing, performance-related pay and fringe benefits.

What separates them is how tightly pay is tied to something measured:

- **Tied to attendance** - time-based pay, salary.
- **Tied to a measured result** - piece rates, commission, performance-related pay.
- **Tied to an outcome known later** - bonuses, profit sharing.
- **Not paid in money at all** - fringe benefits.

That ordering carries the central trade-off of the whole section. The tighter the tie, the stronger the incentive to move the measured quantity - and the greater the risk that the parts of the job which are *not* measured, such as care, safety and helping colleagues, receive less attention. A business choosing a payment method is choosing what it wants more of, and accepting what it is likely to get less of.

Most businesses combine methods rather than relying on one. A basic wage or salary gives the employee a predictable income and the employer a workforce that turns up; a variable element on top supplies the incentive. Moving more of the pay into the variable part shifts risk from the employer to the employee, which is worth saying explicitly in an evaluation.

### Time-based pay

**Time-based pay**, also called a time rate, pays an agreed amount for each hour or day worked:

**gross pay = hours worked x rate per hour**

Hours beyond the standard week are often paid at a higher overtime rate.

*Worked example.* A Windhoek joinery pays bench hands N$28 an hour for a 40-hour week, with overtime at time and a half. In a week with 6 hours of overtime: basic pay is 40 x N$28 = N$1 120; the overtime rate is 1.5 x N$28 = N$42 an hour, so overtime pay is 6 x N$42 = N$252; gross pay is N$1 120 + N$252 = N$1 372.

Time rates suit work where output cannot be counted cleanly, or where care matters more than speed - repairs, care work, skilled fitting. They are simple to calculate and easy for an employee to check, and the income is predictable, which answers the need for security.

The limitation is built into the formula: pay does not rise with output, so nothing in the arrangement gives a reason to work faster. Businesses using time rates therefore rely on supervision, which costs money, and a strong worker and a weak one on the same grade take home the same amount.

### Salary

A **salary** is a fixed annual sum agreed with the employee and paid in equal instalments, usually monthly, regardless of the exact hours worked in any one period. A salary of N$276 000 a year is paid as N$276 000 / 12 = N$23 000 a month.

Salaries suit managerial, professional and administrative work, where the job is defined by responsibilities rather than by counted output and where hours vary from week to week. The employee gets a dependable income that can be planned around, and a degree of standing - being salaried is itself a marker in many organisations. The employer gets a predictable wage bill and no administration of counting hours.

The weakness is that nothing in the arrangement links pay to what is achieved, which is why a salary is so often combined with a bonus or a performance award.

**Salary against time rate.** The difference is what is being paid for. A time rate pays for hours counted, so extra hours bring extra pay and a short week brings less. A salary pays for a role, so the monthly amount is the same whether the month was busy or quiet, and additional hours usually bring no additional payment.

### Piece rates

A **piece rate** pays an agreed amount for each unit produced or task completed:

**gross pay = units produced x rate per unit**

Piece-rate schemes usually include a guaranteed minimum, so that an employee whose machine breaks down does not go unpaid.

*Worked example.* A garment workshop in Oshakati pays N$6.50 for each finished shirt. A machinist completing 420 shirts in a week earns 420 x N$6.50 = N$2 730. If a fault in the cutting room limits her to 180 shirts the following week, the same rate gives 180 x N$6.50 = N$1 170. Her earnings have fallen by N$1 560 for a reason that was nothing to do with her, which is exactly why the guaranteed minimum is written into the agreement.

Piece rates give the clearest possible link between effort and pay, and where the work is repetitive and each unit can be counted they tend to raise output quickly. This is Taylor's method in its purest form.

The costs come with the same link. Speed can be bought at the expense of quality and of safe working, so inspection has to be added and paid for. Income becomes unstable when supplies or machinery fail, which undermines security. The method does not fit work done jointly by a team, because the units cannot be attributed. And setting the rate is a recurring source of dispute: a rate that becomes easy to beat costs the employer, and one that is tightened is experienced as a pay cut.

### Commission

**Commission** pays an employee a percentage of the value of the sales they make, usually on top of a basic wage:

**commission earned = value of sales x commission rate**

*Worked example.* A vehicle salesperson in Swakopmund is paid a basic wage of N$4 000 a month plus 4% commission. In a month with N$186 000 of sales, commission is N$186 000 x 0.04 = N$7 440, so total pay is N$4 000 + N$7 440 = N$11 440. In a quiet month with N$60 000 of sales, commission is N$2 400 and total pay N$6 400 - a swing of N$5 040 between two months in the same job.

Commission suits selling roles where each sale can be attributed to one person, and it lets a business carry a lower fixed wage bill, because much of the cost arises only when revenue does.

Against that: a package weighted heavily towards commission can push employees towards selling whatever earns most rather than what suits the customer, which may cost the business repeat trade. It fits badly where a sale is the work of several people or takes months to close. And earnings move with market conditions the salesperson does not control, so in a downturn the income may fall below what the household needs - a security need undermined by the very method meant to motivate.

### Bonuses

A **bonus** is a lump sum paid in addition to normal pay when a stated target is reached or a stated event occurs. Bonuses may be individual, shared by a team, or paid across the whole workforce, and they may be tied to output, to attendance, to finishing a contract on time, or to the trading result of a year.

*Worked example.* A construction firm promises a team of 8 site workers a shared bonus of N$96 000 for completing a school hall before the school year starts. The team finishes on time, so each member receives N$96 000 / 8 = N$12 000. The payment is a one-off addition to wages already earned, and the firm is not committed to repeating it on the next contract.

A bonus concentrates effort on one stated result within a stated period, and because it is a one-off the employer takes on no permanent addition to the wage bill.

Its weaknesses follow from the same features. A target employees regard as out of reach produces very little effort, because the expectation that effort will earn the payment is what makes the offer work at all - Vroom's expectancy term, at close to zero. A bonus repeated every year tends to become an expected part of pay, so withdrawing it causes more resentment than paying it produced enthusiasm. And a bonus tied to one measure draws attention away from what is not measured - safe working on a site under time pressure being the obvious case.

**Bonus against performance-related pay.** They are different arrangements. A bonus is a lump sum triggered by a stated target or event, with no commitment beyond that occasion. Performance-related pay follows an assessment of how an individual has performed against agreed objectives over a period, and the award may be added permanently to basic pay rather than paid once.

### Profit sharing

**Profit sharing** distributes an agreed share of the business's profit to employees, usually as a stated percentage of profit divided between them, or as a percentage of each person's own pay. The payment depends on the result the business achieves and is made after that result is known.

*Worked example.* A food processor earning a profit of N$4 200 000 shares 5% of it among 60 employees. The pool is N$4 200 000 x 0.05 = N$210 000, and an equal division gives N$210 000 / 60 = N$3 500 each. In a year when profit falls to N$1 200 000 the same rule gives a pool of N$60 000 and N$1 000 each. In a loss-making year it gives nothing.

Profit sharing lines employees' interests up with the trading result, so waste, avoidable cost and lost sales become their concern as well as management's. It can build a sense of being part of the business rather than merely employed by it.

The difficulty is the weakness of the link for any one person. An individual's extra effort makes almost no visible difference to a company-wide profit figure, so instrumentality - the belief that my performance brings my reward - is low. The figure also moves with prices, exchange rates and demand that employees do not control. The payment arrives long after the effort. And in a poor year the reward disappears at exactly the moment employees feel least secure.

### Performance-related pay

**Performance-related pay** awards extra pay to an individual on the basis of an assessment of their performance against objectives agreed in advance. The award may be a one-off payment or an increase to basic pay, and the assessment is normally made by a manager at a review meeting held at set intervals.

*Worked example.* An insurance company in Windhoek pays a claims handler a basic salary of N$18 000 a month and operates three performance bands worth 2%, 4% and 6% of basic pay. A handler placed in the top band receives an extra N$18 000 x 0.06 = N$1 080 a month; one in the lowest band receives N$360. The gap between the two bands is N$720 a month, and whether a gap of that size changes how the work is done is the question the company has to answer before it decides the scheme is working.

The strength of the method is that it extends the idea of paying for results into work whose output cannot be counted in units, which is most office and service work. Setting objectives in advance forces a conversation about what the job is actually for; the review gives feedback the employee might not otherwise receive; and a visible reward for strong performance helps retain the people a business least wants to lose.

The scheme depends entirely on the assessment being accurate and seen to be fair. Where employees regard a manager's judgement as arbitrary, the effect on effort can be negative rather than merely absent. Rewarding individuals can weaken cooperation, because time spent helping a colleague does not show up in one's own assessment. Objectives that can be measured tend to crowd out the parts of a job that cannot. And the sums are often small relative to basic pay, so the scheme can cost management time out of proportion to the change in behaviour it buys.

### Fringe benefits

**Fringe benefits** are rewards given in addition to wages or salary rather than as cash pay - a company vehicle, a housing or transport allowance, medical aid, employer pension contributions, subsidised meals, staff discount, paid study leave. They are sometimes called perks.

They help a business attract and keep employees, and they reach needs that a wage reaches only indirectly: medical aid and a pension answer security, a vehicle or a reserved office answers standing. Some can be provided more cheaply by the employer than the employee could buy them, so the package can be worth more to the employee than it costs the business.

The limits are worth stating precisely. Employees value them very differently, so a benefit one person regards as decisive another regards as worthless - which is Vroom's valence term doing its work. They cost money whether or not they change behaviour. They become an expected entitlement that is awkward to withdraw. And their tax treatment depends on the jurisdiction, which affects what they are actually worth to the employee.

**Fringe benefit against pay.** A benefit is received in a particular form rather than as money the employee can spend as they choose. That is both its strength and its weakness: it can meet a need the employee might not have spent cash on, such as a pension, but an employee with no use for that particular benefit gains little, where the equivalent cash would have been worth its full amount to them.

### Choosing between payment methods

Four questions settle most of these choices.

**Can the output be counted, and attributed to one person?** If it can, piece rates or commission become possible; if it cannot, the choice narrows to time rates, salary and performance-related pay.

**How much does quality matter relative to speed?** The tighter the pay is tied to volume, the more inspection the business has to buy back, and in work where a mistake is dangerous or expensive that cost can exceed the gain in output.

**How much income risk can the employee carry?** An employee on a wage close to household costs is poorly placed to absorb a bad month, so a heavily variable package may undermine the security need at the same time as it sharpens the incentive.

**Is the effort individual or joint?** Individual schemes applied to joint work reward whoever can most easily claim the result and tend to damage the cooperation the work depends on.

One further point is decisive more often than any of these. Pay methods work on what the money is worth to the person receiving it. Once pay is at a level the employee regards as adequate, adding more of it answers a need that is already largely met, and the next unit of spending is likely to buy less than the previous one did. That is why the evaluation of a pay scheme so often ends up somewhere other than pay - and it is why financial and non-financial methods are normally used together rather than chosen between.

### Non-financial motivators: what they are and why they work

A **non-financial motivator** is a reward that comes from the work itself, or from the employee's position and treatment in the organisation, rather than from the money paid. This syllabus names nine: training, opportunities for promotion, development, status, job re-design, team working, empowerment, participation and job enrichment.

They work on the needs that money reaches poorly. Once pay is at a level an employee regards as adequate, further money answers a need already largely met, while recognition, responsibility and the chance to grow answer needs that are not. That is the practical content of Herzberg's separation of removing dissatisfaction from producing positive motivation, and of Maslow's point that a satisfied need loses its power to motivate.

A warning before the list. Non-financial motivators are not the cheap option. Training costs fees and lost working time; job re-design costs management time and may need new equipment; participation costs the hours people spend in meetings. They also work poorly where a more basic need is unmet - enriching the job of an employee whose wage does not cover the household's costs is likely to change very little. They answer different needs from pay rather than substituting for it, and a business that cuts wages and offers recognition instead is likely to find effort falling rather than rising.

### Training

**Training** is planned instruction that gives an employee the knowledge and skills their job requires: induction training on joining, on-the-job training alongside an experienced worker, and off-the-job training away from the workplace such as a course or a supplier's programme.

It motivates through two routes. It raises competence, so work that was difficult becomes manageable and the employee can reasonably expect their effort to produce the result required - that is Vroom's expectancy term being raised directly. And a business spending money on a person signals that it values them and intends to keep them, which answers esteem and security needs.

It has to be paid for in fees and in the output lost while the employee is away, and a better-trained employee becomes more attractive to other employers, so part of the benefit may leave with them. The motivating effect also depends on what follows: where the new skills are never used, or where the course is understood as something the business is obliged to run, the training is unlikely to change effort at all.

### Opportunities for promotion

**Promotion**, in this topic, means advancing an employee to a post of higher rank carrying greater responsibility and usually higher pay.

The word means something entirely different in marketing, where promotion is the communication a business uses to persuade customers to buy. The two senses share nothing but the word, and a learner who has met the marketing sense in topic 3 should keep them apart.

The *prospect* of promotion is what motivates, and it does so where employees can see a route upwards, understand what performance is needed to travel it, and believe that posts genuinely become available. It answers esteem needs through the recognition a higher rank carries, and the need to grow through the wider work the post involves.

The limits are practical. A small business with a flat structure may have no vacancy for years, in which case holding out the prospect produces disappointment rather than effort. For every employee promoted, others were not, and their reaction can offset the gain. And a business that promotes its best technician into management may lose a good technician and gain a weak manager, because the two jobs call for different abilities.

### Development

**Development** is the longer-term growth of an employee's capability beyond the demands of their present job - through mentoring, moving across departments to widen experience, studying for a professional qualification, or leading a project that stretches them.

**Training against development.** The horizon is what separates them. Training equips an employee for the job they hold now, and is judged by whether they do it better. Development builds a person's capability for roles they do not yet hold, and is judged by what they become able to take on.

Development motivates because it treats the employee as a person with a future rather than as the holder of a post. It answers the need to grow, it makes internal promotion realistic and so gives the promotion route credibility, and it tends to hold ambitious employees who would otherwise look elsewhere for a bigger job.

It takes years to show a return and costs money and senior time before it shows anything, which makes it vulnerable when a business is under financial pressure. It can also raise expectations the business cannot then meet: an employee who has finished a qualification and finds no larger role waiting may leave sooner than if nothing had been offered.

### Status

**Status** is the standing an employee holds relative to others in the organisation, together with the visible markers that signal it - a job title, a uniform or badge, an office rather than a shared desk, a reserved parking space, a seat on a committee.

It answers the need for respect from others and for self-respect, which is the esteem level of Maslow's hierarchy and sits among Herzberg's motivators as a form of recognition. It is also cheap relative to pay, which is why a business unable to afford a large increase can still change how valued an employee feels.

Status depends on other people recognising the marker, so it works where colleagues and customers read the title or the badge as meaning something, and does little where they do not. Markers that separate employees can breed resentment among those without them. And a title handed over with no change in responsibility tends to be seen through, after which it carries less weight than it did before it was given.

### Job re-design

**Job re-design** means deliberately changing the content or structure of a job to make it more satisfying and to raise the effort employees are willing to give. It is an umbrella term, and the three forms under it differ in what they change:

- **Job rotation** moves an employee between tasks of similar difficulty at planned intervals. The variety changes; the level of responsibility does not.
- **Job enlargement** adds further tasks at the same level, widening the job **horizontally**.
- **Job enrichment** adds responsibility, decision-making and a complete unit of work, deepening the job **vertically**.

Re-design attacks boredom at its source, which is the narrowness of the work rather than the conditions around it. Rotation also makes a workforce more flexible, because employees who have worked several positions can cover absence, and it reduces the risk of repetitive strain from making one movement all day.

It costs management time to plan and usually needs training before employees can move between tasks, and output may dip while people learn. Widening a job that remains dull can be experienced as more of the same work rather than better work. Employees content with a familiar routine may resist the change. And where re-design is introduced without consultation it is easily read as a way of extracting more work for the same pay.

### Job enrichment

**Job enrichment** gives an employee a complete and identifiable piece of work, the responsibility and authority to decide how it is carried out, and direct feedback on the result. It deepens a job vertically by adding decisions a manager previously took.

**Enrichment against enlargement.** The direction of the change separates them. Enlargement adds more tasks at the same level, so the employee does more things of the kind they already did. Enrichment adds responsibility and decision-making, so the employee does the same work with greater control over it and is answerable for the outcome.

Enrichment is the practical form of Herzberg's argument, and where it works the reward is built into the job and does not have to be paid for again each period - which is a genuine advantage over any scheme that requires a payment every year.

It requires training, because an employee handed decisions they have not been prepared for may make poor ones. It takes authority away from supervisors, who may resist it. And employees may reasonably ask for more pay for work that now carries more responsibility, so a method presented as an alternative to higher wages can end up raising them.

### Team working

**Team working** organises employees into groups that are jointly responsible for a complete task or area of work, with the group deciding between its members how the work is allocated and often setting its own arrangements within limits set by management.

It answers the need to belong, which is the social level of Maslow's hierarchy and the central point of Mayo's human relations school. Members support each other, cover absence, and pass on skills without a formal course, and the wish not to let colleagues down can raise effort in a way no supervisor achieves.

The group's own standard of a reasonable day's work can sit below what management wants as easily as above it - the Hawthorne finding cuts both ways. An individual whose effort is hidden inside a group result may coast on the work of others. Teams take longer to reach decisions than one person does. Personal conflict inside a small group is hard to escape. And work that is genuinely individual gains little from being organised this way.

### Empowerment

**Empowerment** gives employees the authority to make decisions about their own work without referring them upwards, together with the information and resources to decide well and accountability for the results.

It motivates by supplying responsibility and control, which are among Herzberg's motivators and reach the esteem and self-actualisation levels of Maslow's hierarchy. It also improves the work itself: the person closest to a problem usually knows most about it, and a decision taken on the spot reaches the customer faster than one referred through two levels of management.

It works where the boundaries of the authority are stated, the employee has been trained and given the information a good decision needs, and managers accept the decisions that come back. Where a manager reverses those decisions the arrangement is empowerment in name only, and tends to leave employees more cynical than before it was introduced. Some employees experience the added responsibility as pressure rather than reward. And a mistake made by an employee acting within their authority still costs the business money.

### Participation

**Participation** means involving employees in decisions that affect their work - through consultation meetings, team briefings, suggestion schemes, joint committees and employee representation - so that their views are heard before a decision is taken.

**Participation against empowerment.** Who finally decides is what separates them. Participation gives employees a voice in a decision that someone else takes. Empowerment transfers the decision itself, within stated limits, to the employee doing the work.

Participation motivates because being asked signals that the employee's judgement is valued, which answers esteem needs, and because people who have helped shape a decision tend to accept it more readily than people to whom it is announced. That acceptance matters most when the decision changes how work is done.

Consultation takes time and slows decisions, which is costly where a situation is urgent. Its motivating effect depends on employees seeing that what they said made a difference: where the same proposals are consulted on and nothing ever changes, participation is read as a formality and can leave employees more cynical than no consultation at all. Employees may also lack the information needed to contribute usefully to decisions reaching beyond their own work.

### How employees can participate in management and control

**Employee participation in the management and control of a business** means arrangements that give employees a share in decisions beyond their own immediate task - about how a department is run, how the business responds to a change, and in some forms about the direction of the business itself.

The usual arrangements, in rising order of how much say they give:

- **Team briefings and consultation meetings** - information passed down, comment invited.
- **Suggestion schemes** - proposals collected from anyone, often with a payment for those adopted.
- **Quality circles** - small voluntary groups meeting regularly to identify and solve problems in their own area of work.
- **Works councils or joint consultative committees** - standing bodies of elected employee representatives that management must consult on stated matters.
- **Employee representatives or worker directors on the board** - a seat where the decision is actually taken.
- **Employee share ownership** - employees become part-owners, with the voting rights that go with shares.

These form a ladder rather than a list, and the rungs are **being informed**, **being consulted**, **deciding jointly** and **owning**. A team briefing that only passes information down gives no say at all. A works council with a right to be consulted gives a say without the final word. A worker director takes part in the decision. A shareholding employee holds a share of control permanently, through votes, alongside a share of the reward, through dividends. Naming which rung an arrangement sits on is usually what turns a description into analysis.

### How far participation should go

**The case for.** Participation can improve the decisions themselves, because employees doing the work often see problems and remedies managers do not, and a quality circle turns that knowledge into proposals that can be costed. It tends to reduce resistance to change, because employees who were consulted about a new method understand why it is being introduced. And it answers esteem and self-actualisation needs, which is why it belongs in a motivation topic rather than only in a discussion of organisation.

**The case against.** It slows decisions, which is a real cost when a business must respond quickly. Employees may not have the commercial information to judge a strategic question, and some matters cannot be discussed widely without harming the business. Managers may resist arrangements that reduce their authority, or run them as a formality. Where employees see that consultation changes nothing, the arrangement damages trust rather than building it. And employee shareholders have both their savings and their job exposed to the same business, which concentrates their risk rather than spreading it.

**Where the balance falls.** Participation is more likely to repay its cost where managers act on what comes back and are seen to; where employees have enough information to contribute usefully; where the matters put to them are ones they know something about; and where the decision is not so urgent that consultation would arrive too late. A judgement on any particular business should turn on those four conditions rather than on whether participation is a good idea in the abstract. Where they are absent, the same arrangements consume time and produce cynicism.

### Common errors

**"Non-financial motivators are the cheap alternative to a pay rise."** They cost money and management time, and they answer different needs. A business that cuts wages and offers recognition instead is likely to find effort falling.

**"Job enlargement and job enrichment are much the same."** Enlargement is horizontal - more tasks at the same level. Enrichment is vertical - more responsibility and decision-making. Only the second adds what Herzberg called a motivator.

**"Participation and empowerment are interchangeable words."** Participation is a voice in someone else's decision; empowerment is the decision itself.

**"A bonus is performance-related pay."** A bonus is a lump sum triggered by a target or an event. Performance-related pay follows an assessment of an individual against agreed objectives, and may be added permanently to basic pay.

**"What worked in one department will work in the next."** What a reward is worth depends on the needs of the people offered it, which is why the test of any scheme is what happens to the figures the business chose to watch.

### Where this connects

The theories behind these methods are in 2.2.3 and the needs they work on are in 2.2.2. Labour costs and productivity as operations measures belong to 4.1; the way managers behave towards their teams is treated in 2.3; and the marketing sense of the word promotion belongs to 3.3, not here.

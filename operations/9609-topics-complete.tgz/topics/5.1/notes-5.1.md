# 5.1 Business finance

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain why a business needs finance to start up, to grow and to survive; distinguish a short-term need for finance from a long-term one; explain the difference between cash and profit; and explain what bankruptcy, liquidation and administration are and how they differ.
- Explain the meaning and importance of working capital and calculate it; explain and analyse how a business manages trade receivables and trade payables; and distinguish capital expenditure from revenue expenditure.

---

## Why a business needs finance, and what happens when it runs out

### What business finance is for

**Business finance** is the money a business raises and uses to pay for what it needs before, or faster than, its own trading income can pay for it.

The second half of that sentence is the idea. A business able to pay for everything out of the money its customers hand over, at the moment it needed to, would need no finance at all. Finance exists because spending and earning do not line up in time. Equipment has to be bought before it can make anything. Stock has to sit on the shelf before anyone buys it. Wages fall due at the end of the month whether or not the customer has paid.

So the question is not only *how much money is needed*. It is *what is the money for, and how long will it be tied up before trading brings it back*. Topic 5.2 deals with where the money comes from and how a business chooses between the sources open to it. This section deals with why the money is needed in the first place, and the order matters: a source chosen before the need is understood is chosen blind.

### Three moments a business needs finance

**Starting up.** Nothing can be sold until something has been bought. Before a new business takes a cent it has to pay for what must be in place first: premises and the deposit on them, equipment, the opening stock, registration and licence fees, and the rent, wages and power of the months before trade builds up.

Take a small printing business opening in Ondangwa. The press, computer and fitting out come to N$180 000. Opening stock of paper, ink and plates is N$45 000. The owner allows N$60 000 to cover three months of rent, wages and power while the shop builds a customer list - N$285 000 in all, every cent of it needed before the first invoice is paid. Notice what that N$60 000 is doing. It buys nothing the business keeps. It buys time.

**Growing.** Growth is paid for before it pays. A business taking on a larger contract needs the vehicle, the extra machine, the bigger unit and the extra staff in place first, and it needs more stock on the shelves to serve more customers. The revenue that justifies all of it arrives later, and if the new customers buy on credit, later still.

This is why a business can be growing quickly and short of money at the same time. The faster sales grow, the more stock and wages have to be carried before the customers pay for them, and growth funded out of the bank balance alone can empty it.

**Surviving.** The third need has nothing to do with ambition. A drought cuts a supplier's harvest and the price of raw material jumps. A large customer pays sixty days late. The cold-room compressor fails. Fuel goes up. None of these is a failure of the business idea, and none of them waits for a convenient month. Each is a demand for money at a moment when trading has not produced it, and a business without the means to meet it is in difficulty however good its products are.

### Short-term need and long-term need

A **short-term need for finance** is one the business expects to settle within about a year. It comes out of day-to-day trading: paying for inventory, wages, fuel and overheads in the weeks before the customers who will fund them have paid.

A **long-term need for finance** lasts more than about a year. It comes from spending on assets and capacity that will be used, and will earn revenue, over several years: vehicles, machinery, premises, a new production line.

What decides which a need is? Not the size of the amount - a single month's wage bill can be larger than a machine. What decides it is how long the money stays tied up before trading returns it.

That matters because of a principle that runs through the whole of business finance: **finance should be repayable over a period similar to the life of the need it pays for.** Get it wrong in one direction - a machine with an eight-year life paid for with money that must be returned in six months - and the repayments fall due long before the machine has earned them, so the money has to be found somewhere else. Get it wrong in the other - a month's stock paid for with borrowing repayable over ten years - and the business is still paying for goods that were sold and consumed years earlier.

Long-term needs are commonly met by borrowing repayable over several years. A loan of that kind may be **secured**, where the lender holds a claim over a named asset it can sell if the business does not repay, or **unsecured**, where it holds no such claim; a secured loan is typically offered at a lower rate, because the lender's risk of losing its money is lower. Which sources are actually open to a particular business, and how it chooses between them, is the subject of topic 5.2.

### Matching, with the numbers

A bakery in Okahandja has two needs at once.

The first is an oven costing **N$240 000**, expected to be in use for about eight years.

The second is **N$70 000** to carry flour, packaging and wages during the three weeks between buying supplies and being paid by the shops and hotels it delivers to.

These are not the same need and they should not be met the same way. Suppose the oven were paid for with finance repayable over twelve months. The capital repayment alone is N$240 000 / 12 = N$20 000 a month. If the oven adds around N$9 000 a month to the bakery's takings once the extra flour, power and labour are paid for, the bakery is short by about N$11 000 every month for a year, on an asset doing exactly what was expected of it. The asset is sound; the finance is wrong.

Spread over the eight years the oven will actually work, the same amount is N$240 000 / 96 = N$2 500 a month of capital repayment, which the N$9 000 covers comfortably.

The N$70 000 is the opposite case. It is needed again and released again, week after week, as customers pay - so it suits finance that can be drawn and repaid as trading requires, rather than an obligation the bakery is still carrying in eight years' time.

### Cash and profit are different measurements

**Profit** is what is left of a period's revenue once the costs of earning that revenue are taken off: **profit = revenue - costs**. It is recorded when a sale is made and when a cost is incurred, not when money moves.

**Cash** is the money the business actually holds - in the bank and in the till - and can pay with today.

They answer different questions. The profit figure answers *did trading add value over this period?* The cash balance answers *can this business pay what falls due now?* A business needs a yes to both, and a yes to one does not produce a yes to the other.

### A profitable month in which the bank balance falls

Kunene Joinery fits kitchens. In one month it delivers and invoices **N$320 000** of work, all of it on sixty-day credit. Its costs for that month are materials N$140 000, wages N$95 000 and overheads N$40 000 - N$275 000 in all.

Profit for the month = N$320 000 - N$275 000 = **N$45 000**.

Now follow the money. Nothing came in from this month's invoices, because those customers have sixty days. What did come in was N$185 000 from work invoiced two months earlier. Out went the N$275 000 of materials, wages and overheads, and a N$60 000 instalment on a vehicle bought last year.

Cash paid out = N$275 000 + N$60 000 = **N$335 000**. Cash received = **N$185 000**. The bank balance therefore falls by N$335 000 - N$185 000 = **N$150 000**, in a month in which the business made N$45 000 of profit.

Three things pulled the figures apart, and each is worth naming.

*Credit sales.* The N$320 000 counts as revenue as soon as the kitchens are delivered, but the money is two months away. A sale made on credit adds to profit before it adds to cash.

*Repaying finance.* The N$60 000 instalment returns money the business borrowed. Returning borrowed money is not a cost of this month's trading, so it takes cash without touching profit.

*Buying assets.* Had Kunene bought a new saw this month, the cash would have gone in full the day it paid, while only part of the cost is charged against profit in each of the years the saw is used. Cash out now; profit reduced slowly.

It runs the other way too. A business can hold plenty of cash while making a loss - after selling a vehicle, say, or after new finance is paid in - because neither of those is revenue.

### How a shortage of finance becomes failure

A business does not fail because it is unprofitable. It fails because it cannot pay.

The sequence is worth following in order, because each step makes the next one harder. An amount falls due - a supplier's invoice, the wage bill, an instalment - and the bank balance will not cover it. The business asks for time. A supplier who has not been paid has its own money tied up in the debt and is likely to want payment before supplying again, so terms tighten or supply moves to cash on delivery. That makes the following month harder rather than easier, because stock must now be paid for before it can be sold. Staff whose wages are late start looking elsewhere, and their skills go with them. Customers hear that deliveries are slipping and place orders where they are safer. Eventually a creditor stops waiting and goes to court to recover what is owed, and a formal insolvency procedure begins.

Notice where the chain starts. It starts at a moment of not being able to pay, which is a cash problem, and a business can arrive there with a full order book and profitable products. Notice too that it feeds itself: every step removes some of the finance that would have solved the problem at the step before. That is why the earliest signs - an overdraft at its limit month after month, suppliers pressing, wages met a few days late - matter more than their size suggests.

### Bankruptcy

**Bankruptcy** is a legal declaration that a person cannot pay their debts as they fall due. Control of that person's assets passes to an appointed official, the assets are sold, and the proceeds are shared among the creditors in an order set by law.

It is a term about people rather than companies, which is why it reaches business through the unincorporated forms of ownership. A sole trader or an ordinary partner has unlimited liability: in law the owner and the business are not separate, so the debts of the business are that person's own debts. If the business cannot pay them, creditors may pursue the owner personally, and assets held outside the business - a house, a vehicle, savings - may be sold to meet them.

Two consequences follow for the owner. The loss is not limited to what was put into the business. And the personal consequences of a bankruptcy declaration, such as restrictions on borrowing or on holding certain offices, attach to the person and outlast the business.

In some countries the word is used more broadly, to cover companies as well. The distinction worth holding is not the label but the substance: this is the procedure that deals with a *person* who cannot pay.

### Liquidation

**Liquidation**, also called winding up, is the process by which a company is brought to an end. An appointed liquidator takes control, sells the company's assets, pays the proceeds to creditors in an order set by law, and distributes anything remaining to shareholders. At the end of it the company ceases to exist.

Two routes lead there. **Compulsory liquidation** is forced on the company, typically after a creditor who has not been paid applies to a court for an order. **Voluntary liquidation** is begun by the company itself, through its shareholders. That may follow an inability to pay debts, and it may also happen for reasons unconnected with insolvency - owners who wish to retire and close a solvent business tidily, for instance.

Because a company has limited liability, the creditors' claims stop at the company's own assets. Shareholders lose the money they put in, but their personal assets are not normally reached to pay the company's debts. Where a shareholder or a director has personally guaranteed a company debt, that guarantee is a separate personal obligation and can still be enforced against them - which is why the owner of a small company that has given such a guarantee is in a weaker position than limited liability alone suggests.

### Administration

**Administration** is a procedure in which a company in financial difficulty is placed under the control of an appointed insolvency practitioner - the administrator - who takes over the running of it from the directors. The administrator's task is to rescue the company as a going concern if that can be done, and if it cannot, to achieve a better result for the creditors as a whole than closing the company immediately would produce.

What makes the attempt possible is time. While a company is in administration it normally has protection from creditors enforcing their claims against it, which stops the business being dismantled piece by piece while a plan is being made. With that breathing space the administrator may sell the business as a working whole rather than as separate assets, renegotiate what is owed, close the loss-making parts, or find a buyer for the rest.

Administration is temporary. It ends when the company is handed back in a workable state, or sold, or when the attempt fails and the company passes into liquidation.

One caution. The precise legal procedures, and the names they are given, differ from one country to another. What this topic requires is the difference of purpose between the three procedures, not the law of any single jurisdiction.

### Telling the three apart

Set side by side, the three differ on two questions: *who* the procedure is about, and *what it is trying to achieve*.

**Bankruptcy** is about a person who cannot pay - in a business setting, the owner of an unincorporated business whose unlimited liability has made the firm's debts their own. Its aim is to realise that person's assets and share them among creditors.

**Liquidation** is about a company, and its aim is to end it: assets sold, creditors paid in the legal order, company dissolved. It is terminal.

**Administration** is also about a company, but its aim is the opposite of ending it. It is a rescue attempt, run by an outsider under legal protection, and the business may come out of it still trading.

One sentence holds the distinction: administration tries to save the company, liquidation closes it, and bankruptcy concerns a person rather than a company. The relationship between the first two matters as well. Administration that fails is commonly followed by liquidation, so they are stages a company can pass through in sequence, not simply alternatives it picks between once.

### Common errors

**Treating profit as the money in the bank.** These are two measurements taken on two different bases. A profitable month can end with less cash than it started with, and a month that ends with more cash can be a loss-making one.

**Saying a business failed because it was unprofitable.** Some do. But the immediate cause of a formal insolvency procedure is an inability to pay an amount that has fallen due, and profitable businesses reach that point through late-paying customers, stock bought too far ahead, or growth outrunning the finance behind it.

**Using bankruptcy for a company.** A company that cannot pay goes into liquidation, or into administration if a rescue is attempted. Keep bankruptcy for a person.

**Treating administration and liquidation as the same event.** One is an attempt to keep the business alive; the other ends the company. Writing that a company went into administration and was wound up as though it were a single step loses the distinction between them.

**Deciding short or long term by the size of the amount.** A large sum needed for six weeks is a short-term need; a smaller sum committed to a machine for seven years is a long-term one. The length of time the money is committed decides it.

### Where this connects

**Topic 5.2, sources of finance**, takes up exactly where this section stops. Once the need is understood - how much, what for, and for how long - the question becomes which source fits it, and that is where the internal and external sources, and the factors influencing the choice between them, are dealt with.

**Topic 1.2, business structure**, supplies the reason bankruptcy reaches some business owners and not others. Unlimited liability is what turns a firm's debt into its owner's debt.

**Topic 5.3, forecasting and managing cash flows**, is the practical answer to the cash-and-profit distinction: it is the technique for seeing a shortfall before it arrives rather than after.

**Topic 1.3, size of business**, runs the same argument in reverse. The difficulty a small business has in raising finance is one of the reasons it may stay small.

---

## Working capital, credit management and the two forms of spending

### Working capital

**Working capital** is the finance a business has available for its day-to-day operations. It is measured as

**working capital = current assets - current liabilities**

and the answer is a sum of money, in N$.

**Current assets** are cash and the things expected to become cash within a year: money in the bank and the till, **trade receivables** (amounts customers owe for goods already delivered) and **inventory** (raw materials, work in progress and finished goods).

**Current liabilities** are the amounts the business must pay within a year: **trade payables** (amounts owed to suppliers), an overdrawn bank balance, and other short-term amounts due such as tax and unpaid wages.

Read the formula as a question rather than a sum: *if everything due within the year came in and everything due within the year went out, what would be left to trade on?* A positive figure says there is something left. A negative one says the claims arriving within the year are larger than the resources arriving to meet them.

### Why it matters: the gap between paying and being paid

Working capital exists because of a gap in time.

A hardware retailer in Windhoek orders stock on the first of the month. The supplier's terms give it thirty days, so it pays on day 30. The goods sell, on average, around day 45. The trade customers who buy them have thirty days of their own, so the money arrives around day 75.

From day 30, when the retailer pays, to day 75, when it is paid, is 45 days in which the business has parted with money for goods it has not yet been paid for. Something has to cover those 45 days, and that something is working capital. A business holding stock or selling on credit has a version of this gap, and the longer the gap, the more money has to stand behind it.

That is the importance of working capital in one line: it is what lets a business meet its obligations on the day they fall due, rather than on the day its customers get round to paying. A business can be profitable across a year and still fail in a particular week, and working capital is the difference between the two.

### Calculating working capital, and reading the answer

Omaruru Hardware's position at the end of a month:

Current assets - inventory N$410 000, trade receivables N$265 000 and cash N$48 000: **N$723 000**.

Current liabilities - trade payables N$330 000, bank overdraft N$95 000 and tax due N$38 000: **N$463 000**.

Working capital = N$723 000 - N$463 000 = **N$260 000**.

The figure is money. It is not a ratio and not a number of days: Omaruru has N$260 000 of resources due within the year over and above the claims due within the year.

Interpreting it takes one more step, because N$260 000 on its own is neither good nor bad. Set it against what the business has to pay. If Omaruru's monthly outgoings on stock, wages and overheads run at about N$390 000, then N$260 000 is under three weeks of trading. Then look at what the figure is made of: N$410 000 of the N$723 000 is inventory, which pays no bills until it is sold, and only N$48 000 is cash. A business can show positive working capital and still be unable to pay a bill on Friday, which is the limitation of the measure and the reason it is read alongside the composition rather than on its own.

### Too little, and too much

**Too little.** The business cannot meet an amount on the day it falls due. It pays a supplier late, so that supplier tightens its terms or asks for cash with the order; stock that used to arrive on credit now has to be paid for up front, which takes more working capital rather than less. Discounts for prompt payment are lost. If wages are late, staff leave. The business may be forced to sell inventory quickly at a reduced price, which turns stock into cash but throws away the margin it was carrying. Each of those steps leaves less money for the month after, which is why a working capital shortage rarely stays the size it started.

**Too much.** The opposite position costs money too, more quietly. Money sitting in inventory and in unpaid customer accounts earns nothing while it sits there. Omaruru's N$410 000 of stock against purchases of about N$200 000 a month is roughly two months of selling held on the shelves: money that could have paid down the overdraft, bought a second delivery vehicle or funded a marketing push is lying in a storeroom instead, and stock held that long may be damaged, become unsaleable or pass its date. Unpaid customer accounts carry the same opportunity cost, and the further risk that some of them are not collected at all.

So the aim is not the largest possible working capital. It is enough to meet what falls due, with as little as possible tied up beyond that - and where the line sits depends on the business. A cash-only takeaway needs very little. A manufacturer holding three months of raw material and selling on sixty-day terms needs a great deal.

### Managing trade receivables

**Trade receivables** are the amounts customers owe the business for goods or services already delivered on credit. Every N$1 of receivables is N$1 the business has already spent and not yet recovered.

Managing them is a sequence of decisions, not a single action.

*Who gets credit, and how much.* Before offering terms a business can ask for trade references, check how long the customer has traded, and open a new account with a low limit that rises as the customer proves reliable.

*What the terms are, and whether the customer knows them.* Terms written on the order, repeated on the invoice and applied consistently are harder to ignore than terms that surface only once an account is already late.

*Invoicing promptly and accurately.* A credit period does not begin until the invoice is issued, so an invoice sent a fortnight late is a fortnight of credit given away. A wrong invoice is worse: it gives the customer a reason to hold the whole amount while it is queried.

*Chasing what is overdue.* A schedule showing how long each account has been outstanding tells the business which to chase first. Contact made early and by agreement generally recovers more than a demand made months later.

*Deciding what to do about persistent late payers.* The options run from tightening terms, to requiring payment with order, to declining further work. Each protects cash and each risks the sale, and that is the tension at the centre of the whole activity: pressing too hard costs the customer, pressing too little costs the cash.

### Managing trade payables

**Trade payables** are the amounts the business owes suppliers for goods and services already received. They are the mirror image of receivables: while the business owes, it is holding money that would otherwise have gone out, so payables are a source of day-to-day finance that carries no interest.

Managing them well starts with using the agreed credit period instead of paying early out of habit. A business paying on day 10 when the terms allow 30 gives up twenty days of free finance for nothing in return.

Using the period is not the same as exceeding it, and the difference is where the judgement lies. Paying beyond agreed terms takes money the business has not been given permission to hold. A supplier whose money is late may shorten the terms, ask for payment with order, withdraw a prompt-payment discount, move the account down the delivery list, or in the end decline to supply - and a business that cannot obtain raw material on credit has a worse problem than the one it was solving.

Two further judgements sit alongside. Where a supplier offers a discount for early payment, the discount has to be weighed against the value of holding the money longer. And a business relying on a single supplier has less room to stretch payment than one that can buy the same input in three places, because the cost of that supplier withdrawing credit is higher.

The two halves pull on the same cash. Money is tied up while customers owe the business and released while the business owes its suppliers, so the shorter the collection period and the longer the payment period - within what has been agreed - the less working capital the business has to find elsewhere.

### Is a discount for early payment worth offering?

Swakop Tools is owed N$600 000 by trade customers who take, on average, 60 days to pay. Its bank overdraft costs 1% a month. To bring cash in sooner it considers offering **2% off for payment within 15 days**, and expects the customers owing N$400 000 to take it.

*What it costs.* The discount given is N$400 000 x 0.02 = **N$8 000**.

*What it saves.* N$400 000 less the discount is N$392 000, arriving 45 days early - one and a half months. Overdraft interest on N$392 000 runs at about N$3 920 a month, so a month and a half of it is about **N$5 880**.

*The comparison.* N$8 000 - N$5 880 = **N$2 120**. Measured on interest alone the offer costs about N$2 120 more than it saves, each month it runs.

So the arithmetic says no - but only to the question it was asked. Three things could change the answer, and each has to be checked rather than assumed. If Swakop is at its overdraft limit, the earlier cash is not merely cheaper money, it is the difference between paying wages and not, and that is worth more than the interest line shows. If part of the N$400 000 would eventually not have been collected at all, the discount buys certainty as well as speed, and 2% is a small price for removing that risk. And if competing suppliers already offer the same terms, the discount may be defending sales rather than buying cash, which is a different calculation again.

The general shape is worth keeping. A discount for early payment is a certain cost, incurred every time it is taken, set against a saving that lasts only as long as the money would otherwise have been outstanding.

### Capital expenditure and revenue expenditure

**Capital expenditure** is spending on non-current assets: items bought to be kept and used in the business for more than a year. Vehicles, machinery, premises, computers and fixtures, together with the cost of getting them installed and working.

**Revenue expenditure** is spending on running the business day to day, used up within the period in which it is incurred. Wages, rent, fuel, raw materials, insurance, power, advertising and routine repairs.

The test is what is bought and how long it will be used, not how much it costs. A delivery van at N$320 000 is capital expenditure; a year's insurance on the same van at N$26 000 is revenue expenditure, even though both are paid to keep the van on the road. A N$900 office chair that will last six years is capital expenditure in principle, although many businesses set a monetary threshold below which small long-lived items are charged as running costs instead, for the practical reason that tracking them separately costs more than it is worth.

The pair that most often causes trouble is repair against improvement. Replacing a worn tyre keeps the van doing what it already did, so it is revenue expenditure. Fitting a refrigeration unit so the van can carry chilled goods gives it a capability it did not have, and a benefit lasting years, so it is capital expenditure.

### What each form of spending does to profit and to cash

Tsumeb Transport spends the following in one month: **N$680 000** on a truck, **N$95 000** on extending its workshop, **N$140 000** on diesel and drivers' wages, **N$18 000** on insurance and **N$12 000** on routine servicing.

Capital expenditure = N$680 000 + N$95 000 = **N$775 000**.

Revenue expenditure - N$140 000 of diesel and wages, N$18 000 of insurance and N$12 000 of servicing: **N$170 000**.

Total cash leaving the business = N$775 000 + N$170 000 = **N$945 000**. Charged against this month's profit: **N$170 000**.

That gap is the whole point of the distinction. Revenue expenditure is charged in full against the profit of the period in which it is incurred. Capital expenditure is not, because the asset will be used across several years and its cost is spread over them rather than landing on one month. So two businesses spending exactly the same cash in a month can report very different profits, depending on what they spent it on, and neither is being dishonest.

It also settles what kind of finance each needs. The N$775 000 is money tied up for years, so it is a long-term need. The N$170 000 recurs every month and is released as customers pay, so it is a short-term need, and it is the working capital of the business that carries it.

And it explains the trap in the cash column. The truck takes N$680 000 out of the bank on the day it is paid for, while the reported profit for that month barely moves. A business reading the profit figure and forgetting the cash figure can approve a purchase it can fully justify and still be unable to pay its wages at the end of the month.

### Common errors

**Treating working capital as a pile of cash.** It is current assets minus current liabilities, and in a typical trading business most of the current assets are not cash at all - they are stock on the shelves and money owed by customers. A positive figure is not the same as being able to pay tomorrow.

**Assuming more working capital is better without limit.** Money tied up in inventory and receivables earns nothing and carries risk. The aim is enough, not the most.

**Sorting expenditure by size.** A large repair bill is still revenue expenditure, and a small long-lived asset is capital expenditure in principle. Length of use decides it, not the amount.

**Forgetting that buying an asset costs cash immediately.** Capital expenditure does not reduce this period's profit by the full amount, but it does reduce the bank balance by the full amount on the day it is paid.

**Confusing late payment with managing payables.** Using the credit period that was agreed is management. Exceeding it is a decision to take finance the supplier has not offered, and it can cost the business its terms, its discounts or its supply.

### Where this connects

**Topic 4.2, inventory management**, is the other half of the working capital story: holding costs, the risk of running out of stock, and the trade-off between them are the same trade-off seen from the operations side.

**Topic 5.2, sources of finance**, supplies what the short-term and long-term needs identified here are actually met with, and the factors that decide the choice.

**Topic 5.3, forecasting and managing cash flows**, turns the timing gap described here into a month-by-month forecast, so that a shortage is seen before it arrives.

**Topic 5.4, costs**, shares the vocabulary: the revenue expenditure of this section is the same money that appears there as the cost of making and selling.

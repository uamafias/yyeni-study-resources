# 1.4 Business objectives

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Define a business objective and explain the objectives set by private sector businesses, public sector organisations and social enterprises; explain why objectives matter; explain corporate social responsibility and the triple bottom line; and explain how mission statement, aims, objectives, strategy and tactics fit together.
- Explain the stages of business decision-making and the part objectives play in them; explain how and why objectives change over time; explain how objectives are translated into targets and budgets; explain why objectives are communicated and how that affects the workforce; explain SMART objectives; and explain how ethics may influence a business's objectives and activities.

---

## What businesses are trying to do, and why it depends on who owns them

### What a business objective is

A business objective is a specific goal, stated so that progress towards it can be measured, that an organisation sets itself to reach within a stated period.

Two parts of that sentence carry the weight. *Measurable* means there is a number, or a condition, that settles afterwards whether the objective was reached. *Within a stated period* means there is a date by which it should have been reached. A goal with neither - "be the best supplier in the north" - is a wish, because nothing can ever decide whether it has happened.

One warning about the word. Business objectives are the goals an organisation sets for itself. They are not the marketing objectives of one department, and they are not the assessment objectives of a qualification. The word is used for all three and they are different things.

### Ownership decides what the objectives are for

Why does a state-owned water utility not try to maximise profit, when a private bottler of the same water does? Because the two are owned by different people, for different reasons.

An organisation's objectives follow from who owns it and what it exists to do. Private owners have put their own money in and expect a return on it. Government owns a public sector organisation on behalf of the public and expects a service. The members of a social enterprise have put money in to achieve a social or environmental result, and expect that result.

What the three have in common is easy to overlook. Each of them needs enough revenue to cover its costs - a hospital that spends more than it is given still has to find the difference somewhere, and a social enterprise that never covers its costs closes like any other business. The difference lies in what any surplus is for: a return to private owners, the continued funding of a public service, or reinvestment in the social purpose.

### Objectives in the private sector

The private sector is the part of the economy owned by private individuals and shareholders rather than by the state. Its objectives are set by those owners, so they vary with what the owners want.

The ones that recur are these. **Survival** - staying in business at all. **Profit maximisation** - earning the largest profit the business can. **Profit satisficing** - earning enough profit to satisfy the owners while other things they value are also served. **Growth**, measured in sales revenue, output or share of the market. **Increasing the value of the owners' shareholding**, which matters most where the owners are shareholders who may sell. And, for a sole trader or a small partnership, **personal independence** - working for oneself, choosing one's own hours, keeping control of the work.

### How the private sector objectives trade against each other

These objectives are not a menu from which a business picks one. They sit in tension, and which one leads depends on the position the business is in.

Survival tends to lead for a new business, or for one whose sales have just fallen sharply, because a business that runs out of cash has to stop trading whatever else it was aiming at. A guesthouse whose bookings collapse will cut prices below the level that maximises profit if that is what fills rooms and keeps cash coming in.

Profit maximisation and profit satisficing are genuinely different objectives, not two names for one. A satisficing owner accepts a smaller profit in exchange for something else - free time, less risk, keeping the business small enough to run alone. A maximising owner does not. Owner-managers satisfice more often than shareholder-owned companies do, because the owner is also the person who would have to do the extra work.

Growth is pursued because a larger scale can lower average cost and give a business more influence over the price it charges. It also consumes cash before it produces any: stock, equipment and staff are paid for now, and the extra sales are collected later. That is why growth taken on faster than the cash coming in can support puts survival at risk, and why a growing business can fail while its order book is full.

### Objectives in the public sector

The public sector is the part of the economy owned and controlled by national or local government on behalf of the public. A ministry, a municipal water department, a state-owned power utility and a public hospital are all in it. Their objectives are set within government policy rather than by private owners.

Four recur. **Service provision** - supplying the service to everyone entitled to it, including users it would cost a private firm more to reach than they pay. **Standards of quality and access** - stated levels of reliability, waiting time or coverage. **Staying within the allocated budget**, because the money comes from taxation and is fixed in advance. And **wider social aims** - employment, the development of a region, the supply of something the government judges the country needs.

### Why the public sector is measured differently

A public sector organisation is usually asked to cover its costs, or to earn a stated return, rather than to maximise profit. The reason is not that profit is forbidden. It is that the owner is the state and the reason the organisation exists is the service, so a surplus is a means of funding more service rather than the point of the exercise. An electricity utility told to maximise profit would raise prices and stop connecting remote settlements, which is the opposite of what it was set up to do.

What replaces profit as the measure is **value for money**: the amount and quality of service obtained for the money spent. It is applied because the organisation answers to government and, through government, to taxpayers who had no choice about paying.

Value for money is harder to measure than profit, and that is the practical difficulty of the sector. Profit is one number produced by the accounts. Service quality is several numbers, some of them - dignity, safety, fairness of access - not numbers at all. A public organisation judged only on the cost half of value for money has an incentive to cut the service half, which is why budget discipline on its own is an incomplete measure.

### Social enterprises

A social enterprise trades in goods or services in the way any business does, but exists to achieve a social or environmental purpose, and reinvests most or all of its surplus in that purpose instead of distributing it to owners.

The trading is what distinguishes it from a charity. A charity is funded mainly by donations and grants; a social enterprise earns its income by selling something. That is why trading performance is an objective for it at all: no sales, no social work. A workshop that employs people with disabilities to make paving bricks, and sells those bricks at a commercial price, is a social enterprise. The same workshop funded by donations and giving the bricks away is a charity.

### The double demand on a social enterprise

A social enterprise sets objectives on two dimensions at once. It has to earn enough revenue to keep trading, and it has to achieve a social or environmental result it can show. Failure on either one is failure.

Most of the time the two support each other: more sales means more employment, more clean water sold, more waste recycled. The difficulty comes at the point where they pull in opposite directions.

Take a clinic run as a social enterprise in a low-income area, charging N$30 a visit against a cost of N$60 a visit, with the difference met by a grant that ends in a year. Raising the fee to N$60 makes the clinic self-supporting and meets the financial objective. It also prices out some of the patients the clinic exists to serve, which moves it away from the social objective. Holding the fee at N$30 keeps those patients and leaves the clinic dependent on finding another grant.

Neither course is simply right. One objective has to be traded against the other, and that trade-off is the central difficulty of the form. A commercial business facing the same arithmetic has an easier decision, because it has only one objective to satisfy.

### Three organisations, one street

Three organisations trade along the same road in Otjiwarongo.

**Kudu Bakery** is owned by the family that runs it. Its objective this year is to raise profit by enough to pay for a second oven while the owners keep their evenings free. That is profit satisficing with a growth purpose: the family could earn more by opening on Sundays and has decided not to.

**The municipal water depot** is owned by the town council. Its objective is to keep every connected household supplied for at least 22 hours a day and to stay inside the N$4 200 000 it has been allocated. Nothing in that objective mentions profit, because the depot's owner wants water delivered, not a return on capital.

**Omulunga Sewing** is a social enterprise employing twelve women who were previously out of work. Its objectives are to sell N$900 000 of school uniforms this year and to add four more trainees. The first objective pays for the second; without the sales there is no training.

Same street, same customers, same cost of electricity. The objectives differ because the owners differ.

### Why objectives matter at all

Ask what a business loses by not stating its objectives, and the answer is sharper than it first looks.

The first loss is a criterion. Every decision is a choice between options, and calling one option better than another only means something against a stated goal. Cutting the price of a product wins volume and loses margin. Which of those is the improvement? The question has no answer until the business has said whether it is trying to grow its share of the market or to raise its profit this year. Without an objective, an argument between two managers is a clash of preferences with nothing to settle it.

The second loss is measurement. A stated target with a time limit turns a result into something comparable with what was planned. Revenue of N$5 400 000 is neither good nor bad on its own; against an objective of N$5 000 000 it is a result the business can act on, and it tells the business something about its own forecasting as well.

### Coordination and motivation

The third thing objectives do is coordinate. A business is several departments doing different work, and each of them can improve its own position in ways that damage another's. Production lowers its cost per unit by making long runs of one item, which leaves sales without the range customers ask for. Sales promises a delivery date production cannot meet. A shared objective does not abolish those conflicts, but it gives them a common reference: both departments can be asked how their choice serves the objective the business has stated, and the answers can be compared.

The fourth is motivation, and it runs both ways. A stated objective may raise motivation where employees see it as achievable and can see what their own part in it is. It may lower motivation where it is seen as out of reach, or as having nothing to do with the work the employee actually does. A packhouse worker told the company aims to increase shareholder value by 15 per cent has been given an objective that does not connect to anything he controls. Told that his line is to cut wastage from 6 per cent to 4 per cent by June, he has one that does.

### Corporate social responsibility

Corporate social responsibility, usually shortened to CSR, is the principle that a business accepts responsibility for the effects of its activities on society and on the environment, beyond the legal minimum and beyond the interests of its owners alone.

The two words *beyond* are the definition. Obeying the law is not CSR; every business has to do that. Paying shareholders is not CSR either. CSR begins where a business chooses to take account of people it is not obliged to take account of - the community around a mine, the workers in a supplier's factory, the users of a river downstream of a plant.

### The triple bottom line

The triple bottom line is the way CSR is turned into something a business can report. Instead of measuring itself on one result, the business measures itself on three: economic, meaning financial; social; and environmental. The shorthand is profit, people and planet.

**Economic** covers the familiar figures - revenue, profit, cash generated, wages paid, taxes paid. **Social** covers the effects on people: jobs created, training given, safety record, treatment of suppliers, work done in the community. **Environmental** covers the effects on the physical world: water used, energy used, waste produced, land rehabilitated, emissions.

The mechanism by which this changes behaviour is worth stating plainly, because it is the reason the triple bottom line is more than a report. Managers act on what they are held to account for. A plant manager assessed only on cost per tonne makes decisions about water and waste as an afterthought. The same manager assessed on cost per tonne *and* water used per tonne has a reason to look at the second figure before he decides, not after. Changing what is measured changes what gets decided.

### What adopting the triple bottom line does to costs and returns

Adopting social and environmental objectives usually raises costs in the short term. Paying above the going rate, treating effluent before discharging it, auditing a supply chain and training staff who might leave all cost money in the year they are done. The return, where it comes, arrives later and through several steps: customers who prefer a business they trust, employees who stay longer and cost less to replace, communities and authorities that raise fewer objections to what the business wants to do next, and a lower risk of the fines, boycotts and lost contracts that follow a scandal.

That asymmetry - certain cost now, uncertain benefit later - is the honest difficulty with CSR, and it is why a business under cash pressure finds the commitment hardest to make. It is also why a business may be tempted to take the reputational benefit without the cost, by publicising social or environmental claims it cannot support. That route carries its own risk: customers, employees and campaigners may check the claims, and a claim found to be false can cost more reputation than the genuine spending would have bought.

### Mission, aims, objectives, strategy, tactics

These five words are often used loosely, and the difference between them is examinable, so it is worth fixing each one precisely.

A **mission statement** is a short written statement of what a business exists to do and what it stands for, written to be understood by employees, customers and other stakeholders. It has no measure and no deadline, so a business has no way of reporting that its mission has been achieved.

**Aims** are the broad long-term goals that follow from the mission. "Become the region's preferred supplier of fresh produce" is an aim: it points in a direction without saying by how much or by when.

**Objectives** are the specific, measurable, time-limited targets that turn an aim into something a business can work towards and afterwards check. "Raise the share of Oshakati retailers we supply from 30 per cent to 45 per cent by December next year" is an objective.

**Strategy** is the long-term plan of action, committing significant resources, chosen to achieve the objectives. Building a cold store is a strategy. It takes years, costs a great deal and is hard to reverse.

**Tactics** are the short-term, smaller-scale decisions taken day to day to carry the strategy out. Running a two-week price promotion on tomatoes while the new cold store fills is a tactic. It is cheap, quick and easily changed.

### The chain worked through one business

Namib Trails runs desert tours from Swakopmund.

*Mission*: to show visitors the Namib without damaging it.
*Aim*: to grow the business while reducing its impact on the dunes.
*Objective*: to carry 20 per cent more visitors in the year to March while cutting fuel used per visitor by 10 per cent.
*Strategy*: replace the six-seat vehicles with twelve-seat vehicles over two years and move to fixed routes.
*Tactic*: this month, combine the two Tuesday departures into one full vehicle.

Read downwards, each level is the previous level made more concrete. Read upwards, each level explains why the one below it is being done - the Tuesday departures are combined because the fuel objective says so, and the fuel objective exists because the mission says so.

The chain is also where things break. A mission printed and hung in reception, with planning done without ever referring to it, leaves a purpose nobody acts on. Tactics chosen with no strategy behind them - a discount this week, a new service next week - leave activity that serves no stated purpose and consumes resources the strategy needed. Either break wastes the work done at the other levels.

### Common errors

**A mission statement is not an objective.** It states purpose. It carries no measure and no deadline, so it cannot be achieved, missed or reported on. An answer that offers a mission statement where an objective was asked for has not answered the question.

**Profit satisficing is not failed profit maximisation.** It is a deliberate choice to stop short of the maximum in exchange for something the owner values more.

**A social enterprise is not a charity.** It earns its income by trading. Describing it as an organisation that relies on donations loses the feature that defines it.

**A public sector organisation with a financial target is not pursuing profit.** The target exists to control what the service costs the taxpayer, not to enrich an owner.

**An objective without a date is not an objective.** "Increase sales" is a direction of travel. Nothing about it can ever be marked achieved or missed.

---

## Setting objectives, and making them work

### The stages of a business decision

Business decision-making runs through an ordered sequence. The order matters, because each stage supplies what the next one needs.

1. **Set the objective.** Decide what the decision is meant to achieve.
2. **Gather information.** Collect the data the comparison will need - costs, prices, capacity, demand, the views of the people affected.
3. **Identify and compare the options.** List the courses of action genuinely open, and measure each against the objective.
4. **Choose one.** Take the decision, and record why that option rather than another.
5. **Implement it.** Allocate the money, assign the people, communicate what is changing and by when.
6. **Review the outcome.** Compare what happened with the objective, and feed what is learned back into the next decision.

The sequence is a loop, not a line: the review stage is the setting stage of the decision that follows.

### Where objectives enter the sequence

Objectives enter the sequence twice, and the two entries do different work.

At stage three they are the **criterion**. Options can only be ranked against something, and the objective is that something. A transport firm choosing between two vehicles ranks them differently depending on whether the objective is to cut cost per kilometre or to cut delivery times. Same two vehicles, same information, different answer - because the criterion changed.

At stage six they are the **benchmark**. Reviewing an outcome means comparing it with what was intended, and what was intended is the objective. Without one, a review can describe what happened but cannot say whether it was good enough.

The objective also does quieter work at stage three: it narrows what counts as an option at all. A business whose objective is to grow market share in its existing region does not spend time costing an export venture. That saves the effort of comparing options the business was never going to take.

### What skipping a stage costs

Each stage skipped has a cost of its own, and they are different costs.

Skip the objective and the decision has no criterion, so it gets made on whichever argument is put most forcefully. Skip the information and the comparison rests on assumption - the manager's impression of what customers want stands in for evidence about what they buy. Skip the comparison and the first workable option is taken as though it were the best one. Skip implementation planning and a decision that was taken is not actually carried out: nobody was given the money, the time or the instruction. Skip the review and the business never finds out whether the decision worked, so the same mistake stays available to be made again.

### How much process is worth it

Working through six stages takes time and money, and not every decision is worth it.

Scientific decision-making gathers data and compares options against the objective in a structured way. It suits decisions that are large, hard to reverse and repeated - where to site a depot, whether to buy a machine that will run for ten years. A decision made on judgement alone skips the information and comparison stages. It is faster and cheaper, and it suits decisions that are small, reversible or too urgent to research: a restaurant owner deciding within the hour whether to take a booking for forty people is not going to commission a study.

The cost of the structured route is delay and expense; the cost of the quick route is that the outcome rests entirely on how good the judgement was. The sensible rule is to match the effort to the size and the reversibility of the decision.

### Why objectives change over time

An objective is set for the circumstances of a period. When those circumstances change and the objective does not, the business directs effort at a target it no longer needs - and, worse, keeps measuring its people against it.

The common pattern follows the age of the business. In the first years the objective is **survival**: the business has little cash, no reputation and customers who have not yet formed a habit. Once it is established, attention moves to **growth and profit**: the business can afford to invest, and wants to. Once it is mature and its market is no longer expanding quickly, objectives move again - to **defending market share**, to **raising the value of the owners' shareholding**, or to **spreading into new products or markets** because the existing one has stopped growing.

The pattern is common rather than universal. A firm can be pushed back into survival by one bad year at any age.

### What forces a change of objective

Events that move an objective fall into three sorts.

**External change.** A new competitor takes 10 per cent of the market; a recession cuts what customers can spend; a drought halves the cattle a meat processor can buy; a new technology makes the existing product obsolete; a change in the law or in the exchange rate alters what imports cost. None of this requires anything inside the business to change, and all of it can make the existing objective unreachable or irrelevant.

**Internal change.** A new owner or manager arrives with different priorities. Cash runs short, and a growth objective gives way to a survival objective within a month. A key person leaves. The owner decides to hand the business to a son or daughter and starts managing for a smooth handover rather than for this year's profit.

**Achievement.** The plainest reason of all: the objective was reached. A business that set out to open six branches and has opened six needs a new objective, and choosing the next one is a real decision rather than an administrative step.

### Targets and budgets

An objective stated for a whole business cannot be acted on by any one person in it. Nobody in the packhouse can "raise revenue by 20 per cent". The objective has to be broken down until it reaches something an individual or a department can actually do, and that is what targets and budgets are for.

A **target** is a specific level of performance that a department, team or individual is expected to reach within a stated period. It turns a business-wide objective into something one part of the business can act on.

A **budget** is a financial plan for a future period setting out planned income and planned expenditure. It gives a department the money it needs to reach its target, and it limits what the department may spend in reaching it.

The two go together. A target without a budget asks for a result and supplies no means of getting it. A budget without a target hands over money with no statement of what it is to achieve. Cascading works by division: the objective is broken into departmental targets whose achievement together adds up to it, and each target is funded by a line in a budget.

### Cascading an objective: a worked example

Oshakati Fresh Produce earned revenue of N$8 000 000 last year. The owners set an objective of raising revenue by 20 per cent this year.

**The revenue objective.** The increase required is N$8 000 000 x 0.2 = N$1 600 000, so the objective is N$8 000 000 + N$1 600 000 = N$9 600 000 of revenue for the year.

**The sales target.** Divided evenly across the year, that is N$9 600 000 / 12 = N$800 000 of sales a month. The sales department now has something it can act on and be measured against each month rather than once a year.

**The budgets that support it.** Reaching the higher figure needs more stock bought, more deliveries run and more selling done, so the objective is funded as well as stated: a marketing budget of N$240 000 for the year, a transport budget raised by N$180 000, and a purchasing budget raised in line with the extra volume.

Notice the check the arithmetic makes possible. Twelve months at N$800 000 is N$9 600 000, which is the objective, so the targets add up to what they are supposed to add up to. If the monthly target had been set at N$750 000, the department could hit its target every month and the business would still miss its objective by N$600 000. Cascading is only sound when the parts sum to the whole.

### Budgets as control, not just as money

Once targets and budgets exist, the business has something to compare actual performance against, and that comparison is what makes them useful during the year rather than only at the end of it.

The difference between what was planned and what happened is a **variance**. A favourable variance means the business did better than planned - revenue above target, spending below budget. An adverse variance means the opposite.

An adverse variance found in March is a signal, and its value lies in when it arrives. Oshakati Fresh Produce selling N$700 000 in March against a target of N$800 000 is N$100 000 behind after one month. Discovered then, the business can add a promotion, chase the retailers who have cut orders, or revise the objective. Discovered in December, the same information is a post-mortem. This is why the period matters: a target for the year alone gives one signal, too late to act on.

### Communicating objectives

An objective changes nobody's behaviour until the people expected to act on it know what it is, what their own part in it is, and by when it has to be reached. An objective known only to the board is a sentence in a document.

Three things have to be communicated, not one. The objective itself. The individual's contribution to it - which is the part most often left out, and the part that decides whether an employee can act. And the deadline.

Communicating an objective may raise motivation. The mechanism is straightforward: an employee who can see that the objective is reachable, that his or her own effort moves it, and that the tools and time to do it have been provided, has a reason to make the effort. Clear objectives also reduce wasted work, because people stop guessing at what matters. Where an objective is linked to recognition or reward, the reason to act on it strengthens further.

### When communicating an objective backfires

The same act of communication can damage performance, and in three recognisable ways.

**A target seen as out of reach demotivates.** A team that sold 120 units last month and is told to sell 200 next month, with nothing else changed, may conclude the target cannot be met and stop treating it as real. Effort falls rather than rises, and the target has done the opposite of what it was set to do.

**A target imposed without consultation invites resistance.** People asked to commit to a number they had no part in choosing, and which may rest on assumptions they know to be wrong, tend to comply narrowly rather than co-operate.

**A target that measures one thing pushes out everything else.** Pay a sales team on volume alone and discounts appear; the volume target is met and the margin the business actually wanted is gone. Measure a call centre on calls handled per hour and calls get ended quickly, whether or not the problem was solved.

The common repair for the first two is two-way communication: letting employees respond to a proposed objective before it is fixed. That tends to produce objectives that are better informed, because the people doing the work know things the people setting the target do not, and more readily accepted, because those people helped shape them. It takes longer, which is the price.

### SMART objectives

SMART is a test applied to the wording of an objective. It asks five questions.

**Specific.** Does it say exactly what is to be achieved, and by whom? "Improve customer service" does not. "Answer every telephone enquiry within three rings" does.

**Measurable.** Is there a number, so that achievement can be established rather than argued about? Without one nobody can say afterwards whether the objective was met.

**Achievable.** Is it within reach of the people asked to reach it, given their skills and numbers? A target beyond them demotivates instead of motivating.

**Realistic.** Do the resources - money, equipment, time, stock - support it? A bakery with one oven cannot double output whatever the staff are told.

**Time-limited.** Is there a date? An objective with no date stays open to postponement, and nothing forces anyone to report on it.

Achievable and realistic are close together and are often confused. The useful distinction: *achievable* asks about the people, *realistic* asks about the resources.

### Rewriting a weak objective

"Increase sales."

Specific? No - which sales, of what, by whom? Measurable? No - one extra unit would satisfy it. Achievable and realistic? Impossible to say, with no figure. Time-limited? No.

Rewritten: "Increase unit sales of bottled water by 10 per cent in the twelve months to 31 December."

Now the product is named, the measure is unit sales, the size of the increase is 10 per cent, and the date is fixed. The business can check monthly whether it is on course, and on 31 December it can say plainly whether the objective was achieved. Whether 10 per cent is achievable and realistic is then a question about this business - its staff, its capacity, its market - which is exactly the question the test is meant to force somebody to ask.

### What SMART does not test

SMART tests how an objective is written, not whether it is the right objective to hold. A business can write a perfectly SMART objective to pursue a market it should be leaving. The test is a check on drafting, and passing it is not evidence that the strategy behind it is sound.

Two further limitations are worth holding. A short time limit pulls a business towards results that show up quickly, at the expense of results that take longer to arrive - staff development, research, the repair of a reputation. And what is easy to measure is not always what matters most: safety culture, service quality and the goodwill of a community are all real and none of them reduces neatly to a number, so an organisation that sets only measurable objectives can find itself managing only the measurable part of its business.

### Business ethics

Business ethics are the moral principles a business applies to what it does, setting a standard of conduct that goes beyond what the law requires of it.

*Beyond the law* is the working part of the definition, and it is what makes ethics a matter of objectives rather than of compliance. Paying the minimum wage set by law is compliance. Deciding to pay above it because the legal minimum is not enough to live on is an ethical decision.

A **code of practice** sets out in writing the standards of conduct a business expects of its employees and its suppliers. It matters because it turns a general intention into something specific enough for an employee to follow and for the business to enforce - what gifts may be accepted, how suppliers are selected, what is checked before a contract is signed.

### How ethics changes objectives and activities

Ethics works on a business in two ways.

It **adds objectives**. Fair treatment of workers in the supply chain, honest marketing, care of the environment, and fair dealing with small suppliers all become things the business is trying to achieve, alongside its financial objectives and sometimes in tension with them.

It also **removes options**. Some courses of action would meet a financial objective by means the business is not prepared to use: paying an official to secure a contract, describing a product as something it is not, buying from a supplier whose costs are low because its workers are children. An ethical position rules those out before the comparison of options begins, which is why ethics shows up at stage three of the decision sequence rather than at the end of it.

The effect on activities follows: suppliers are audited, contracts contain conditions, staff are trained on what they may and may not do, and some profitable business is turned away.

### The cost now, the return later

Acting ethically often raises costs in the short term. A fairer price to a supplier costs more than the cheapest one available; safer equipment costs more than the minimum that passes inspection; a cleaner process costs more than discharging waste untreated. Those costs land in this year's accounts, so unit cost rises and, if the price is held, margin falls.

Where a return comes, it comes through several steps and over a longer period. Customers who trust a business may buy from it again and may accept a higher price than they would pay a business they do not trust. Employees who are treated well tend to stay longer, which lowers recruitment and training costs and keeps experience in the business. Communities and authorities raise fewer objections to what a trusted business wants to do next. And the risk of fines, boycotts, lost contracts and the management time an investigation consumes falls.

The chain is real but conditional. It reaches higher profit only where enough customers value the conduct highly enough to change what they buy, and where the business is visible enough for the conduct to be noticed. For a supplier of components nobody sees, the reputational step is weak and the cost is the same, which is why the strength of the case for ethical spending varies with how visible the business is to the people whose opinion of it matters.

### Whose standard?

A business trading in several countries meets a practical difficulty: ethical standards differ between societies and change over time, so conduct treated as acceptable in one market may be unacceptable in another. Payments that oil a transaction, the age at which people may work, the hours expected of them and the obligations owed to an extended family are all judged differently in different places.

Two positions are available. Apply one standard everywhere, usually the stricter one - simple to explain, consistent, and costly where it puts the business at a disadvantage against local competitors who do not. Or apply local standards - cheaper and locally accepted, but it leaves the business open to the charge that it treats some workers as worth less than others, and exposed if the practice is reported in its home market.

Most large businesses that have thought about it settle on a floor: a small number of standards applied everywhere and in all markets - no child labour, no bribery, no unsafe workplace - with local practice accepted above that floor. The decisive consideration is usually which standard the business could defend publicly if its conduct in one market were reported in another, because that is the situation in which the cost of having chosen the cheaper standard actually arrives.

### Holding the topic together

Objectives are the spine of this part of the syllabus. An objective is a measurable goal with a date. What it is depends on who owns the organisation and why it exists. Why it matters is that it supplies the criterion for choosing between options and the benchmark for judging the result. How it reaches the work is through targets and budgets, and through communication that tells each person what their part is. How it is checked is the SMART test on the wording and the variance report on the outcome. And what limits it is ethics, which adds objectives of its own and rules out some of the ways a financial objective might otherwise be met.

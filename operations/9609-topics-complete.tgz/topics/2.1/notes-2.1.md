# 2.1 Human resource management (HRM)

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain the role of human resource management in meeting the objectives a business has set itself.
- Explain the reasons for and the role of a workforce plan, calculate labour turnover, and analyse what high and low labour turnover mean for a business.
- Explain the recruitment process and the documents it produces, compare recruitment methods and internal with external recruitment, analyse the selection methods a business can use, and explain what an employment contract does.
- Define redundancy and dismissal, distinguish voluntary from involuntary redundancy and fair from unfair dismissal, and explain why the difference matters to a business.
- Analyse the relationship between HRM, employee morale and welfare, including work-life balance, and analyse the impact of diversity and equality in the workplace on a business.
- Explain induction, on-the-job and off-the-job training, analyse the impact of training and development on a business, and evaluate development aimed at intrapreneurship, multi-skilling and flexibility.
- Analyse how cooperation between management and the workforce benefits both sides, and analyse the impact on employers and employees of trade union involvement, including collective bargaining.

---

## What HRM is for

### Human resource management

Human resource management is the business function responsible for planning, recruiting, developing, rewarding and retaining the people a business needs in order to meet its objectives.

The words doing the work are "in order to meet its objectives". HRM is not a purpose of its own sitting beside the business's purpose. Every task it carries out - a vacancy filled, a training course booked, a pay scale revised - exists because some objective the business has set needs people who are able and willing to do the work.

### Turning an objective into a workforce requirement

A business objective is a statement about output, not about people. "Open two new branches, in Oshakati and Rundu, by June" says nothing directly about staff. HRM's first job is to translate it: each branch needs a manager, six counter staff and a share of one supervisor; all of them need to serve customers in more than one language; and all of them need to be in post and trained before the doors open.

That translation answers four questions. How many people. Holding which skills. By when. At what labour cost. Together those answers are the workforce requirement, and the rest of HRM's work - recruiting, selecting, training, paying, retaining - is the business of meeting it.

Notice what HRM does not do. It does not open the branches. It changes what the workforce is able to do and willing to do, and the branches open because the workforce opens them. That is why an HRM decision shows up in output, cost or quality only once the workforce behaves differently, which is weeks or months after the decision was taken rather than the same afternoon.

### Four routes from HRM to an objective

HRM contributes to organisational objectives along four routes, and a good answer names the route it is using rather than saying HRM "helps".

**Supply.** Getting the right number of people, holding the right skills, in place at the time the objective needs them. A growth objective that arrives without the staff to serve the extra customers is not met.

**Productivity.** Raising output per employee through training, job design and motivation, so that the same objective is reached with fewer labour hours, or a larger one with the same workforce.

**Cost.** Holding labour costs to what the plan allows, through the mix of contracts used, the pay structure, and control of overtime and absence. Labour is a large part of total cost in most service businesses, so this route runs straight into a profit objective.

**Retention and compliance.** Keeping employees willing to stay, so that experience is not lost and recruitment spending stays low, and keeping the business inside the employment law of the country it operates in, so that it is not paying for avoidable disputes.

### Why HRM decisions have to be taken early

Recruiting and training take months, not days. A vacancy has to be defined, advertised, applied for, shortlisted, interviewed and offered; a notice period then runs; and the appointee is not fully productive on the first morning.

The consequence for a business is a timing problem rather than a cost problem. If the objective changes faster than the workforce can be changed, the workforce lags behind the plan: output targets are set against a staffing level that does not yet exist, and the gap is filled by overtime, by agency cover or by not meeting the target. The longer the lead time on a particular skill, the earlier the HRM decision has to be taken - which is why a business that needs a qualified electrician in nine months has an HRM decision to take now, and one that needs six more shelf-packers in November does not.

### A lodge that changes what it sells

A 40-room lodge near Swakopmund decides to move from serving mainly self-drive tourists to hosting corporate conferences. The building is unchanged and the rooms are unchanged, so the capital side of the decision is small.

Almost all of the work is HRM. The objective needs staff who can run audio-visual equipment, handle group bookings and invoice companies on account - none of which the current front-desk team does. The translation into a workforce requirement is: one events coordinator recruited externally, because nobody inside holds that experience; four existing front-desk staff trained on the booking system and on invoicing; and kitchen hours redistributed, because conference catering peaks at midday rather than in the evening.

The lodge's objective therefore depends on HRM twice over. Through supply, because the coordinator has to be found in a small local labour market. And through productivity, because the same front-desk staff have to do a different and more demanding job without the wage bill rising.

### How much HRM matters is not the same in every business

How far an objective rests on HRM depends on how far it rests on people. In the lodge above, service quality is what the customer is buying, and it is produced almost entirely by employees, so an HRM failure and a failure of the objective are close to the same event. In a business where output is set mainly by machinery - a bottling line running to a fixed cycle - a change in staffing moves output far less, and capital investment does more of the work.

That comparison is the judgement to reach when a question asks how important HRM is: it is more important the more the objective depends on what employees choose to do, and less important the more it is determined by equipment, by location or by price.

### Where this connects

The workforce requirement this section describes is what the next section turns into a document: the workforce plan. The retention route leads into labour turnover and into morale and welfare, and the productivity route leads into training and development. HRM also supplies one of the inputs to operational capacity later in the course, because a business cannot produce more than its people and its equipment together allow.

---

## Workforce planning and labour turnover

### Workforce plan

A workforce plan is a statement of how many employees a business expects to need, with which skills and at what times, together with the actions it intends to take to close the gap between that requirement and the workforce it currently holds.

A plan is therefore two things joined together: a forecast, and a set of decisions that follow from it. A forecast on its own is a prediction. It becomes a plan when somebody writes down what will be done about it and by when.

### How a workforce plan is built

The plan is built in three steps, and they run in this order because each one needs the answer to the one before it.

**Step one: forecast the workforce required.** This comes out of the sales and output plans, not out of HRM. If the sales plan says 30% more units next year and each machine operator produces a known number of units, the required number of operators follows. For service work the same logic runs on customers served per employee, or beds, or rooms, or covers.

**Step two: audit the workforce held.** Count the current workforce by number and by skill, then adjust it for known departures - retirements whose dates are known, fixed-term contracts that end, and the resignations the turnover rate says to expect.

**Step three: state the gap and the actions.** The difference between the two is a shortfall or a surplus. The plan then sets out dated actions: recruit externally, promote and train internally, redeploy from a shrinking section, use overtime or temporary contracts for a short peak, or reduce numbers where the surplus is expected to last.

### Why a business bothers

Four reasons account for most workforce plans.

Demand is expected to change, upward or downward, and the workforce has to change with it. Technology or working methods are changing, so the skills needed are not the skills held - a warehouse installing scanning equipment needs fewer pickers and at least one person who can maintain the system. Retirements and resignations are expected, and both remove capability that has to be replaced. And some skills take a long time to obtain, whether by recruitment in a thin labour market or by training, so the decision has to be made long before the need bites.

The role of the plan, once written, is to convert those forecasts into actions with dates against them. That is what separates a business that fills a shortage before it stops output from one that discovers the shortage when a customer order cannot be met. It works the same way on a surplus: a business that sees a surplus coming can let it disappear through natural wastage - simply not replacing people who leave - while a business that does not see it coming is left paying for employees it no longer needs, or making redundancies it could have avoided.

One qualification belongs here rather than in a footnote. The plan rests on the demand forecast under it, so its usefulness falls as that forecast becomes less reliable. Where demand is volatile, a single predicted headcount is a guess, and committing to it produces one of two errors: permanent staff who turn out to be surplus and expensive to remove, or too few people and orders the business cannot fill. Businesses in that position tend to plan against a range of outcomes and to meet the uncertain part of the requirement with fixed-term contracts and overtime, which cost more per hour but commit the business to nothing. The volatility changes what the plan should commit to; it does not make planning pointless.

### Labour turnover

Labour turnover is the proportion of a business's workforce that leaves and has to be replaced over a period, normally measured over one year.

It counts leavers of every kind: resignations, retirements, dismissals, redundancies and the end of fixed-term contracts. Some businesses also calculate a separate figure for resignations alone, because that is the part management can most readily influence, but the measure named in this topic is the whole of it.

### The formula and what each part means

**Labour turnover (%) = (number of employees leaving during the period / average number of employees during the period) x 100**

The numerator is a count of people who left during the period. The denominator is the *average* number employed across the same period, usually taken as the opening headcount plus the closing headcount, divided by two. The result is a percentage of the workforce, not a number of people, and it belongs to a stated period - a rate quoted without its period is meaningless, because the same business will show a different figure over a quarter and over a year.

### Worked calculation

A Windhoek logistics firm employed 250 people on 1 January and 230 on 31 December. During the year 18 people left.

Average number employed = (250 + 230) / 2 = 240 employees.

Labour turnover = 18 / 240 = 0.075, which is 7.5% for the year.

**Interpretation.** Over a year the firm lost about one employee in every thirteen. On its own that figure says nothing about whether the business has a problem. It becomes useful in three comparisons: against the same firm's rate last year, against other logistics firms in the same town, and against the cost of replacing a driver. If replacing and retraining one driver costs the firm around N$12 000 in advertising, licence checks, induction and lost delivery time, then 18 leavers represent roughly N$216 000 a year of spending that exists only because people leave.

### Common errors

**Using the closing headcount as the denominator.** The measure is defined on the average number employed over the period. In a business whose size is changing quickly the two give noticeably different answers: the firm above would show 18 / 230, or 7.8%, on the closing figure. Use the average.

**Reporting turnover as a number of people.** Turnover is a rate, expressed as a percentage of the workforce. Two businesses that each lose 18 people do not have the same turnover if one employs 240 and the other employs 60; the second has lost nearly a third of its staff.

**Treating a high rate as automatically bad.** A rate is high or low only against something. Seasonal retail and hospitality work at rates that would be alarming in an engineering firm, because the jobs are short by design.

**Reading a cause into the number.** The figure records how many people left, not why. It identifies that something may be wrong without identifying what, and the diagnosis comes from exit interviews, comparison of pay with local employers, and evidence about workload.

### What high labour turnover does to a business

Start from a rate that has risen sharply. Three effects follow, and they compound.

Spending rises first. Every leaver has to be advertised for, selected and inducted, and each of those steps costs money and management time that would otherwise have gone into running the operation.

Capability falls next. The person who left took the knowledge of how the job is actually done - which customer wants what, where the faults usually appear - and the replacement does not have it. Output per employee falls during the vacancy and again during the learning period, and errors and customer complaints tend to rise while it lasts.

The two then feed each other. The employees who remain absorb the extra work while the post is empty, which raises their workload and their frustration, and some of them leave too. A business that reaches this stage can find that the rate keeps climbing for reasons created entirely by the rate itself.

Where this ends depends on the skill level. Where the work is quickly learned, the cost is mostly administrative and the business absorbs it. Where an employee takes a year to become fully productive, a high rate means a workforce permanently part-trained, and the effect reaches quality, delivery reliability and ultimately the customers who decide whether the business keeps its orders.

### The case that some turnover is useful, and that very low turnover has costs

Turnover is not a defect to be driven to zero. Some of what it does is what a business would pay for.

Leavers make room for people who bring skills and ways of working the business does not have, which is how practice from elsewhere reaches it. Turnover moves out employees who were performing poorly without the business having to dismiss them. And where numbers need to fall, a business with turnover can shrink by not replacing people, which avoids redundancy payments and the damage that compulsory redundancy does to those who stay.

Very low turnover has the mirror problem. Experience stays, and recruitment spending is small, but the workforce sees few new ideas and promotion routes block up: if nobody above leaves, an ambitious employee below has nowhere to go, and may leave for that reason alone. A business with almost no turnover in a changing market can find that its skills have aged with its workforce.

So the same rate can be damaging in one business and useful in another, and the judgement rests on the sector norm, the skill level, and what one replacement actually costs.

### Where this connects

The turnover rate is an input to the workforce plan: a business of 240 employees losing 7.5% a year has to plan to replace about 18 people annually before it recruits a single person for growth. Turnover also connects forward to morale and welfare, which is where most of its causes sit, and to training, because a business that loses trained employees does not keep the return on what it spent training them.

---

## Recruitment, selection and employment contracts

### Recruitment and selection are two different jobs

Recruitment is the process of identifying a vacancy and attracting a field of suitable applicants from which a selection can then be made.

Selection is the process of choosing, from the applicants that recruitment has attracted, the one whose evidence best matches the person specification.

Recruitment builds the field; selection picks from it. The distinction matters because the two fail differently. Weak recruitment leaves a business choosing carefully between applicants none of whom can do the job. Weak selection leaves it choosing badly from a strong field. A business that keeps making poor appointments has to work out which of the two it is doing.

### The recruitment process in order

**One: confirm the vacancy.** Somebody has left, or the workforce plan says a new post is needed. The first question is whether the post should be refilled as it stood, redesigned, split between existing staff or left unfilled - a vacancy is an opportunity to change the job, and the moment passes once the advertisement is placed.

**Two: write the job description.** What the post exists to do.

**Three: write the person specification.** What the holder must be able to bring.

**Four: choose a recruitment method and place the vacancy.** Advertisement, agency, online, or an internal notice.

**Five: receive and acknowledge applications**, and close the list on the stated date so that every applicant is judged on the same information.

Skipping step one produces a replacement for a job the business no longer needs. Skipping steps two and three produces an advertisement nobody can screen against, because there is no written statement of what a suitable applicant looks like.

### Job description and person specification

A **job description** sets out the title, purpose, duties, responsibilities, reporting lines and working conditions of a post. It describes the job, not the person who will hold it.

A **person specification** sets out the qualifications, skills, experience and personal attributes an applicant needs in order to do that job. It is normally divided into essential requirements, without which an applicant cannot be appointed, and desirable ones, which separate the good applicants from each other.

A simple test tells them apart. If a sentence could be printed on the office wall and stay true after the current holder leaves, it belongs in the job description. If it is about the person walking in, it belongs in the person specification.

### What the two documents are actually used for

The documents are written at the same time and used at different points.

The job description faces the applicant first: it tells them what they would be doing, which is what makes an application an informed one. It then stays in use long after the appointment, because it underpins the employment contract and supplies the standard against which the employee's performance is later reviewed.

The person specification faces the employer. It supplies the criteria used to screen applications and to compare candidates, and it is what keeps the comparison consistent between the first application read on Monday and the fortieth read on Thursday.

Because the person specification supplies the screening criteria, writing it carelessly has a direct cost. A specification that lists a requirement the job does not actually need - five years' experience for work that can be learned in six months, or a degree for a post where a trade certificate is what matters - narrows the field without improving the appointment, and screens out applicants who could have done the work well. In a thin labour market that can be the difference between a field of twelve and a field of two.

### Three recruitment methods

**Job advertisements** are placed where potential applicants will see them: in a newspaper, on radio, on a notice board at the premises, or in a trade publication. The advertisement reaches a wide and undirected audience, which is its strength and its weakness. It can reach applicants who would not otherwise have heard of the vacancy, and it produces unsuitable applications that still have to be read and screened. The cost is paid when the advertisement is placed, whether or not a good field results.

**Employment agencies** hold registers of candidates and screen on the employer's behalf. An agency saves the employer screening time and can reach people who are not actively looking for work, because it approaches them directly rather than waiting for an application. The employer pays a fee, often set as a percentage of the first year's salary, and the shortlist that comes back reflects the agency's reading of the person specification rather than the employer's own - which is why the specification has to be written precisely before an agency is briefed.

**Online recruitment** covers job boards, the business's own website and professional networks. It is cheap for each applicant reached and fast to place, and it can produce very large numbers of applications, which moves the employer's work from attracting applicants to filtering them. It reaches only applicants with reliable internet access and the confidence to apply online, which in parts of Namibia leaves rural applicants outside the field altogether - so a business recruiting for a depot in a small town may still get a better response from a notice in the local shop than from a national job board.

### Choosing between the methods

The three methods differ in cost, in reach and in how much screening work they leave with the employer, so the choice follows the post rather than a general rule about which is best.

A scarce senior skill is often handled through an agency or a professional network, because the people who could do the job are already employed and are not reading advertisements. The agency fee is large in absolute terms and small against the cost of leaving a senior post empty for six months.

A local, quickly learned vacancy points the other way. The applicants live nearby and are looking, so a notice at the premises or an advertisement in a local newspaper reaches them at a fraction of the cost, and the screening work is manageable because the field is small.

The decisive question is usually where the suitable applicants actually are, and only then what each route costs.

### Internal and external recruitment

**Internal recruitment** fills a vacancy from among people the business already employs, by promotion or transfer. **External recruitment** fills it from applicants who are not currently employed by the business.

Internal recruitment is usually quicker and cheaper. There is no advertising to pay for, the candidate's record of performance is already known rather than claimed, and only the new duties have to be learned because the business, its systems and its customers are already familiar. The visible prospect of promotion also has an effect on everyone who did not apply: it tells them that effort here leads somewhere. Against that, a promotion leaves a second vacancy behind - the post the promoted employee has just left - so the recruitment problem moves rather than disappearing, and no thinking from outside enters the business.

External recruitment widens the field and can bring in skills and experience the business does not hold. It costs more in advertising and selection time, the appointee takes longer to reach full productivity because everything is new, and the evidence is less reliable: an application and two interviews say less about how somebody works than three years of watching them do it. Existing staff who wanted the post may also be discouraged, and a business that habitually recruits senior posts from outside can find its ambitious juniors leaving.

### Which route, and when

The comparison above only decides the question when both routes are genuinely open. Where the skills a post needs do not exist anywhere inside the business, external recruitment is the only route that can fill it, and the fact that internal promotion would have been cheaper is beside the point.

Where the skills do exist inside, the judgement turns on three things: the speed the vacancy has to be filled at, the effect on motivation of promoting or of passing over, and whether the business needs new thinking more than it needs continuity. A business in trouble, whose established way of working is part of what put it there, has a reason to go outside that a business performing well does not.

### Selection: six methods, used in combination

The selection methods named in this topic are the curriculum vitae or resume, the application form, the interview, the reference, testing, and the assessment centre. They are normally combined rather than used alone, because each one produces a different kind of evidence and each has a weakness that another can cover.

It helps to sort them by what they are evidence *of*. A curriculum vitae and an application form are claims made by the applicant about the past. A reference is a claim made by somebody else about the past. An interview is evidence about how the applicant presents and reasons now. A test and an assessment centre are evidence about what the applicant can actually do, produced under conditions the employer controls.

A typical process uses the written stage to reduce forty applicants to six, the interview to reduce six to two, and references or a test to decide between the last two and confirm that what was claimed is true.

### Curriculum vitae and application form

A **curriculum vitae**, also called a resume, is a document written by the applicant summarising personal details, qualifications, employment history, skills and referees.

An **application form** is a document written by the employer which every applicant completes, asking the same questions in the same order.

The difference is who holds the pen, and everything else follows from it. Because the applicant writes the curriculum vitae and chooses its format, it shows what that applicant decides to present, in whatever order flatters them most. That makes it quick and cheap for the applicant to send, so it produces a larger field, but it makes comparison slower for the employer, who has to hunt for the same fact in forty different layouts, and it means the claims on it are evidence to be checked rather than facts established.

Because the employer sets the questions on an application form, applicants become directly comparable point by point, and the form can force an answer on matters a curriculum vitae can quietly omit - the gap between two jobs, the reason for leaving the last one. The cost is that a form takes longer to complete than attaching an existing curriculum vitae, which can reduce applications from strong candidates who are not short of other offers.

### Interviews, references and testing

An **interview** is a structured conversation in which the employer questions an applicant to test the evidence in the application, explore how the applicant thinks, and judge suitability for the post. It is the only method that tests communication and manner directly and lets the employer follow up an answer with another question. Its weakness is that a judgement about months of future work is being made from a meeting of forty minutes, and it is open to interviewer bias - a preference for candidates who resemble the interviewer, or a first impression that colours everything after it. Using a set list of job-related questions, asked of every candidate, and more than one interviewer, reduces that weakness without removing it.

A **reference** is a statement about an applicant's past performance, conduct or reliability, obtained from a previous employer or another named person who has known the applicant in a working capacity. Its value is verification: it comes from somebody who has watched the applicant work over a long period, which the written methods cannot offer. Its limitation is that the applicant chooses the referees, and many employers limit what they are prepared to confirm in writing, often to dates of employment and job title. A reference therefore tends to rule an applicant out rather than separate two strong ones.

**Testing** means setting applicants a standardised task - an aptitude test, a skills or practical test, or a psychometric test - and scoring every applicant on the same basis. A test gives a directly comparable measure of something the job needs, which an interview can only infer from what the applicant says about themselves. The evidence is worth only as much as the test's fit to the job: a typing test for a typing job measures the work itself, while a general reasoning test for a warehouse post separates applicants on a basis that has little to do with the work they would be doing.

### Assessment centres

An **assessment centre** is an extended selection event, usually lasting one or more days, at which a group of applicants is observed by several assessors across several exercises - group tasks, presentations, written exercises, tests and interviews.

Its strength comes from the multiplication. Because evidence is gathered from several exercises and several assessors, one weak performance on one morning, or one assessor's prejudice, carries far less weight in the final decision than the same thing carries in a single interview. It also observes behaviour the shorter methods rarely reach: how an applicant works with other people, and how they behave when a task is going badly.

The cost is the limitation. Assessors are taken off their own work for a day or more, a venue and materials are needed, and applicants have to be able to give up the time. That confines the method to senior posts, where the cost of a wrong appointment is large, and to big graduate or trainee intakes, where one event selects several people at once and the cost is spread over all of them.

### How much selection is enough

Selection is itself an investment, and the amount worth spending depends on what a wrong appointment would cost.

Where a mistake means a short notice period, a quick replacement and a few weeks of ordinary output lost, an application form and one interview may be proportionate, and an assessment centre is money spent on certainty the business does not need.

Where a mistake means a year of poor decisions by a branch manager, or the loss of a training investment that takes eighteen months to recover, a longer process can pay for itself several times over. The decisive factor is the cost of being wrong, not the cost of the method.

One condition sits under all of it: extra selection stages only improve the decision if they produce evidence relevant to the job. A second interview that asks the same questions again adds cost without adding information.

### Selecting a workshop supervisor

A family-owned panel-beating workshop in Walvis Bay, employing 22 people, needs a supervisor. The job needs three things: the trade skill itself, the ability to schedule work across four bays, and the authority to correct people who have been colleagues for years.

A curriculum vitae will establish the trade qualification and the years worked, and nothing more - the other two requirements are not the kind of thing an applicant can demonstrate on paper. A practical test settles the first requirement properly, because panel work is visible: give each shortlisted applicant a damaged wing and a time limit. The scheduling requirement is best tested by a short written exercise - here are seven jobs, four bays and two absent staff, plan the week - which is a test rather than a question about a test.

The third requirement is the hard one, and it is why the owner should interview with a second person present and ask for evidence of occasions rather than opinions: what the applicant did the last time somebody senior to them was doing the job wrong. A reference from a previous employer is worth taking here, because conduct with colleagues is one of the few things a former supervisor is usually willing to comment on.

An assessment centre would answer all three questions well and is out of proportion to a single appointment in a 22-person workshop, where the assessors would be the owner and the only other manager, and the workshop would stop for a day.

### The employment contract

An employment contract is the agreement between employer and employee setting out the terms on which work is done, including duties, hours, pay, holiday entitlement, notice periods and the type and length of the engagement.

The contract is where recruitment ends. The job description supplies the duties, the offer supplies the pay, and the contract turns both into obligations that bind each side.

The exact rights an employment contract carries - minimum notice, minimum wage, maximum hours, what has to be recorded in writing - are set by the employment law of the country where the work is done. The general principle transfers between countries; a specific entitlement does not, so a statement about what an employee is owed has to be checked against the national legislation in force rather than assumed from another country's rules.

### Contract types trade security against flexibility

Contract types differ along one main dimension: how much security the employee gets, and how much flexibility the employer keeps.

A **permanent** contract has no end date. The employee has steady income and the protections that come with continuous service; the business is committed to a continuing wage cost, which it can normally reduce in just three ways: resignation, dismissal or redundancy.

A **fixed-term** contract ends on a stated date or when a stated task is finished. It suits a known, bounded need - a construction project, maternity cover - and the business is committed only for that period.

**Temporary and casual work, including zero-hours arrangements**, gives the business the most flexibility: hours are offered as demand requires, and are paid only when worked. The employee carries the uncertainty.

**Part-time** contracts are a separate question from security - a part-time post can be permanent - and they let a business match staffing to a daily or weekly peak, and reach people who cannot work full time.

Because a contract that gives the employer flexibility gives the employee less certain income, employees on casual and short fixed-term arrangements tend to leave as soon as steadier work is available. A business that staffs a core function this way often carries higher labour turnover and repeated recruitment cost as the price of the flexibility it bought, which is a real cost and belongs in the comparison.

### Where this connects

Contract choice belongs to the workforce plan as much as to the law, because the mix of permanent and flexible contracts fixes both the labour cost the business is committed to and the speed at which it can change the size of its workforce when demand moves. The selection methods here reappear whenever a business is judged on the quality of its appointments, and the end of an employment relationship - redundancy and dismissal - is the subject of the next section.

---

## Redundancy and dismissal

### Redundancy and dismissal

**Redundancy** is the ending of employment because the job itself is no longer required. The post disappears - through closure, falling output, relocation or a change in working methods - and the employee has not done anything wrong.

**Dismissal** is the ending of employment by the employer because of the employee's own conduct or capability. The job continues to exist and the business intends somebody else to do it.

One sentence holds the distinction: in redundancy the post has gone and the person was adequate; in dismissal the post remains and the person was not.

### Voluntary and involuntary redundancy

**Voluntary redundancy** means employees are invited to volunteer to leave, normally in return for a payment above the statutory minimum. **Involuntary**, or compulsory, redundancy means the employer selects who goes, using criteria stated in advance - length of service, skills the business will still need, or attendance and performance records.

Voluntary redundancy avoids much of the resentment that compulsory selection creates among the employees who stay, and it removes the argument about whether the selection was fair, because nobody was selected. It also has a well-known cost. The employees most willing to volunteer tend to be those most confident of finding other work - the experienced, the qualified, the mobile - so a business can lose exactly the people it wanted to keep, and then have to recruit replacements for skills it has just paid to remove. Many businesses therefore open voluntary redundancy only to named sections, or reserve the right to refuse an application from an employee whose skills are still needed.

### Fair and unfair dismissal

A dismissal is **fair** where two conditions are both met: the reason is one the law of that country recognises - such as persistent misconduct, incapability to do the job, or a genuine operational reason - and the employer has followed a proper procedure, which normally means investigating, warning the employee, holding a hearing at which they can answer, and allowing an appeal.

A dismissal is **unfair** where the reason is not acceptable in law, or where an acceptable reason was handled without the proper procedure. The second half catches businesses out. An employer with a genuinely good reason to dismiss can still lose a claim by acting on it immediately, with no warning and no hearing, because what was wrong was the process rather than the decision.

### Why the difference costs money

The distinction is not a matter of wording. It decides who pays what.

An employee made redundant is normally entitled to a redundancy payment, because the ending was the business's doing and not theirs. An employee fairly dismissed is normally not, because the ending followed from their own conduct or capability. An employee found to have been unfairly dismissed may be awarded compensation, or reinstatement, by a labour court or tribunal.

So a business that describes a redundancy as a dismissal to avoid the payment is exposed twice over: the payment is still owed if the post has genuinely gone, and the dismissal is likely to be found unfair because there was no conduct or capability reason behind it. The reverse error is quieter and just as expensive - using redundancy as a way of removing a poor performer means paying redundancy money for a post the business then has to refill, which is also evidence that the post was never redundant.

Beyond the direct cost there is the effect on the employees who remain. A workforce that watches colleagues removed without a procedure draws conclusions about its own security, and morale, cooperation and labour turnover all move in response.

### A cannery cutting a shift

A fish cannery in Luderitz loses a contract that took a third of its output and decides to stop the night shift. Forty jobs go with it.

These are redundancies: the night shift no longer exists, and the forty employees did nothing wrong. The cannery opens voluntary redundancy first, and 17 people apply - including three of the five people qualified to operate the retort. Accepting all 17 would leave the day shift unable to run, so the cannery accepts 14 and applies stated criteria to select the remaining 26, keeping the retort operators.

Separately, a supervisor is found to have falsified temperature records. That is a conduct matter and the post itself is not going, so it is a dismissal, not a redundancy - and it is fair only if the cannery investigates, puts the evidence to the supervisor, hears the answer and allows an appeal, even though the misconduct looks obvious.

### A note on jurisdiction

Which reasons count as fair, what procedure has to be followed, how long an employee must have worked before certain protections apply, and how a redundancy payment is calculated, are all set by national employment law and differ between countries. What this topic requires is the general distinction and the reasoning that follows from it. An answer that states a specific entitlement - a number of weeks' pay, a qualifying period - should say which country's law it is drawing on, because the figure does not travel.

---

## Morale, welfare, diversity and equality

### Morale, welfare and work-life balance

**Employee morale** is the general level of confidence, satisfaction and willingness to work that a workforce holds. It is visible in how readily employees attend, cooperate with each other, and put effort into work nobody is directly supervising.

**Employee welfare** refers to what a business provides for employees' physical and mental wellbeing beyond pay: safe working conditions, access to health provision, rest and eating facilities, transport where the site is remote, and support during illness, injury or bereavement.

**Work-life balance** is the relationship between the time and effort an employee gives to work and the time left for the rest of their life. The HRM policies that support it include flexible starting and finishing times, remote or hybrid working where the job allows it, part-time and job-share options, and limits on the overtime employees are expected to accept.

The three are related but not the same. Welfare is what the business provides, work-life balance is one thing welfare provision can protect, and morale is the state of mind that results - influenced by both, and by pay, management and job design as well.

### How HRM practice reaches output through morale

The chain runs through behaviour, and it is worth setting out link by link rather than jumping from "better morale" to "higher profit".

A business introduces a practice that improves conditions - predictable shift patterns instead of rosters issued two days ahead, say. Employees can now plan childcare and travel. Absence caused by clashes between work and home falls, and so does the number of employees who resign because the job does not fit their lives. Fewer absences mean fewer shifts covered by overtime or agency staff; lower turnover means fewer recruitment and induction cycles and fewer part-trained people on the floor. Output per employee rises, and the spending that existed only because people left falls with it.

The size of that gain is not the same everywhere. Where output depends on judgement, care and effort that cannot be observed - nursing, teaching, repair work, selling - a willing employee produces noticeably more than an unwilling one, and morale moves output a long way. Where the pace of work is set by a machine, a more willing employee cannot make the line run faster, and the gain shows up in absence, turnover and safety rather than in output per hour.

### The relationship runs both ways

It is easy to read morale as a cause and turnover as an effect. The link runs in both directions, and that is what makes it worth managing early.

Poor morale raises absence and resignations. The resignations then lower morale further among those who remain: their workload rises while posts are empty, established teams are broken up, and each departure is read by the people left behind as evidence about the employer. A business that lets this run finds itself recruiting into a reputation that makes recruitment harder.

The same loop runs in reverse when it is working. Low turnover keeps teams together, which makes the work easier for everyone in them, which is itself a reason to stay.

### Judging welfare spending

Welfare provision and work-life-balance policies present a business with an awkward comparison. The cost is certain, immediate and easy to count: the subsidy on the staff clinic, the hours lost when the shift finishes earlier, the extra staff needed to cover flexible hours. The benefit is probable, slower and hard to attribute - absence that did not happen, resignations that did not occur, effort that cannot be separated from everything else moving at the same time.

That asymmetry is why welfare spending is often the first thing cut when profits fall, and why the consequences of cutting it appear a year later in the turnover figures rather than immediately.

A business judging such a policy is best served by estimating the thing it can measure. If replacing one employee costs about N$12 000 and the policy is expected to prevent eight resignations a year, the saving to compare against is about N$96 000 - a figure that can be argued with, which is more use than a general claim that happy staff work harder. The judgement then turns on whether the estimate of prevented resignations is credible, which is a question about evidence from the business's own exit interviews.

### Diversity and equality

**Workplace diversity** means a workforce whose members differ from one another - in gender, age, ethnicity, language, background, physical ability and working experience.

**Equality** in the workplace means that employment decisions - recruitment, pay, training, promotion and dismissal - are made on the basis of what the job requires, rather than on personal characteristics that have nothing to do with doing it.

The two are not the same thing and are easily confused. Diversity describes what a workforce looks like. Equality describes how decisions about it are made. A business can employ a varied workforce and still promote only one group within it; a business applying equality consistently may still have a narrow workforce if the local labour market is itself narrow.

### The impact on the business

Three mechanisms carry most of the effect, and they work differently.

**The field for every vacancy.** A business that recruits and promotes on job-related criteria draws on the whole labour market rather than part of it. A larger field raises the chance that the strongest available applicant is the one appointed, and in a country with a small pool of a scarce skill, ruling out half of it on grounds unrelated to the work is expensive in exactly the posts hardest to fill.

**What a varied workforce can see.** People with different experience bring different readings of the same problem, and a workforce that resembles the customer base understands it more readily - which matters for a retailer or a bank serving customers in several languages, and matters less for a business with one industrial customer. The same differences can slow decisions and raise the effort needed to communicate clearly, so the gain depends on how the business manages the differences rather than on their presence alone.

**Legal and reputational exposure.** Treating employees unequally on grounds unrelated to the job exposes a business to claims and to damage to its standing as an employer. That reputation then feeds back into recruitment: a business known for it draws a smaller field and tends to pay more to fill posts.

### Two separate arguments

There is a business case for equality and there is a legal duty, and they are not the same argument. Which characteristics are legally protected, and what an employer is required to do about equality and representation, are set by the law of each country and differ between them. The business case - a wider field, better decisions, lower exposure - can be made anywhere. The legal duty has to be read from the employment legislation in force where the business operates.

An answer resting on the law alone is weak when the law changes or the business moves. An answer resting on the business case alone misses that compliance is not optional.

### Where this connects

Most of the causes behind a labour turnover figure sit in this section. Welfare and work-life balance also connect to motivation later in the course, and equality connects back to the person specification: a specification written strictly against what the job requires is the practical form equality takes at the point of recruitment.

---

## Training and employee development

### Training, and the three forms named in this topic

Training is the provision of instruction and practice that gives employees the knowledge and skills a job requires. The three forms this topic names are induction, on-the-job and off-the-job training.

They are not three alternatives for the same need. Induction is defined by *when* it happens - at the start of employment. On-the-job and off-the-job are defined by *where* it happens - at the work position or away from it. A new employee therefore receives induction and then, separately, on-the-job or off-the-job training in the skills of the post, and an induction programme itself may contain both.

### Induction training

Induction training is the training given to a new employee at the start of employment. It covers the business and its rules, the duties of the post, the people the employee will work with, and health and safety requirements.

Its purpose is to remove the friction of being new. A new employee who does not know where anything is, who to ask, or what is expected, works slowly and cautiously; induction shortens that period and brings the day the employee becomes fully productive forward.

It also affects whether the employee stays. A large share of resignations happen in the first few months, and much of that early leaving follows from a new employee not understanding what was expected of them, or not settling among colleagues - both of which a proper induction addresses directly. The costs are real but small: the time of whoever delivers it, and a delay before the new employee's first productive day.

### On-the-job training

On-the-job training is training carried out at the workplace while the employee does the actual job - usually by watching an experienced colleague, being coached by one, or rotating through the tasks of a section.

It is relatively cheap. No separate venue is hired, no external trainer is paid, and the trainee is producing output, even if slowly, throughout. What is learned is exactly what the business needs, because it is learned on the business's own equipment, with its own customers and its own procedures.

Two costs sit behind that. The quality of the training depends entirely on the practice of whoever does it, so poor habits and shortcuts pass on alongside good technique, and a business that has never written down the right method has no way of noticing. And the experienced employee's own output falls while they teach, which is a real cost even though it never appears as a training invoice.

### Off-the-job training

Off-the-job training is training carried out away from the immediate work position - at a training centre, a college, or with an external provider - so the employee is not producing while learning.

It gives access to expertise, equipment and recognised qualifications the business cannot supply from inside. A welder cannot be taught a pressure-vessel certification by a colleague who does not hold one. It also lets the employee learn without production pressure or interruption, which matters for anything that has to be understood rather than copied.

It costs more per employee - fees, travel, sometimes accommodation - and removes the employee from output for the whole period rather than slowing them down for part of it. And because what is taught is general, it still has to be transferred to the business's own methods afterwards, which is a step businesses often forget to plan for.

### Choosing between on-the-job and off-the-job

The choice follows the skill being taught rather than a general preference.

A task specific to the business's own equipment, customers or procedures is usually learned fastest beside somebody already doing it, and sending the employee away to learn a generic version of it wastes money and adds a transfer step.

A qualification, a legal certification, or a skill nobody inside the business holds has to come from outside, because there is nobody in the building who could teach it.

The decisive question is therefore whether the knowledge already exists inside the business. Where it does, the argument for going outside has to be made on quality or on certification, not on cost - because on cost alone, on-the-job training usually wins.

### Development, and how it differs from training

Employee development is the longer-term broadening of an employee's capability beyond the demands of the current job, so that the employee can take on different or larger roles later.

The difference is the target. Training is aimed at the job the employee is doing now and is judged by whether they do it better. Development is aimed at what the employee could do in two or five years and is judged by whether the business has people ready when a post opens. A business that trains but never develops has a competent workforce and no internal candidates.

### The impact of training on the business

Training raises the skill with which a task is performed, and four consequences follow from that single change.

Output per employee tends to rise, because a skilled operator completes the same task in less time. Errors, waste and rework fall, which shows up in material cost and in the number of jobs returned by customers. Accidents fall, where the training covered the safe method, and with them the cost of lost time and of damage. And morale can rise, because an employee who can do the job well finds it less stressful and reads the spending as evidence that the business intends to keep them - which links training back to labour turnover.

But the sequence matters as much as the list. Training is a cost before it is a benefit. The fees and the lost production come first; the productivity gain arrives afterwards and accumulates slowly. And the gain is captured only for as long as the trained employee stays, which is why a business that trains heavily has a stronger reason than most to work on retention at the same time. The two decisions are genuinely connected: spending on training while ignoring turnover is buying a benefit and then giving it away.

### The argument that training just trains people for competitors

The objection is familiar and partly right: an employee who gains a recognised qualification becomes more valuable in the labour market, and some of them are recruited by competitors who paid nothing towards it.

It is a weak reason to stop training, because the alternative is not free. An untrained workforce carries its own costs in errors, waste, accidents and slow work, and those are paid every day rather than occasionally. The comparison is between two costs, not between a cost and nothing.

The risk is usually managed rather than avoided: competitive pay and a visible route to promotion reduce the reason to leave, and where the law of the country permits it, an agreement that an employee repays part of the cost of a qualification if they leave within a stated period transfers some of the exposure back. The judgement turns on how transferable the skill is. Training in the business's own procedures raises little external value and carries little risk; funding a widely recognised qualification raises a lot of both, and is where the retention work has to be concentrated.

### Intrapreneurship

Intrapreneurship is entrepreneurial behaviour by employees inside an existing business - spotting opportunities, proposing new products, services or methods, and taking responsibility for developing them, using the business's own resources rather than leaving to start a separate venture.

The intrapreneur takes an entrepreneur's initiative without an entrepreneur's personal financial risk: if the idea fails, the business has lost the money. That difference is exactly why intrapreneurship has to be deliberately encouraged, because the employee's own incentive to propose something risky is weaker than an owner's.

### How development encourages it, and what else is needed

Development contributes in two ways. It gives employees knowledge of the business beyond their own task - how the product is sold, what it costs, what customers complain about - and that breadth is what allows an opportunity to be recognised at all, since nobody spots a gap in a process they have never seen. And the development programme itself signals that proposing change is expected rather than resented.

Training alone does not produce intrapreneurship. Three further things are needed. Time, because an employee fully occupied by daily work has none to spare for an idea. Some budget to test a proposal cheaply before committing to it. And a route by which a proposal reaches somebody with the authority to say yes, rather than dying with a supervisor who was not asked to think about it.

Tolerance of failure sits under all three. Most proposals do not succeed, and a business that penalises employees whose ideas failed tends to stop receiving any, which costs it the successful ones too.

### Is intrapreneurship worth encouraging

The case for it is that it produces improvements and new products from people who already understand the business's customers and operations, which is cheaper and less risky than acquiring innovation from outside and faster than developing it through a separate department.

The case against is that time spent on proposals is time not spent on current output, and that most proposals fail, so the spending is certain and the return is not.

The judgement usually turns on the market the business is in. Where products and methods change quickly, a business that generates no ideas internally is relying entirely on copying others, and the cost of the failed proposals is the price of the successful ones. Where the product is stable and competition is on price, the same time is better spent on doing the existing job more cheaply. The condition for it working at all is that the route from proposal to decision genuinely exists - without it, encouragement produces frustration rather than innovation.

### Multi-skilling and flexibility

Multi-skilling is training employees to carry out several different tasks or jobs rather than one, so that any one employee can be used in more than one part of the operation.

The flexibility it buys is specific and worth naming precisely. Employees can be moved to whichever part of the operation demand has risen in, so a queue at one point can be cleared by people from another. Absence and holidays can be covered from inside, without hiring extra staff or paying agency rates. And a single absence is far less likely to stop a process, because more than one person can do the critical step.

### What multi-skilling costs

It costs more in training time, because every additional task has to be taught and practised, and the employee is less productive during each learning period.

It often costs more in pay. An employee who holds several skills has more alternatives in the labour market and can ask for more, and businesses that introduce multi-skilling frequently find they have to recognise it in the pay structure or lose the people they have just trained.

And it can reduce depth. Time spent learning a second task is time not spent becoming expert at the first, so a workforce of people who can each do four jobs adequately may hold nobody who does any of them exceptionally - which matters where the work needs real expertise rather than competence.

### Where the flexibility is worth most

Two Namibian businesses illustrate why the same policy is worth different amounts.

A guesthouse in Otjiwarongo employs nine people. Demand moves between reception, housekeeping and the kitchen depending on the day, and one person being ill removes a ninth of the workforce. If the housekeeper can also serve breakfast and the receptionist can also take restaurant bookings, the guesthouse can absorb an absence and a busy morning without calling anyone in. Multi-skilling here buys capacity the guesthouse would otherwise have to hire for.

A cement plant employing 300 people is different. Each task already has several people trained on it, shifts overlap, and an absence is covered by someone who does that job every day. The training spending would buy cover that already exists, and the plant would be better served by deepening specialist maintenance skills.

Flexibility from multi-skilling is therefore worth most where demand moves between parts of the operation or the team is small enough that it carries no spare capacity, and worth least in a large operation with many employees on each task.

### Where this connects

Training connects backwards to induction and to labour turnover, and forwards to productivity and capacity in the operations topics. Development connects to internal recruitment, because a business with no developed employees has no internal candidates to promote, and to the workforce plan, which is where a skills shortfall is first identified.

---

## Cooperation, trade unions and collective bargaining

### Cooperation between management and the workforce

Cooperation between management and the workforce means the two sides working through consultation, shared information, joint problem-solving and agreed procedures, rather than dealing with each other only when there is a dispute.

In practice it takes concrete forms: works councils or joint committees that meet on a schedule, briefing systems that tell employees how the business is performing, quality or safety groups that include the people doing the work, and written grievance and disciplinary procedures that both sides have agreed to follow.

### What the business gets from it

Three mechanisms carry the benefit to the employer, and they are worth keeping separate.

**Change goes through faster.** Employees who have been consulted about a change have heard the reason for it and have had the chance to alter how it is carried out. They are more likely to accept it, so the change takes effect with less resistance, fewer disputes and less lost output than the same change imposed without warning. A new shift pattern agreed in committee starts on the announced date; one imposed may not.

**Problems surface earlier.** Employees doing a job see faults that management cannot see from a distance - a machine that has started producing at the edge of tolerance, a procedure everyone has quietly stopped following because it does not work. A business with a working channel for raising these corrects them before they reach a customer, and a fault caught inside the factory costs a fraction of the same fault caught by the buyer.

**Disputes cost less.** An agreed procedure settles a disagreement by discussion at a known cost. The alternative - a dispute that reaches a stoppage - costs output, delivery reliability and sometimes the customers who could not wait.

### What the workforce gets from it

The benefit to employees is not simply the mirror image.

Information is the first part. Employees who are told the position the business is in can judge what is realistically available in a pay claim, and can distinguish a genuine difficulty from a negotiating position. A workforce that is told nothing has to assume the worst or demand on principle.

Influence is the second. The people doing a job usually know how it could be organised better, and consultation gives them a way of changing their own conditions - shift lengths, break patterns, the layout of a work area - that pay bargaining alone does not reach.

Protection is the third. An agreed procedure for discipline, grievance and redundancy selection means decisions are taken against stated rules rather than at a manager's discretion, which is worth a great deal to an individual employee who would otherwise have very little standing alone.

Cooperation is therefore of benefit to both, but through partly different routes: the business gains speed, information and lower dispute costs; the workforce gains information, influence and protection.

### What cooperation costs each side

Neither side gets the benefits free.

Management gives up speed and some freedom of decision. Consulting takes weeks, and a change that emerges from consultation is rarely exactly the change management proposed. A business facing an immediate crisis may judge that it cannot afford the time - and may be right, at the cost of the trust it spends doing so.

Employees give up some scope to resist. A workforce inside an agreed procedure has committed to using it, which means not acting while it runs.

The arrangement depends on both sides treating it seriously. Where one side uses consultation as a formality, announcing decisions already taken, the other stops bringing anything real to it, and the committee continues to meet while the actual relationship reverts to dispute. That is the condition under which cooperation delivers nothing, and it is a more common failure than outright refusal to cooperate.

### Trade unions and collective bargaining

A **trade union** is an organisation of employees formed to represent their collective interests to employers, principally over pay, hours, working conditions and job security.

**Collective bargaining** is negotiation between an employer and a trade union over the pay and conditions of a group of employees, in which the agreement reached applies to all the employees in that group rather than being settled person by person.

The word doing the work is *collective*. One negotiation, one agreement, one set of terms for everybody covered - which is the source of both the advantages and the objections that follow.

### The impact on employers

For an employer the effect runs in two directions at once.

On the one hand, bargaining once with a union instead of individually with hundreds of employees lowers the cost of negotiating and produces one settlement that fixes labour costs for an agreed period, which makes budgeting and pricing easier. The union also gives management a single, reliable channel through which to consult the workforce about change, which is the cooperation mechanism above with an organisation behind it.

On the other, collective strength can push pay and conditions above what individual bargaining would have produced, because employees negotiating together can withhold their labour together. The possibility of industrial action is leverage the employer has to take into account, and it can slow changes to working practices that management would otherwise have introduced directly.

Whether the balance is favourable depends on the alternative. An employer who would otherwise face a workforce with no representation may still prefer to face an organised one, because disorganised discontent is harder to negotiate with than organised demands.

### The impact on employees

Collective bargaining supplies individual employees with negotiating power none of them holds alone. An employee asking for more money by themselves can be refused at no cost to the employer; several hundred employees asking together cannot be, because the cost of refusing is the possibility of losing all of them at once. Union membership also supplies representation when a disciplinary or redundancy decision is taken, which changes how carefully such decisions tend to be made.

Pay, conditions and job security therefore tend to be better than the same employees would secure individually - a tendency rather than a rule, since it depends on the union's bargaining position and on what the business can afford.

The costs to employees are real. Membership requires a subscription. The agreement reached binds members who voted against it, so an individual can be worse off under a settlement the majority accepted. And industrial action costs the participants their pay for as long as it lasts, which falls hardest on the employees with the least saved.

### What determines how much leverage a union has

The strength of a union's position is not a constant, and a good answer says what it depends on.

The first factor is how easily the employer could replace the workforce. Where the skills are scarce and training a replacement takes months, a stoppage cannot be worked around, and the union's position is strong. Where the work is quickly learned and unemployment is high, it is weak.

The second is whether output can be produced in advance and stored. A manufacturer that has built up stock can absorb a stoppage for weeks; a bus operator or a hospital cannot store anything, so a stoppage bites immediately.

The third is the state of demand. A union pressing a claim while the business is losing orders is asking for money the employer may genuinely not have, and pressing it to a stoppage can shorten the life of the jobs it is defending.

The judgement to reach is therefore that union involvement raises labour costs and slows change in some circumstances and lowers negotiating costs and stabilises the relationship in others, and which of those dominates is decided by scarcity of skills, the storability of output and the state of demand - not by whether the business approves of unions.

### A note on jurisdiction, and one connection

The right to form a union, to bargain collectively and to take industrial action, and the procedures that must be followed before action is lawful, are set by the law of each country and differ widely. What this topic requires is the mechanism, not the legal position of unions in any one country.

The two halves of this section are also connected in practice. A business that consults its union between pay rounds, and shares information about its position, tends to reach settlements with fewer disputes, because each side has a clearer view of what the other can accept. Cooperation and collective bargaining are not opposites; bargaining is what the relationship falls back on when cooperation has nothing left to settle.

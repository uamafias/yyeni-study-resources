# 4.3 Capacity utilisation and outsourcing

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Measure capacity utilisation and interpret the figure, analyse what happens to a business operating below or at the limit of its capacity, and evaluate the methods available for raising utilisation.
- Define outsourcing, analyse how it changes a business's costs, its capacity and its control over quality, and evaluate whether a particular business should outsource a particular activity.

---

## Capacity utilisation: measuring it, living with it, raising it

### Capacity, and the percentage that measures its use

Maximum capacity is the highest output a business can produce in a given period using the resources it already holds: its premises, its equipment, its staff and the hours it works.

Capacity utilisation is the proportion of that maximum the business is actually producing, written as a percentage.

**Capacity utilisation = (current output / maximum possible output) x 100**

Current output and maximum output have to be measured in the same units of output over the same period - crates a month against crates a month, guest-nights a week against guest-nights a week. A weekly output set against a monthly capacity produces a figure that means nothing.

The answer is a percentage, not a quantity. A business runs at 70% of capacity; it does not run at 70 crates of capacity.

### Reading the formula both ways

The formula rearranges, and both rearrangements are worth holding.

**Current output = capacity utilisation x maximum output.** A plant with capacity for 48 000 crates a month running at 70% is producing 0.70 x 48 000 = 33 600 crates.

**Maximum output = current output / capacity utilisation.** A workshop making 2 700 doors a month at 75% of capacity has a maximum of 2 700 / 0.75 = 3 600 doors a month.

**Spare capacity** - also called excess capacity - is the gap between maximum capacity and current output. It is measured in units of output: 48 000 - 33 600 = 14 400 crates a month. The same gap as a percentage of maximum capacity is 100% minus the capacity utilisation, so 30% here. Both are correct answers, to different questions, and the unit asked for decides which one is wanted.

### Maximum capacity is a judgement, not a reading off a dial

The denominator in the formula looks like a physical fact. It is not.

A bottling plant working one eight-hour shift five days a week has a different maximum from the same plant working two shifts six days a week, and nothing about the machinery has changed. Time set aside for planned maintenance, and time lost changing a line from one product to another, come out of capacity too, so a business that ignores them reports a maximum it cannot reach.

Product mix moves it as well: a bakery baking only white loaves makes more loaves in a day than it can as part of a mixed run of loaves, rolls and cakes, because every changeover costs oven time.

Two consequences follow. Comparing one business's utilisation against another's is sound only where both measure capacity on the same basis. And a business can raise its reported utilisation without producing anything more, simply by restating its capacity on a one-shift basis.

### Erongo Bottling: the calculation, and what the answer is worth

Erongo Bottling fills fruit juice at Walvis Bay. Its line can fill 48 000 crates a month on the two-shift pattern the business works. Last month it filled 33 600 crates. Its fixed costs - the lease on the building, the finance charges on the filling line, the salaries of the permanent staff and the insurance - come to N$1 440 000 a month. Each crate takes N$62 of juice, bottles, caps and packaging.

*Capacity utilisation* = 33 600 / 48 000 = 70%.

*Fixed cost per crate* = total fixed costs / output = 1 440 000 / 33 600 = N$42.86.

*Total cost per crate* = 62 + 42.86 = N$104.86.

Now take the same plant filling 43 200 crates, which is 43 200 / 48 000 = 90% of capacity.

*Fixed cost per crate* = 1 440 000 / 43 200 = N$33.33, and total cost per crate = 62 + 33.33 = N$95.33.

The variable cost has not moved: every crate still takes N$62 of materials. What changed is that the same N$1 440 000 is now carried by 9 600 more crates, so each crate carries N$42.86 - N$33.33 = N$9.53 less of it.

That N$9.53 a crate is the whole reason capacity utilisation is watched. Nothing got cheaper. A cost the business was paying anyway is simply spread more thinly.

### What the percentage does not tell you

A capacity utilisation figure answers one question: how much of what the business could produce it is producing. Three things it does not answer are worth holding onto, because each is a place where a high figure can hide a problem.

*It does not say the output was sold.* A factory running at 95% into a warehouse of unsold goods reports the same percentage as one running at 95% against firm orders.

*It says nothing about quality.* Units later scrapped, reworked or returned still sit in the output figure.

*It does not say whether the capacity is the right size.* A business whose plant can serve half the market it sells to may run at 100% and still lose orders it could have had.

It is also a different measure from labour productivity. Capacity utilisation is output against the maximum output possible, and it is a percentage. Labour productivity is output per worker or per labour hour, and it is a quantity - cabinets per employee per month. A business that puts more people onto an idle line raises its capacity utilisation while output per worker is no higher than it was.

Because one figure carries all of this, it is read against something else: the same business's figure last month or last year, the level it planned for, or a competitor measuring capacity on the same basis.

### Operating below capacity

Erongo at 70% carries N$9.53 a crate more of fixed cost than it would at 90%, and that is the first and most direct effect of under-utilisation. The fixed costs of the period are divided between fewer units, so fixed cost per unit rises, total cost per unit rises with it, and at the same selling price the profit earned on each unit is smaller. Far enough below capacity, the business makes a loss.

The second effect is that resources the business is already paying for stand idle. The unused 30% of the line is not free: the lease, the finance charges on the equipment and the salaries of permanent staff are being paid on capacity producing nothing, so capital is tied up in assets that are not earning.

The third effect is on people. Employees can see idle machines and a quiet floor, and where under-utilisation persists they may expect short-time working or redundancies. Motivation tends to fall, and the staff most able to find work elsewhere - often the most skilled - are the likeliest to go. The effect tends to be stronger where the business has made redundancies recently, because the expectation is already there.

### From a fall in orders to a monthly loss

Erongo's largest wholesale customer moves to a rival, and monthly orders fall from 33 600 crates to 24 000.

Capacity utilisation falls to 24 000 / 48 000 = 50%. The fixed costs of the period do not fall with the order book: the lease runs to its term, the finance on the filling line is contracted, and the permanent staff are employed on monthly salaries. So the same N$1 440 000 is now divided between 24 000 crates: 1 440 000 / 24 000 = N$60.00 a crate, against N$42.86 at 33 600.

Contribution per crate is still N$110 - N$62 = N$48, but there are fewer crates to carry the fixed total. Monthly contribution was 48 x 33 600 = N$1 612 800, which left N$172 800 of profit after fixed costs of N$1 440 000. It is now 48 x 24 000 = N$1 152 000, which leaves a loss of N$288 000.

The chain does not stop at the profit figure. A business making a monthly loss has to find the cash to cover it, and the pressure moves to whatever can be changed inside the month - overtime, temporary staff, maintenance, marketing. Cutting maintenance and marketing is the response most likely to make the following month worse, which is how a fall in utilisation can turn into a downward path rather than one bad month.

### Spare capacity is not only a cost

Treating every unused hour as waste leads to the wrong decision about as often as ignoring it does.

Spare capacity buys a business things a business at its limit cannot have. It can accept an unexpected order - a large tender, a sudden export enquiry - without turning it away or paying a premium to fill it. It can take a machine out of service for maintenance, and take staff off the line for training, without stopping production. And it can grow into rising demand as the demand arrives, instead of ordering equipment and waiting for it to be installed.

That is why a business in a growing market, or one whose demand is hard to predict, may hold capacity it is not using on purpose. The question is not whether spare capacity costs something - it does, and the cost is the extra fixed cost per unit that the worked example puts at N$9.53 a crate between 70% and 90%. The question is whether what it buys is worth more than that in the market the business is actually in. A lodge outside Etosha whose occupancy swings from about 40% in the wet season to close to full in July is sized for July, stands part-empty for months, and could not sensibly be sized for the average.

### Operating at the limit, and past it

At 100% capacity Erongo's fixed cost per crate is at its lowest: 1 440 000 / 48 000 = N$30.00, against N$42.86 at 70%. On cost per unit alone, full capacity is where a business wants to be. Running there has costs that the cost-per-unit figure does not show.

**Maintenance.** A line running every available hour has no window in which to be serviced. Servicing is deferred, and deferred servicing makes an unplanned breakdown more likely - and a breakdown takes out far more output than the service would have done.

**People.** Meeting demand at the limit means overtime, extra shifts, or both. Long hours tend to raise error and accident rates, and sustained pressure raises absence and staff turnover. A business holding output at the limit for a month is in a different position from one holding it there for a year.

**Quality.** Where a line is pushed, checks are the easiest thing to shorten, so defects, reworking and returns tend to rise - and a defect found by a customer costs more than one found on the line.

**Orders turned away.** A business with no slack and a new enquiry has three answers short of investing: turn the work away, quote a longer delivery time, or buy the extra output. Turning it away gives up the contribution those sales would have earned, and the customer may go to a competitor who can deliver.

**The price of the extra output.** Buying it costs more per unit than producing in-house at normal rates. Erongo can fill 52 800 crates - 52 800 / 48 000 = 110% of its stated capacity - by running Sunday shifts, but the labour in those crates is paid at a premium. Labour is N$18 of the N$62 variable cost. A 50% premium adds 18 x 0.5 = N$9 to each of the extra crates, so they cost N$71 rather than N$62 and each earns N$110 - N$71 = N$39 of contribution instead of N$48. Across the 4 800 extra crates that is 9 x 4 800 = N$43 200 less than the same crates would have earned at normal rates.

So cost per unit does not simply fall as utilisation rises. It falls while fixed costs are spread across more units made at normal cost, and it can turn back up once the business is buying output beyond the level its resources are designed for.

### Raising the percentage: the routes available

Capacity utilisation is a ratio. The numerator is what the business produces and sells; the denominator is what it could produce. There are therefore two routes to a higher percentage, and they are not the same decision.

**Route one: produce and sell more.**

*Promotion and price.* Advertising, sales promotion, a lower price, a new distribution channel. Each raises utilisation only where the extra sales actually arrive and are worth more than what it cost to win them.

*New markets and new customer groups.* Selling into neighbouring countries, or to a different kind of buyer - a Windhoek bakery supplying school hostels as well as retail shops.

*Products that sell at a different time of year.* A coastal ice plant supplying fish processors through the fishing season and hotels and caterers outside it fills the same freezers twice over rather than once.

*Work for other businesses.* Producing to another firm's specification, or under its brand, fills idle hours without the business having to build demand of its own. It is usually taken at a thinner margin than own-brand work, and it leaves the business dependent on a customer that may also be a competitor.

**Route two: reduce the capacity.**

Rationalisation - closing a site, selling or mothballing a machine, cutting a shift - raises the percentage by lowering the denominator, and cuts fixed costs while it does so. It is the route that improves the figure when demand is not expected to return. It costs money at the time: redundancy payments fall due, equipment sold at short notice often fetches less than its book value, and a lease may have to be bought out. And it is hard to undo, because a business that cuts capacity and then finds demand recovering has to buy it back, usually at a higher price and after a delay while equipment is ordered and staff recruited and trained.

**Route three: change how much capacity the business owns.**

Renting out a spare unit, or hiring out equipment while it is idle, earns something from capacity the business is not using without giving it up for good. Temporary and seasonal staff and flexible shift patterns work the other way round: they let the capacity actually in use rise and fall with demand, so less of it stands idle in the trough. Temporary staff are usually less experienced than permanent staff, and a business whose peak coincides with other employers' peaks competes with them for the same people.

### What a price cut has to deliver

Erongo's owner considers cutting the price from N$110 to N$99 a crate to fill the line.

Contribution per crate falls from N$110 - N$62 = N$48 to N$99 - N$62 = N$37.

At 33 600 crates the contribution being earned now is 48 x 33 600 = N$1 612 800. To earn that same total at N$37 a crate, Erongo has to sell 1 612 800 / 37 = 43 589 crates. That is a rise of 43 589 - 33 600 = 9 989 crates, which is 9 989 / 33 600 = 30% more volume, and it would put the line at 43 589 / 48 000 = 91% of capacity.

So the price cut takes capacity utilisation from 70% to 91% and leaves profit exactly where it started. Below a 30% rise in volume the business is worse off than before; above it, better off.

The arithmetic does not say whether that volume exists. That depends on how sensitive this market is to price, on what competitors do about their own prices, and on whether the 48 000-crate ceiling allows the volume at all. What the arithmetic does is give the owner the number the marketing judgement has to beat.

### What rationalisation does to the same figure

Take it instead that Erongo's owner concludes the lost volume is not coming back, and closes one of the two filling lines. Capacity falls from 48 000 crates a month to 24 000. Fixed costs fall as well - the finance charge on the closed line ends and eight permanent staff are made redundant - from N$1 440 000 to N$1 040 000 a month.

At output of 24 000 crates, capacity utilisation becomes 24 000 / 24 000 = 100%, and fixed cost per crate becomes 1 040 000 / 24 000 = N$43.33 where it had been 1 440 000 / 24 000 = N$60.00.

Two things there are worth seeing. The percentage reached 100% without one extra crate being sold, which is why a rise in capacity utilisation is not by itself evidence that a business is doing better. And the real gain is the N$60.00 - N$43.33 = N$16.67 a crate taken out of fixed cost, not the percentage. Against it sit the redundancy payments due now, whatever the line fetches when sold, and the position Erongo would be in if the lost customer came back: buying capacity at a market price instead of running a line it already owned.

### Common errors

**Reading a higher percentage as better news in itself.** Capacity utilisation rises when output rises and also when capacity is cut. A business producing into a warehouse it cannot empty raises the figure while tying up cash in inventory and taking the risk that the goods go unsold. The figure improves; the position does not.

**Confusing it with productivity.** Capacity utilisation is a percentage of possible output. Labour productivity is output per worker or per labour hour, and it is a quantity rather than a percentage.

**Giving spare capacity in the wrong units.** Spare capacity is a number of units of output; the same gap as a percentage of maximum capacity is 100% minus the utilisation. Both are right, to different questions.

**Inverting the formula.** Dividing maximum capacity by current output gives a figure above 1 that falls as the business improves, which is the commonest slip on this calculation.

**Treating maximum capacity as a fixed quantity.** It follows the shift pattern assumed, the maintenance time allowed and the product mix being made, so it moves when they move.

### Where this connects

Fixed cost per unit, and the way it falls as output rises, is the mechanism that makes capacity utilisation matter at all; fixed and variable costs and contribution are set out in topic 5.4. The break-even output of a business can be read as a capacity utilisation: Erongo's fixed costs divided by its contribution per crate give 1 440 000 / 48 = 30 000 crates, which is 30 000 / 48 000 = 62.5% of capacity, so any month below that utilisation is a loss-making month. Labour productivity, and the difference between efficiency and effectiveness, are in topic 4.1. Output produced ahead of demand becomes inventory, which is topic 4.2.

---

## Outsourcing

### Outsourcing, and two words often used beside it

Outsourcing is paying another business to carry out an activity that the business could perform itself. The work is bought as a service instead of being produced in-house: a manufacturer buys a component it used to machine, a retailer pays a courier to run its deliveries, a mine buys in catering, cleaning, security or payroll.

**Subcontracting** is normally used of a particular piece of work placed with another firm - a builder subcontracting the electrical work on one site - rather than a whole activity handed over for a period.

**Offshoring** is about location, not about who does the work: an activity is offshored when it is moved to another country, whether it is handed to a supplier there or kept inside the business in an office of its own. So an activity can be outsourced to a firm in the same town and never leave the country, and it can be offshored without being outsourced at all.

### What outsourcing does to the cost base

The first effect is on the shape of the costs, not only on their size.

Performing an activity in-house means holding the capacity to do it - premises, equipment, supervision and permanent staff - most of which is paid for whether the activity runs at full stretch or at half of it. Buying the activity from a supplier replaces that with a price per unit of work used. Fixed costs fall and variable costs rise.

That matters in two ways. A smaller fixed-cost base means the business covers its costs at a lower output, so a fall in demand is less dangerous. And costs then move with activity: a business paying N$255 a frame for 900 frames pays for 900, where a machining cell sized for 1 400 is paid for in full at either volume.

It does not follow that outsourcing lowers total cost. It lowers total cost only where the supplier's price is below the in-house cost that is genuinely avoidable - the spending that would actually stop. Where the building, the equipment lease or the supervisor's salary continue regardless of where the work is done, that cost is unavoidable over the period in question and the supplier's price is added to it rather than replacing it. The test is not what the in-house activity is recorded as costing; it is what would stop being spent.

### Okahandja Furniture: in-house cost against a quotation

Okahandja Furniture makes 1 400 chair frames a month in a machining cell of its own. Materials and the wages of the machinists come to N$180 a frame. The cell itself - the lease on its floor space, the supervisor's salary and the maintenance contract - costs N$126 000 a month, and the whole of that N$126 000 would end if the cell closed, because the floor space is separately leased and can be given up and the supervisor works on nothing else. A supplier quotes N$255 a frame, delivered.

*In-house, at 1 400 frames.* Materials and labour: 180 x 1 400 = N$252 000. Add the cell: 252 000 + 126 000 = N$378 000 a month, which is 378 000 / 1 400 = N$270 a frame.

*Outsourced, at 1 400 frames.* 255 x 1 400 = N$357 000 a month.

Outsourcing saves 378 000 - 357 000 = N$21 000 a month at that volume.

The saving depends on the volume, and the point at which it disappears can be calculated. The difference per frame is 255 - 180 = N$75, so the avoidable N$126 000 is covered by the price difference on 126 000 / 75 = 1 680 frames. Above 1 680 frames a month Okahandja is cheaper making them itself, because the cell cost is then spread across enough frames to bring the in-house cost per frame below N$255; below 1 680 the supplier is cheaper.

That figure is what the decision turns on financially, and it is the monthly volume rather than the quotation that the owner should watch. If orders grew to 2 000 frames, the per-frame difference would be 75 x 2 000 = N$150 000 against N$126 000 of cell cost, and making them in-house would be ahead by N$24 000 a month.

### What outsourcing gives a business

**Capacity without capital.** A business at the limit of its own capacity can place the overflow with a supplier and meet the extra demand, then stop placing it when demand falls back. Buying a second machine commits the business to that machine whether or not the demand lasts. This is the direct link between outsourcing and capacity utilisation: it is one of the ways a business at full capacity supplies more, and one of the ways a business carrying too much capacity stops paying for it. Capacity can also usually be bought faster than it can be built, because a supplier with a free line may be able to start next month where a new line has to be ordered, delivered, installed and staffed.

**Specialist skill and equipment.** A supplier doing one activity for many customers may run it at a scale, and with equipment and experience, that no single customer's volume would justify - a laboratory testing for twenty food producers, a payroll firm that keeps up with every change in the rules. Whether the advantage is real in a particular case is a question about the particular supplier, not something outsourcing delivers by itself.

**Management attention.** Every activity kept in-house is an activity managers have to run. Placing cleaning, payroll or transport outside frees that time for the parts of the business customers actually choose it for.

**A cost base that moves with activity.** Fixed costs converted into a price per unit fall when activity falls, which is worth most to a business whose demand is seasonal or hard to predict.

### What it costs a business

**Control over quality and timing.** The supplier does the work; the business's own customers still hold the business responsible for it. A defect that reaches the customer, or a late delivery, damages the business's reputation rather than the supplier's, and the business hears about the problem later than it would if the work were done down the corridor. A contract can specify standards and penalties, but a penalty recovers money, not a customer.

**Dependence.** Once the in-house capability is closed - the cell sold, the staff gone - bringing the work back is slow and expensive, and the supplier knows it. As renewal approaches the business is negotiating from a weaker position than it held at the start, and the supplier may seek a higher price. The risk is larger where few suppliers can do the work, and smaller where several can.

**Knowledge, and the supplier's other customers.** A supplier that makes a business's component or runs its process learns how that business works, and it may serve the business's competitors as well. Where the activity is one the business competes on - its design, its recipe, the service customers choose it for - outsourcing risks handing over what distinguishes it. The same risk is far smaller for cleaning or payroll.

**Effect on employees.** Outsourcing an activity done in-house normally means the people who did it are made redundant or moved to other work, which brings a cost at the time, possible disruption, and an effect on the confidence of those who continue. What the business is obliged to do for the employees affected - notice, consultation, payments - depends on the law of the country it operates in, and belongs in the cost of the decision before it is taken.

**The cost of running the contract.** Specifying the work, inspecting what arrives, moving goods and settling disputes all take time and money that in-house production did not need in the same form. Where the supplier is in another country, transport time and exposure to exchange-rate movements, where the supplier prices in its own currency, belong in the comparison too.

### Outsourcing a delivery fleet: the chain both ways

A Windhoek wholesaler runs six delivery trucks of its own and is considering handing the work to a courier firm.

*The favourable chain.* The trucks are sold and the drivers' posts go, so the licences, the maintenance contract, the depreciation and that part of the wage bill end - all of it avoidable, because the vehicles can be sold and the posts are dedicated to delivery. Those costs were being incurred whether the trucks ran full or half empty; the courier charges for each delivery made. The wholesaler's fixed costs fall, so its total costs now move with its sales and a quiet month costs it less than it used to. Cash from the sale of the trucks is released. Managers who spent their time on routing, breakdowns and driver rosters spend it on buying and selling instead.

*The unfavourable chain.* This wholesaler's customers judge it by when the goods arrive. A courier serving many clients schedules by its own efficiency, so an urgent order competes with every other client's urgent order, and the wholesaler learns about a failed delivery when the customer telephones. Late or damaged deliveries cost it repeat orders. And at renewal the wholesaler no longer owns trucks or employs drivers, so its bargaining position is weaker and the price may rise.

Which chain dominates depends on how much of the fleet's cost was genuinely avoidable, on how reliable the courier proves to be, and on whether delivery is something this wholesaler's customers choose it for or simply expect.

### What actually decides it

Five questions settle most outsourcing decisions, and the arithmetic is only the first of them.

*Is the activity core or supporting?* An activity customers choose the business for is one to keep and improve. One they never see and never judge is a candidate to buy.

*How much of the in-house cost is genuinely avoidable?* A comparison against the recorded in-house cost overstates the saving wherever premises, equipment or staff would continue regardless.

*Can the required standard be written down and checked?* Work whose quality can be specified and measured - a component made to a drawing, a payroll run - is safer to place outside than work resting on judgement the business would find hard to describe.

*How many suppliers could do it?* A thin market means a dependent relationship and weak bargaining at renewal. Several capable suppliers mean the business can move if it has to.

*How stable is demand?* Volatile or seasonal demand favours buying capacity by the unit. Steady, predictable, high volume favours owning it, because the fixed cost is then spread thinly.

The five may point in different directions, and where they conflict the weight falls on the first. A business can recover from a poor cost decision more easily than from having outsourced the thing it competed on.

### Common errors

**Assuming outsourcing reduces cost.** It reduces cost only where the supplier's price is below the in-house cost that would actually stop being incurred. Setting the quotation against a recorded in-house cost that includes unavoidable overheads flatters the supplier.

**Treating outsourcing and offshoring as the same word.** One is about who performs the activity, the other about where it is performed.

**Forgetting where the responsibility sits.** A customer who receives a late or faulty delivery has dealt with the business, not with its supplier.

**Listing benefits without their conditions.** Lower costs, better quality and more flexibility are things outsourcing can produce, and each of them depends on the supplier chosen, the contract written and the activity placed. A benefit written without its condition is not an answer to a question about a particular business.

### Where this connects

Outsourcing answers a capacity problem in both directions, so it sits directly beside capacity utilisation: a business at its limit can buy the extra output instead of building for it, and a business carrying spare capacity can stop paying for capacity it does not use. Placing work with a supplier rather than holding equipment and inventory connects to inventory management and supply chain management in topic 4.2. The shift from fixed to variable cost, and its effect on the output at which a business covers its costs, is the break-even arithmetic of topic 5.4. And the choice between owning capacity and buying it is a version of the capital-intensive against labour-intensive question in topic 4.1.

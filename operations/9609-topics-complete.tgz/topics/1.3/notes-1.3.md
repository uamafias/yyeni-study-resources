# 1.3 Size of business

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Calculate and compare the measures used to state how big a business is - revenue, number of employees, capital employed, market share and number of outlets - and analyse which of them is appropriate for a particular comparison.
- Explain and analyse the advantages and disadvantages of being a small business, the strengths and weaknesses of family businesses, the importance of small businesses to an economy, and the part they play in the structure of particular industries.
- Explain why and how a business grows internally; identify and distinguish the types of external growth - horizontal, backward and forward vertical, conglomerate, and the difference between a friendly merger and a hostile takeover; analyse the impact of a combination on stakeholders; evaluate why a merger or takeover may or may not achieve its objectives; and explain the importance of joint ventures and strategic alliances.

---

## Measuring the size of a business

### Size is read off indicators, not measured directly

There is no single quantity called the size of a business. Size is inferred from indicators of how much activity the business accounts for, and five are used at this level:

- **Number of employees** - the people it employs.
- **Revenue** - the value of what it sold in a period.
- **Capital employed** - the value of the long-term funds invested in it.
- **Market share** - its sales as a percentage of sales in the market it competes in.
- **Number of outlets or sites** - how many places it trades from.

Each of these counts something different, which is why the choice of indicator is itself a business decision rather than a technicality.

### The three measures that carry a calculation

**Revenue for a period = selling price per unit x quantity sold.** It is measured in currency (N$) and always for a stated period - a month, a quarter, a year. Revenue is not profit: it is what came in from sales before anything is taken off.

**Market share = (the business's sales in a period / total sales in that market in the same period) x 100.** The answer is a percentage. Sales may be counted in currency or in units, but the same basis has to be used above and below the line: units over currency is not a share of anything.

**Capital employed = the owners' capital and reserves plus long-term borrowing.** It is measured in currency and is a value at one date, not over a period. It states what has been put into the business and left in it.

**Number of employees** is a count of people. Where a business uses part-time or seasonal workers the count is often converted to full-time equivalents, so that two people each working half a week count as one.

### Two businesses, four answers

Okavango Bricks is a brickworks near Rundu. It runs two automated kilns, employs 40 people and sells 12 000 000 bricks a year at N$4 each. Capital employed is N$62 000 000. Total sales of building bricks in the region it supplies are N$160 000 000 a year.

Ondangwa Uniforms sews school and workwear to order. It employs 240 machinists, has revenue of N$12 000 000 a year and capital employed of N$5 000 000.

*Okavango's revenue:* 12 000 000 x N$4 = **N$48 000 000** a year.

*Okavango's market share:* N$48 000 000 / N$160 000 000 = 0.30, so its share of that regional market is **30%**.

*By revenue:* N$48 000 000 / N$12 000 000 = **4** - Okavango is four times the size.

*By capital employed:* N$62 000 000 / N$5 000 000 = **12.4** - Okavango is more than twelve times the size.

*By employees:* 240 / 40 = **6** - Ondangwa is six times the size.

Every figure is arithmetically correct and they point in opposite directions.

### What the disagreement between the figures means

The ranking reverses because the two businesses turn different resources into output. Okavango has put money into kilns and conveyors and needs few people to run them; Ondangwa has put very little money into equipment and needs a person at every machine. Revenue and capital employed pick up the first; a headcount picks up the second.

So the right response to the four figures is not to ask which one is true. All four are true. The question is which one answers the question being asked. A ministry deciding which business supports more livelihoods in the north wants the headcount. A supplier deciding which business is worth extending credit to wants revenue and capital employed. A competitor deciding whether it can win work from Okavango wants the market share.

### What each measure cannot tell you

**Revenue over time is measured in money of changing value.** If Okavango's revenue rises from N$48 000 000 to N$54 000 000 while brick prices rise 10%, most of the increase is price, not activity. Comparing revenue across countries adds a currency conversion that moves for reasons unconnected with either business.

**Market share depends on how the market is defined.** Okavango holds 30% of building bricks in its region. Define the market as all walling materials in Namibia, including blocks and prefabricated panels, and the same sales are a much smaller share. A share figure without a stated market definition cannot be compared with anything.

**A headcount ignores what the people do.** Two hundred and forty machinists and forty kiln technicians are not the same input, and the count says nothing about output per worker.

**Capital employed is a value at one date.** A business that has just bought equipment looks larger than one whose equipment is old and written down, even where the two produce the same output.

### Choosing the measure

The appropriate measure follows from the purpose of the comparison and from what is available for both businesses on the same basis.

Comparing competitive position inside one market points to market share, because that is the only one of the five that is defined relative to rivals. Comparing how much labour a business uses points to employees. Comparing the resources committed points to capital employed. Comparing businesses in different industries is where single measures are weakest, because the mix of labour and equipment differs by industry, and a comparison that uses one indicator across two industries is comparing the industries as much as the businesses.

In practice a judgement about size that matters - a bank assessing a customer, a regulator examining a proposed combination - rests on more than one indicator, and the useful skill is saying what each one adds and where it misleads.

### Common errors

**"The business with the higher revenue is the bigger business."** It is bigger on that measure. On employees or capital employed it may be the smaller of the two, as Okavango and Ondangwa show.

**"Revenue is profit."** Revenue is what came in from sales. Nothing has been taken off for what it cost to make those sales.

**"Market share rose, so sales rose."** A share can rise because the business sold more, or because the market as a whole shrank while the business held its sales. The two have very different implications, and the share on its own does not distinguish them.

**"Capital employed is the cash in the bank."** It is the long-term funding invested in the business, most of which is tied up in premises, equipment and stock rather than held as money.

### Where this connects

Market share and market growth are measured again in 3.1.3, where the concern is what a change in share implies for marketing decisions rather than what it says about size. Types of business ownership are in 1.2.2, and ownership type limits how large a business can readily become. The rest of 1.3 uses these measures: a small business is small on them, and growth is an increase in them.

---

## Small businesses

### What counts as small

A small business is one that is small on the indicators in 1.3.1 - few employees, low revenue, little capital employed, a small share of its market. Where a country sets a numerical threshold, it does so for its own purposes, usually to decide who qualifies for support or for simplified reporting, and the figure differs from one country to another. There is no international definition to quote, so an answer should describe the business rather than reach for a number.

### The advantages of being small

The advantages come from closeness and speed.

**The owner deals with customers directly.** A tailor in Katutura knows which of his customers need a fitting on a Saturday and which will pay at month end. That knowledge is held by the person who can act on it, without being written into a report first.

**Decisions do not travel.** Where the owner is also the manager, a change of supplier or price can be decided in an afternoon. A business with regional managers and a head office takes longer, because the decision has to be prepared, approved and communicated.

**The product can be adapted to the individual customer.** Making one item differently costs a small workshop very little; changing a specification on a production line running three shifts costs a great deal.

**Markets too small to interest a large competitor are worth having.** A repair service for a type of pump used on 60 farms is a living for one business and not worth a large firm's attention.

### The disadvantages of being small

The disadvantages come from scarcity of resources.

**Buying in small quantities.** A business ordering 20 bags of cement pays more per bag than one ordering 2 000, so its cost per unit of output starts higher before anything else is considered.

**Finance is dearer and harder to arrange.** A small business typically has a short trading record and few assets to offer as security, so a lender assessing it faces more uncertainty about repayment and may ask for a higher rate, a personal guarantee, or decline the application. Selling shares to outside investors is rarely open to a business of this size because the amounts are too small to interest them.

**The owner carries several roles.** The person who quotes for the work also does the work, chases payment and keeps the records, so any of those may be done late.

**Customer concentration.** Losing one customer that provides 40% of revenue removes 40% of revenue, while rent, insurance and salaried staff continue to be paid in the short run. A business can move from profit to loss without anything having gone wrong in its own operations, and how quickly it recovers depends on whether it can replace that customer or reduce those commitments.

### Whether small size is a problem depends on the market

Small size is not a defect to be corrected. It is a position with a cost and an advantage, and which dominates depends on what the business sells and to whom.

Where customers value a tailored product or personal service and the market is local, the closeness is the product: growing would remove the very thing customers pay for. Where the product is standard and buyers compare mainly on price, the input cost gap against a larger producer is the harder problem, because it shows directly in the price the small business has to charge to cover its costs. The answer to "should this business stay small?" therefore depends on which of those two markets it is in, and on whether the owner's objective is income, independence or growth.

### Family businesses

A family business is owned by members of one family and, in most cases, managed by them, with ownership and senior positions expected to pass to later generations of the same family. Family businesses are not necessarily small - some are very large - but the features below follow from who owns and runs the business, not from its size.

### Strengths and weaknesses of family businesses

**Strengths.** A long time horizon: owners who expect to hand the business to a daughter weigh a decision over decades rather than over the next reporting period, so they may accept a thinner year to keep a supplier relationship or a trained team. Trust between owner-managers who know each other, which lowers the cost of supervising and checking. Commitment, which shows in long hours and in accepting lower pay in a poor year rather than laying people off. Continuity of reputation, because the family name is attached to the product and a lost reputation is personal.

**Weaknesses.** Senior posts may be filled from a small pool of relatives rather than from the best available candidates, so capability is limited by who was born into the family. Disagreements between relatives carry into business decisions and are hard to settle by a formal procedure, because the parties still meet at family occasions afterwards. Succession is often unplanned and disputed. And raising equity from outside means admitting owners from outside the family, which the family may resist because it dilutes their control - so the business may grow more slowly than its opportunities would allow.

### Why succession is the dangerous moment

Consider a hardware business in Gobabis founded by a woman who has run it for thirty years. Much of what makes it work is held in her head: which customers pay late, which supplier will take a rush order on a Friday, what a job should be priced at when the specification is vague.

If she hands over without that knowledge being written down or worked alongside, her son inherits the premises, the stock and the equipment but not the relationships. He quotes too low on a job and too high on the next; a supplier who used to squeeze in an urgent delivery no longer does; a large customer, uncertain about the change, tries a competitor. Revenue falls just as the business is carrying the cost of the handover, which is the point at which it is least able to absorb a fall.

The chain runs from an ownership feature - inherited succession - through a specific mechanism - undocumented relationships - to a measurable consequence - lost orders and lower revenue - and lands on the survival of the business. It is also the chain that says what would prevent it: an overlap in which the successor works alongside the founder, and the knowledge written down as procedures and price lists.

### Judging family ownership

Whether family ownership helps or hinders turns on how far the family separates ownership from management. Where senior appointments are made on capability, whether or not the candidate is a relative, where advice is taken from outside the family, and where succession is planned years in advance, the long horizon and the trust are net gains and are difficult for a professionally managed competitor to copy. Where senior posts are treated as an inheritance, the same closeness becomes a barrier: capable outsiders leave because they cannot rise, and outside finance stays away because it has no say.

### Why small businesses matter to an economy

**Employment.** Taken together, small businesses employ a large part of the workforce in most economies. No one of them is significant; the total is.

**New entry and competition.** Most new businesses start small, so small businesses are the route by which new products, new methods and new competitors enter a market. A market with no new entrants tends to become comfortable for the firms already in it.

**Serving what large businesses will not.** A settlement of 2 000 people supports a shop, a workshop and a taxi operator. It does not support a supermarket chain's distribution economics, so without small businesses those services are not provided at all.

**Supplying and serving large businesses.** Small firms act as subcontractors, agents, dealers and specialist suppliers, so part of what a large business delivers depends on the network of small firms around it.

**Training.** A worker who learns a trade in a small workshop carries that skill into other employment later, so some of the benefit of that training reaches businesses that did not pay for it.

Because of all this, governments commonly support small businesses through simplified registration, advice services, training and finance schemes. What that support consists of, and how generous it is, differs from one country to another.

### Where small businesses form the structure of an industry

Some industries are made up mostly of small businesses, and this is a feature of the industry rather than a stage those businesses have failed to grow out of. It happens where:

- demand is local and cannot be served from one distant site - a hairdresser cannot cut hair from another town;
- customers want the product adapted to them, so long identical runs are impossible;
- the work is carried out on the customer's premises, as with plumbing, repairs and cleaning;
- producing more units does not lower the cost of each unit by much, so a large producer brings no price advantage into the market.

Personal services, the building trades, restaurants and takeaways, small-scale farming and craft manufacture all show the pattern. A large firm entering one of them has to carry head-office costs its small rivals do not have, without a compensating cost advantage.

In other industries - cement, brewing, banking, mobile telephony - a few large producers hold most of the output, and small businesses persist alongside them in specialist roles: supplying components, distributing and servicing the large producer's product, or serving segments the large producer finds too small to be worth its attention. Both structures have small businesses in them; what differs is the role they play.

### The structure can change

Structure follows the technology of reaching customers and of producing. Where a technology lowers the cost of serving customers at a distance, work that had to be done locally can be done from further away, and the number of small businesses in that industry may fall. A shared online ordering platform with next-day delivery lets one warehouse in Windhoek serve towns that previously each needed a stockist, so the stockists lose the part of their trade that was simply availability, and are left with the part that was advice and fitting.

The movement can run the other way. Where a technology lowers the cost of producing in small batches - a digital cutter that needs no tooling for a new design - a small workshop can offer variety a long production run cannot, and the number of viable small producers rises.

### Common errors

**"Small businesses are businesses that failed to grow."** Many are small because their market is local or bespoke, and because the owner's objective is an independent income rather than a larger business.

**"A family business is a small business."** The two are separate ideas. A family business can be large, and most small businesses are not run by a family.

**"Small businesses matter because each one is important."** Individually most are not. The argument is about the total: employment, entry and local provision added across all of them.

**"Being small means low costs."** Total costs are lower. Cost per unit is often higher, because inputs are bought in small quantities and the owner's time is spread thinly.

### Where this connects

Types of business ownership are in 1.2.2, and most small businesses are sole traders, partnerships or private limited companies. Sources of finance and the difficulty small businesses have in obtaining them belong to 5.1. Business objectives, including an owner's objective of independence rather than growth, are in 1.4. The next section takes the businesses that do want to be larger and asks how they get there.

---

## How businesses grow

### Internal (organic) growth

Internal growth, also called organic growth, is growth achieved by expanding the business's own operations rather than by combining with another business. The business ends up larger doing more of what it already does, or doing it in more places.

### Why a business grows

**To raise revenue and profit.** More units sold at a price above the cost of making them raises profit, provided the extra output can be sold without cutting the price to a level that offsets the extra volume.

**To spread head-office and premises costs over more output.** A business paying N$600 000 a year for premises and administration carries N$6 of that cost on each unit at 100 000 units and N$4 at 150 000 units: N$600 000 / 100 000 = N$6 and N$600 000 / 150 000 = N$4. The cost of each unit falls without anything being bought more cheaply.

**To reduce dependence on one product or one market.** A business selling a single product to a single group of customers is exposed to anything that affects them.

**To use idle capacity.** Where equipment and premises are being paid for and stand unused, extra output uses resources that are already committed.

**To meet the owners' objectives.** Growth may be pursued as an objective in itself - a target share of the market, a national presence, the standing that goes with size.

### How a business grows internally

**Raising output from existing premises** - a second shift, another machine, more staff.

**Opening a further outlet or site** - the same format repeated in another town.

**Adding products to the range** - sold to the customers the business already has, which is why it is often the cheapest form of expansion to attempt.

**Entering a new geographic market**, including exporting into neighbouring countries.

**Selling through a new channel** - an online store alongside the shop, or supplying a wholesaler as well as selling direct.

Organic growth is usually financed from retained profit and borrowing, so its pace is limited by the cash the business generates and by what it can afford to service. Because the business is expanding work it already knows how to do, and because ownership does not change hands, control and the existing way of working are usually kept - which is the main reason owners prefer it where they have the time.

### The characteristic risk: growing faster than the cash

A bakery in Oshakati wins a contract to supply 14 schools. It must buy flour, hire two drivers and pay for a second van before the first invoice is settled, and the schools pay 60 days after delivery. Wages are paid weekly and the flour supplier wants payment in 30 days.

The order is profitable on every loaf. The bakery can still run out of money, because cash goes out for weeks before it comes in, and the gap widens with every new school rather than narrowing. If the bank overdraft is already at its limit, the bakery cannot pay wages in week six, and a business that cannot pay its staff stops trading whatever its order book says.

This is why organic growth has to be planned in cash as well as in sales, and why a business growing quickly may arrange finance before the growth rather than after it. The risk is larger where customers are given credit and suppliers expect payment sooner - which is exactly the position of a small business selling to institutions.

### External growth: merger and takeover

External growth is growth achieved by combining with another business rather than by expanding the existing operation.

A **merger** is an agreed combination of two businesses into a single business, usually presented as a combination of equals.

A **takeover**, also called an acquisition, is the purchase by one business of a controlling interest in another - more than half of the voting shares - after which the buyer controls it.

The distinction matters less to the combined operation than to how the combination is arrived at, and the words are often used loosely in practice. What is examinable is the difference between an agreement between two boards and a purchase of control.

### The types of external growth, and what names them

The type is named by the relationship between the two businesses, not by the size of the deal.

**Horizontal** - both are at the same stage of the same industry.

**Vertical backward** - the other business is at an earlier stage of the same chain of production: a supplier.

**Vertical forward** - the other business is at a later stage of the same chain: a distributor or a retailer.

**Conglomerate diversification** - the two sell into unrelated markets.

**Friendly and hostile** describe something else entirely: not the relationship between the businesses but how the combination is pursued. A horizontal combination can be either.

A useful test for the vertical pair: ask where the other business sits relative to this one on the path from raw material to final customer. Nearer the raw material is backward; nearer the customer is forward.

What all forms of external growth share, and what separates them from organic growth, is that size changes in one step. That is the attraction and the risk: the capability, the customers, the staff and the commitments of the other business arrive together, including the ones the buyer did not examine before agreeing the price.

### Horizontal integration

Horizontal integration is a merger with, or takeover of, a business at the same stage of production in the same industry - one bakery combining with another bakery.

**What it is meant to achieve.** The combined business holds a larger share of its market and faces one competitor fewer in it. It may buy inputs in larger quantities on better terms; it needs one head office, one accounts department and one marketing budget rather than two, so those costs are spread over more output and the cost of each unit falls. Two product ranges and two customer lists can be sold to each other's customers.

**The conditions.** Those savings appear only where the duplicated activity can in fact be removed - which means people leaving, contracts ending and systems being merged - and where a competition authority allows the combination to proceed unchanged.

**The difficulties.** The two businesses bring their own working practices, pay structures and computer systems, which have to be reconciled, and staff on the lower of two pay scales will expect the higher. Removing duplicated posts means redundancies, with their cost and their effect on the people who remain. A large combined share of one market may draw the attention of a competition authority, which may attach conditions before permitting it.

### Vertical integration: backward and forward

**Backward vertical integration** is a merger with, or takeover of, a business at an earlier stage of the same chain of production - a bakery combining with the mill that supplies its flour. It secures the supply of an input and the terms on which it is transferred, keeps inside the business the margin the mill used to earn on those sales, gives control of input quality, and can limit rivals' access to that supplier. How much of the gain is realised depends on the mill's output matching roughly what the bakery uses: where the mill can produce far more, the bakery has bought capacity it must sell to others or leave idle.

Its risks are that milling is a different business from baking and needs skills the buyer may not have, and that an in-house supplier no longer has to win the order in competition, so its costs may drift above what an outside mill would charge unless it is held against an outside price.

**Forward vertical integration** is a merger with, or takeover of, a business at a later stage of the same chain - the same bakery combining with the chain of cafes that sells its bread. It secures a route to the customer, keeps inside the business the margin earned at the later stage, gives control over how the product is presented, priced and served, and gives direct information about what customers are actually buying. Whether the outlay is justified depends on how much of the bakery's output passes through those cafes: buying the outlet that takes a twentieth of production secures very little.

Its risks are that running cafes is a different trade from baking, and that the independent cafes that also stock the bread are now buying from a business that competes with them, so some of them may reduce their orders.

### Conglomerate diversification

Conglomerate diversification is a merger with, or takeover of, a business in an unrelated market, so that the combined business sells into markets whose demand does not rise and fall together.

**The purpose is to spread risk.** Where the two markets respond to different conditions, a fall in one may be offset by steadier trade in the other, so combined revenue varies less than the revenue of either part alone. Cash generated in a mature market also gains somewhere to be invested.

**The offset is only as good as the difference between the markets.** A safari lodge and a curio manufacturer both depend on the same tourist season and the same visitor numbers; they fall together, and combining them spreads very little. A lodge and a bakery selling to households are far less connected.

**The weakness.** The buyer brings no operating knowledge to the acquired market, so any improvement has to come from the existing managers staying and performing. Management attention is divided across unrelated businesses, each needing a different kind of judgement. And a shareholder who wanted exposure to two markets could have bought shares in both without the business paying a premium to arrange it.

### Friendly merger and hostile takeover

A **friendly merger** is a combination that the boards of both businesses agree and recommend to their shareholders. A **hostile takeover** is a purchase pursued against the recommendation of the target's board, with the offer put directly to the target's shareholders, who decide whether to sell.

The consequences follow from that difference.

**Information.** In an agreed combination the buyer is normally given access to the target's records before the price is settled, so it can check what it is paying for. In a contested bid the buyer works largely from published information, so the risk of paying for something it has not examined is higher.

**People.** In an agreed combination the managers who know the business have a reason to stay. Where a bid succeeds against the board's advice, the managers and skilled staff the buyer needs may leave - and in a business whose value is mostly in its people, that can remove much of what was bought.

**Price.** A contested bid is usually dearer. The target's board is arguing publicly that the business is worth more than the offer, so a higher price is generally needed to persuade enough shareholders to sell, and the cost of advisers and of running a contested bid is higher too.

### The impact of a merger or takeover on stakeholders

A combination affects the stakeholders of both businesses, and the effect differs in direction as well as in size between groups. A single verdict on the effect on stakeholders hides that disagreement, which is why an answer has to take the groups one at a time.

**Employees** are affected first through duplication. Where both businesses have their own accounts, purchasing and head-office functions, the combined business may need one of each, so some posts are at risk of redundancy. Others gain: a larger business may offer promotion routes and training a small one could not. Which of the two a particular employee meets depends on whether that role exists twice.

**Customers** may gain a wider range and the service of a better-resourced business. They may lose choice where a competitor has been removed and the price is less constrained by rivalry.

**Suppliers** may gain a larger order from the combined business, or lose the contract where the buyer standardises on the other side's supplier. The combined business also buys in larger quantities, which strengthens its position when terms are negotiated, so a supplier that keeps the work may keep it on thinner margins.

**Shareholders** are on two sides of the same transaction. The target's shareholders are usually offered more than the market price their shares stood at before the bid, so in the short term they commonly gain. The buyer's shareholders carry the risk: they have paid that premium, and they are better off only if the combined business earns enough more than the two businesses would have earned apart to cover both the premium and the cost of combining them.

**The local community** around a site is affected through employment and through what the business buys locally. Closing a duplicated site removes both from that town and adds them where production is concentrated instead. A town that depends on one large employer carries more of that risk than a city with many.

**Managers** of the acquired business may lose authority, a title, or the job itself, which is part of why a board may resist a bid that its shareholders would accept.

### Why a merger or takeover may or may not achieve its objectives

A combination is judged against the objective it was undertaken to achieve - a larger share of the market, a secure input, entry to a new market, a lower cost per unit - and it meets that objective where the gain it produces exceeds the price paid plus the cost of combining the two businesses. Four things decide whether it does.

**The price.** The offer usually includes a premium above the market value of the target's shares, and the extra profit needed to justify that premium has to be earned every year afterwards. A combination sound at one price can leave the buyer worse off at another, which is why the same transaction cannot be judged without knowing what was paid.

**Whether the savings are real.** Expected savings depend on two things actually happening: the duplicated activity has to be removable, and two sets of systems, procedures and working practices have to be made to work together. Where the systems are incompatible or the staff of one side resist the other's methods, the saving is delayed or never arrives, while the cost of attempting it is incurred at once.

**Management attention and the people who leave.** A combination absorbs senior time. While managers are settling structures and reporting lines they are not attending to customers and competitors, so a rival may take business during the disruption. Key staff and long-standing customers who dislike the change may leave, and each departure removes part of what was bought.

**The regulator.** A competition authority may examine a combination that would leave the combined business with a large share of a market. It may permit it, permit it subject to conditions such as selling part of the business, or prohibit it. That possibility belongs in the assessment before a bid, because the cost of preparing a bid is incurred whether or not the combination is permitted.

**The judgement.** Success turns on whether the specific gain was checked before the price was agreed rather than assumed, whether the two businesses can be made to work as one, and whether combining was a method capable of delivering that objective at all. Spreading risk can be met by a conglomerate combination. Lowering the cost of each unit is met where duplication genuinely exists and can be removed, and not otherwise - which is why an objective stated vaguely as 'growth' is the hardest of all to assess afterwards.

### Joint ventures and strategic alliances

A **joint venture** is a separate business created and jointly owned by two or more existing businesses for a stated purpose, with the partners sharing the capital they put in, the control of it, and the profit or loss it makes. A mining company and an engineering firm may form a jointly owned company to build and run a processing plant.

A **strategic alliance** is an agreement between businesses to co-operate on a defined activity - shared research, shared distribution, joint marketing - without creating a separate business and without either side buying a stake in the other. Two airlines selling seats on each other's flights are in an alliance, not a joint venture.

**Why they are used as methods of external growth.** They give access to something the business does not have - a partner's distribution network, local market knowledge, a technology, a licence - without the outlay and the commitment of buying a whole business. They share the cost and the risk of a project too large or too uncertain for one business to carry alone. And in some countries a local partner is a condition of operating there, so a joint venture is the route in rather than a preference.

**What they cost.** Control is shared: decisions need the agreement of partners whose objectives may differ, which slows action and can deadlock it. Profit is shared in the agreed proportions. And the knowledge a partner acquires from working alongside the business may later be used in competition with it.

**How they compare with a takeover.** They are lighter commitments: the outlay is smaller, the arrangement covers a defined activity rather than a whole business, and it can be ended or allowed to lapse if it does not work, whereas a business that has been bought has to be sold again to reverse the decision. What is given up is the control and the whole of the profit that ownership would have brought.

### Common errors

**"A merger is a takeover where both sides are happy."** Close, but the examinable difference is what happens to ownership: a merger combines two businesses into one, while a takeover is a purchase of a controlling interest by one of them.

**"Vertical integration means getting bigger in the same market."** That is horizontal. Vertical moves along the chain of production, to a supplier or to a customer.

**"A takeover raises profit because the two businesses' profits are added together."** The buyer paid for that profit, usually at a premium. The test is what the combination earns above what the two would have earned separately, set against the price and the cost of combining.

**"Conglomerate diversification removes risk."** It spreads risk across markets, and only to the extent that the markets move differently. Two businesses depending on the same season or the same customers fall together.

**"Organic growth is safe."** Its characteristic danger is cash: a profitable business can fail while growing because money leaves before it arrives.

### Where this connects

Joint ventures appear again in 1.2.2 as a type of business ownership; here the concern is what they achieve as a method of growth. Business objectives, against which any growth decision is judged, are in 1.4. Stakeholders and their competing interests are in 1.5. The cash problem that limits organic growth is worked through in 5.2 and 5.3, and market share as a measure returns in 3.1.3.

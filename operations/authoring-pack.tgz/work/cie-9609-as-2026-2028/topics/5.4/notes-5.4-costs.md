# 5.4 Costs

*cie-9609-as-2026-2028. Offline study notes, rendered from the approved content units on 2026-09-12. Everything here is also what the flashcards are built from.*

**What this topic asks of you**

- Explain why a business needs accurate cost information, and define and distinguish fixed, variable, direct and indirect costs.
- Explain the difference between full and contribution costing, the uses and limitations of each, the difference between contribution and profit, and when contribution costing would and would not be used.
- Calculate and use total, average and marginal cost; explain how costs are used to set prices, to monitor performance and to calculate profit; and analyse a special order using contribution.
- Explain the meaning and importance of break-even analysis; calculate and interpret break-even output, contribution, margin of safety and profit, in numbers and on a chart; and evaluate the uses and limitations of the technique.

---

## What costs are, and why the split matters

### Cost information

Cost information is the record of what it costs a business to make its products or run its operations, broken down so that it can be attached to particular products, departments or activities.

The phrase "broken down" is doing the work. A business already knows what it spent in total - the bank statement says so. Cost information is that total taken apart, so the business can say what *this* product costs rather than what everything costs.

### Why accuracy matters

Four decisions run on cost figures. What to charge, so the price covers what the product costs. What to keep making, and what to stop. Where spending is drifting away from plan. And whether the business is doing better or worse than it was.

If a figure is wrong, each of those decisions can be misled. Not all of them automatically: a costing error only changes a decision if it is large enough to matter to that decision. And not all in the same direction either, because the direction follows the distortion.

Under-costing. A product carrying too little cost looks more profitable than it is. The business prices it low, pushes it hard, and loses money faster the more it sells.

Over-costing. A product carrying too much looks like a failure, so the business drops it - and then finds the overheads it was helping to cover have not gone anywhere, and now sit on the products that remain. Whether dropping it was a mistake turns on how much of that cost would genuinely have disappeared with it: an overhead that is unavoidable over the period in question stays behind, while a lease that could be given up or a supervisor employed only on that product goes with it.

The two pathways are connected, and that is the part worth remembering. A shared total divided between products is a fixed sum. A basis that charges one product too little charges another too much, so the same allocation can make one product look better than it is and another look worse, at the same time. The error is not in the arithmetic. It is in how the shared costs were divided up in the first place.

### Two different questions about every cost

The syllabus names four types of cost, and it is easy to treat them as a list of four things. They are not. They are two questions, and every cost gets an answer to both.

**Question one: what happens to this cost when output changes?**

A **fixed cost** does not change as output changes over a given period. Rent, insurance, business rates, the salaries of permanent staff. The business pays them whether it produces nothing or works flat out.

A **variable cost** changes directly with output. Raw materials, packaging, wages paid per item made. Produce nothing and they are nothing; double output and they roughly double.

**Question two: can this cost be traced to one product?**

A **direct cost** can be attributed in full to one product, department or activity. The leather in a shoe, and the wages of the worker who makes only that shoe.

An **indirect cost**, also called an overhead, cannot be attributed to one product without dividing it up. Factory rent, the finance department's salaries, the electricity for the whole site.

Because they are separate questions, a cost can be direct and fixed at the same time. The salary of a supervisor who works on one product line only is fixed - it does not move with output - and direct, because it belongs to that line and no other. Candidates who learn the four as a single list get this wrong.

### Fixed is only fixed within limits

Fixed costs are fixed within a range of output and for a period of time, and both parts matter.

A bakery renting one unit pays the same rent whether it bakes 200 loaves a day or 2,000. At 3,000 it needs a second unit, and the rent steps up to a new level - at which it is fixed again. Costs that behave this way are sometimes called stepped fixed costs, and they are the reason a business planning a large increase in output cannot assume its fixed costs will stay where they are.

The arithmetic that follows from this is worth holding onto. **Total cost = fixed costs + (variable cost per unit x output).** As output rises, the fixed total is spread over more units, so **fixed cost per unit falls** while **variable cost per unit stays the same**. That is the whole reason producing more usually lowers the average cost of each unit - not that anything got cheaper, but that the same rent is being carried by more loaves.

### Why sharing out an overhead is a judgement, not a measurement

A factory makes two products and pays N$120 000 a year in rent under a lease with six years still to run. How much of that rent belongs to each product?

There is no measurement that answers this. The business has to choose a basis: floor space used, machine hours, labour hours, or simply units produced. Suppose product A occupies 70% of the floor but takes only 30% of the machine hours. On a floor-space basis it carries N$84 000 of rent; on a machine-hours basis it carries N$36 000. Nothing about the factory has changed. The same real spending has produced two different costs for the same product.

That is why the resulting figure is a judgement rather than a measurement, and it matters because of what happens next. If product A is judged on the floor-space figure it may look unprofitable and be dropped. The rent does not fall when it goes - the lease is unavoidable for six years and no part of it can be given up by making less - so it simply lands on product B, which may now look unprofitable in its turn.

The chain is worth being able to write out: a basis is chosen, the basis sets the overhead each product carries, that figure drives a decision about the product, and the decision does not change the overhead. Two things decide whether the chain actually ends in a worse business. First, how much of the cost really is unavoidable: if dropping A released floor space the business could sublet, part of the rent does disappear with it. Second, what the freed capacity would earn: if the space and machine time A used could be turned over to a product earning more than A contributed, dropping A is the right decision even though the rent stays. And the whole chain matters less the smaller the shared costs are relative to the direct ones - in a business where overheads are small, the choice of basis barely moves the answer.

### Reducing a variable cost

A furniture maker in Okahandja pays N$310 in timber and fittings for each chair it makes. That is a variable cost: no chair, no timber.

Four things could bring it down. Buying timber by the container rather than the pallet, if the supplier prices by volume. Cutting waste - if 12% of each board is currently offcut, better cutting patterns recover part of that. Finding another supplier at the same grade. Or redesigning the chair so it uses less timber without losing strength.

Each of those lowers the cost of every chair the business will ever make, which is what makes variable-cost savings worth chasing. What none of them touches is the rent on the workshop.

### Common errors

**"Wages are a variable cost."** Some are and some are not. A worker paid per item made is a variable cost; a salaried supervisor is a fixed cost. The question is always whether the amount moves with output.

**"Direct means variable."** They often coincide, which is why the error is easy, but they answer different questions. A supervisor dedicated to one production line is direct and fixed.

**"Fixed costs never change."** They do not change *with output*, within a range. Rent can be increased by the landlord, and it steps up when the business takes more space. Fixed is not the same as permanent.

### Where this connects

The costs defined here are used everywhere in 5.4: in full and contribution costing (5.4.2), in the cost figures used for decisions and pricing (5.4.3), and in break-even analysis (5.4.4), which cannot be done at all until fixed and variable costs have been separated. Cash and profit are distinguished in 5.1.1, and pricing as a marketing decision is in 3.3.2.

---

## Full costing and contribution costing

### The two methods

**Full costing** assigns every cost to the products: the direct costs of each product plus a share of the costs the business incurs as a whole, fixed overheads included.

**Contribution costing** assigns only the variable costs to products, and treats fixed costs as a cost of the period, to be covered out of the combined contribution of everything the business sells.

### One boundary, and it is fixed against variable

Both methods charge a product with the materials and the labour that went into making it. They agree about everything that varies with output.

Where they part company is the **fixed** costs - the rent, the insurance, the salaries that are the same whether the business makes one unit or a thousand. Full costing shares them among the products. Contribution costing refuses to, and holds them back as a cost of the period.

Be careful here, because it is easy to say 'fixed and indirect' as though those were one thing. Section 5.4.1 showed they are two separate questions, and the two boundaries do not line up:

- A **supervisor employed on one line only** is direct *and* fixed. Full costing puts her salary inside that line's cost. Contribution costing leaves it out, because it is fixed - even though it belongs to that line and nothing has to be divided to know so.
- **Power used by several products** is indirect *and* variable. Both methods charge it to the products, because it varies with output - but it still has to be divided between them first, so contribution costing has not escaped apportionment either.

The line between the methods is fixed against variable. The line between direct and indirect is a different line, and it decides how much dividing up has to be done, not which method includes what.

### Contribution

**Contribution per unit = selling price per unit - variable cost per unit.**

**Total contribution = contribution per unit x number of units sold.**

A chair sells for N$800 and costs N$310 in timber and fittings. Its contribution is N$490. That N$490 does not go into anyone's pocket. It goes towards the rent, the insurance, the salaries - the fixed costs that had to be paid before a single chair was made. Once those are fully covered, the next chair's N$490 is profit.

This is the costing sense of the word, and it is the only sense that has a formula. When you meet "contribution" in topic 2.3 or 4.1 - the contribution of managers to performance, the contribution of operations to added value - it is the ordinary English word meaning the part something plays. No calculation is involved there.

### Contribution is not profit

**Profit = total contribution - fixed costs.**

Contribution is what is left from a sale after the variable costs of making it. Profit is what is left after the fixed costs of the period as well. A business can have a very large total contribution and still make a loss, if its fixed costs are larger still.

Take the chair maker. Each chair contributes N$490. Fixed costs are N$147 000 a year.

| Chairs sold | Total contribution | Fixed costs | Profit |
|---:|---:|---:|---:|
| 200 | N$98 000 | N$147 000 | (N$49 000) |
| 300 | N$147 000 | N$147 000 | nil |
| 400 | N$196 000 | N$147 000 | N$49 000 |

Every row has positive contribution. Only the last has profit. If a question asks for contribution and you give profit, or the reverse, the whole answer fails however good the arithmetic.

### What each method is good for, and where it fails

**Full costing** produces a cost per unit that covers everything the business spends, which makes it a sound basis for a long-run price - a price above full cost covers the whole business, not just the product. Where a business makes one product it is also the simpler method, because there is nothing to share out.

Its limitation is the share-out itself. The basis is chosen rather than measured, a different basis changes each product's cost, and a product can appear to make a loss purely because of the size of the overhead share it was given. Where those overheads are unavoidable - a lease with years to run, staff the business keeps - a business that stops making the product still has them, now spread across fewer products. Where part of the overhead would genuinely go with the product, that part belongs in the decision.

**Contribution costing** avoids most of that problem by keeping fixed costs out of the product figure altogether. It gives a clean figure for what each product adds, and it is the right tool for a decision in which the fixed costs will not change. It does not escape apportionment entirely: a variable cost shared between products still has to be divided before it can be charged to one.

It has three limitations of its own. It leaves fixed costs out of the product figure, so a business pricing on contribution alone can cover its variable costs on every sale and still not cover its fixed costs overall. It assumes variable cost per unit is the same at every level of output, which bulk buying and overtime both disturb. And repeatedly taking work priced above variable cost but below full cost can make it harder to charge the full price elsewhere, once customers learn a lower price exists.

### Why a loss-making product may be worth keeping

A business makes three products. Under full costing, product C shows a loss of N$20 000 after taking its share of overheads. The obvious move is to stop making it.

Work through what actually happens. Product C sells for more than its variable cost, so it earns a positive contribution - say N$60 000 a year. Its share of the overheads was N$80 000, which is where the reported loss comes from. Stop making it, and the N$60 000 of contribution disappears. The N$80 000 of overheads does not: the rent and the salaries are unchanged, and are now carried by A and B alone. The business is N$60 000 worse off than before, and A and B each look less profitable than they did.

Two conditions are what make this an argument rather than a rule, and an answer that leaves either out is incomplete.

The first is avoidability. The reasoning holds while the fixed costs really would be incurred anyway. If dropping C would let the business give up a warehouse, or lay off a supervisor who works only on C, then part of that N$80 000 does go, and the calculation has to be done again with only the costs that would genuinely disappear. If N$50 000 of it is avoidable, the business loses N$60 000 of contribution and saves N$50 000 of cost, so it is only N$10 000 worse off - and if more than N$60 000 is avoidable, dropping C improves profit.

The second is what the capacity would otherwise do. Positive contribution shows what is lost by dropping C and putting nothing in its place. It does not show that keeping C is the best use of the factory. If the line, the floor space and the labour C occupies could make a product contributing N$90 000, the comparison is not N$60 000 against nothing but N$60 000 against N$90 000, and C should go. Keeping a product because it contributes something is only right when there is nothing better to do with what it uses.

### When contribution costing fits the decision, and when it does not

Contribution costing suits a **short-run decision in which the fixed costs will not change whatever is decided**: whether to accept a one-off order using spare capacity, which of two products to push with the same machine hours, or whether to stop making something.

It does not suit a decision that **changes the fixed costs themselves** - opening a second site, buying a machine that adds depreciation and insurance - because the figure it produces leaves out precisely the thing that is changing. And it does not suit **setting a long-run price**, which has to cover everything the business spends or the business does not survive.

The test to apply in an exam is a single question: in this decision, do the fixed costs move? If they do not, contribution is the right lens. If they do, they have to be in the calculation.

### Common errors

**"Contribution is profit."** It is profit only after fixed costs are covered. Read which the question asked for.

**"Full costing is more accurate."** It is more complete, which is not the same thing. The overhead share inside it is a choice, so a full cost carries a judgement that a variable cost does not.

**"Any order above variable cost should be accepted."** It adds contribution, which is a point in its favour, not a decision. Whether there is spare capacity, and what it does to the prices other customers pay, both matter.

### Where this connects

The cost types this section sorts are defined in 5.4.1. Contribution is used again in special-order decisions (5.4.3) and is the engine of break-even analysis (5.4.4), where break-even output is fixed costs divided by contribution per unit. Pricing as a marketing decision is in 3.3.2.

---

## Using cost information to decide

### Three cost figures, three different questions

**Total cost** is everything it costs to produce a given level of output: fixed costs plus total variable costs.

**Average cost**, or cost per unit, **= total cost / output**.

**Marginal cost** is the cost of producing one more unit. At AS level, where variable cost per unit is treated as constant, the marginal cost of one more unit is simply its variable cost.

They are not three ways of saying the same thing. Average cost answers *what has each unit cost us on the whole?* Marginal cost answers *does making one more add more than it costs?* Those questions can have opposite answers, and that is the point of having both.

### The same business, both figures

A print shop has fixed costs of N$40 000 a month. Each poster costs N$15 in paper and ink.

At 4 000 posters a month: total cost = N$40 000 + (4 000 x N$15) = N$100 000. Average cost = N$100 000 / 4 000 = **N$25 per poster**. Marginal cost of the 4 001st poster = **N$15**.

A customer offers N$20 each for 500 posters. Below average cost, so it looks like a loss. But the shop has spare capacity, the fixed costs are being paid anyway, and each of those posters brings in N$20 against N$15 of extra cost. The order adds 500 x N$5 = **N$2 500** to profit.

Read the two figures again. Average cost said no; marginal cost said yes. Marginal cost is the right one here because nothing in the fixed N$40 000 changes as a result of taking the order. Change that - suppose the run needs a weekend shift the shop must pay for - and the answer moves.

### Using cost to set a price

**Cost-plus pricing** takes the cost per unit and adds a mark-up: **price = cost per unit + (cost per unit x mark-up percentage)**. A product costing N$25 with a 40% mark-up is priced at N$25 + N$10 = N$35.

Which cost goes into that formula depends on the question being asked, and there are two different questions.

**For a one-off order**, the test is whether the price beats every cost the order itself causes - its variable cost, plus any extra fixed cost it creates, such as a weekend shift - and whether the capacity it uses would otherwise have earned more. Where it does, the order leaves the business better off than refusing it: it improves profit if the business is profitable, and reduces the loss if it is not. A business already losing money is not a reason to turn down work that covers its own costs and contributes something.

**For the long run**, the test is different. Total contribution across everything the business sells has to cover the fixed costs, at a volume it can realistically achieve. That is why a long-run price is set above full cost per unit - but notice that full cost per unit was itself calculated at an assumed level of output. Sell fewer units than assumed and the fixed cost per unit rises, so a price that looked safe no longer covers everything.

The limitation of pricing from cost at all is that the calculation never looks outside the business. It does not ask what customers are willing to pay, or what a competitor charges.

### Using cost to monitor performance, and to work out profit

**Revenue = selling price per unit x units sold. Profit = revenue - total costs.**

For monitoring, the figure on its own says very little. Cost per unit of N$25 is neither good nor bad. It becomes useful the moment it is compared: against the plan, against last quarter, against another branch or product line. A rise from N$22 to N$25 is a question worth asking, and the comparison is what raises it.

What cost information cannot do is answer the question it raises. Cost per unit rises when spending rises - but it also rises when output falls and the same fixed costs are spread over fewer units, without anybody having spent a cent more. A business that reads the first explanation into a figure caused by the second will cut the wrong thing.

### A special order

A special order is a one-off request to supply at a price below the normal one.

A bottler in Walvis Bay sells crates at N$180. Variable cost is N$110 a crate; fixed costs are N$420 000 a month and it is currently selling 8 000 crates against a capacity of 10 000. A hotel group offers N$135 a crate for 1 500 crates, one delivery only.

Contribution per crate on the offer = N$135 - N$110 = **N$25**. Total contribution = 1 500 x N$25 = **N$37 500**.

Before treating that as the gain, check what else the order causes. If it needs a setup, an extra shift or a delivery the bottler does not normally make, those costs are caused by this order and come off the N$37 500 - they are incremental, even though they are fixed. Here there are none: the run fits the existing shift and the hotel group collects. And the 1 500 crates fit inside the 2 000 of idle monthly capacity, so no full-price sale is displaced. On those conditions the order adds N$37 500 to profit.

The numbers are not the whole decision. Three things sit outside them. Existing customers paying N$180 may learn what the hotel group paid. The hotel group will expect N$135 next time. And if demand rises above 8 500 crates in the month, the capacity used by the order is capacity that would have earned N$70 a crate rather than N$25.

So the answer is a conditional one: worth taking while the capacity is genuinely spare, the order causes no cost beyond the N$110 a crate, and the price can be kept separate from the standard price list.

### Common errors

**"Never sell below average cost."** With spare capacity and unchanged fixed costs, a price above the costs the order actually causes leaves the business better off than refusing it - and that holds whether the business is currently profitable or losing money. The rule is a good habit and a bad absolute.

**"Marginal cost is average cost."** They are equal only if there are no fixed costs, which is almost never.

**"A rising cost per unit means costs are out of control."** It can mean output fell. Check which before recommending anything.

### Where this connects

Cost types are defined in 5.4.1 and contribution in 5.4.2. Break-even analysis in 5.4.4 uses the same contribution figure to find the output at which profit is zero. Pricing strategies as a marketing decision are in 3.3.2, and capacity utilisation is in 4.3.

---

## Break-even analysis

### Break-even analysis and the break-even point

**Break-even analysis** compares a business's revenue with its costs at different levels of output, in order to find the level at which the two are equal.

**The break-even level of output** is the number of units at which total revenue exactly equals total costs, so the business makes neither a profit nor a loss.

### Why a business bothers

A plan says the new bakery will sell bread and make money. Break-even analysis turns that into a number: 4 200 loaves a month, below which the bakery loses money and above which it makes some.

That single number does three jobs. It sets a target everyone in the business can understand. It shows how much room there is - if the bakery expects 6 000 loaves, sales can fall by 1 800 before there is a problem. And it lets the business test a change before making it: what happens to that 4 200 if flour goes up 10%, or if the price rises by N$2?

It is worth being clear about what kind of number it is. It is not a forecast of what will happen. It is a statement of what would have to happen, given the figures put in.

### The formulas, and what every term means

Everything in this section runs off contribution, so start there.

**Contribution per unit = selling price per unit - variable cost per unit** (currency per unit)

**Break-even level of output = fixed costs / contribution per unit** (units)

**Margin of safety = current or budgeted output - break-even output** (units, or as a % of current output)

**Profit = (contribution per unit x units sold) - fixed costs** (currency)

The terms:

- *Selling price per unit* - what one unit sells for, before any discount.
- *Variable cost per unit* - what one unit costs in materials, packaging and any labour paid per item.
- *Fixed costs* - the costs of the period that do not move with output, taken as a total, not per unit.
- *Current or budgeted output* - what the business is selling now, or plans to.

Two things to watch. Fixed costs go in as a **total**, not per unit - dividing them first is the commonest way to get the answer wrong. And the fixed-cost total and the output figure must cover **the same period**: monthly fixed costs give a monthly break-even output.

Break-even output rarely comes out whole. A business cannot sell 4 199.6 loaves, so round **up** to the next whole unit - at 4 199 it has not broken even.

### One business, all four figures

Kaoko Juice bottles a single product. Selling price N$28 a bottle; variable cost N$16 a bottle; fixed costs N$96 000 a month. It currently sells 12 000 bottles a month.

**Contribution per unit** = N$28 - N$16 = **N$12 per bottle**.

**Break-even output** = N$96 000 / N$12 = **8 000 bottles a month**.

**Margin of safety** = 12 000 - 8 000 = **4 000 bottles**, which is 4 000 / 12 000 = **33.3% of current output**.

**Profit** = (N$12 x 12 000) - N$96 000 = N$144 000 - N$96 000 = **N$48 000 a month**. Checking it the other way: margin of safety x contribution = 4 000 x N$12 = N$48 000. The two routes agree, which is a useful way to catch an arithmetic slip.

**What the figures say.** Kaoko must sell 8 000 bottles before it earns anything at all, and two-thirds of everything it currently sells goes to covering that. Sales could fall by a third before it started losing money - comfortable, but not enormous for a business exposed to a bad season. And every bottle beyond 8 000 adds N$12 straight to profit, which is why volume matters so much to a business with high fixed costs.

### Reading and drawing the chart

On a break-even chart, **output is on the horizontal axis and money on the vertical**.

- The **fixed cost** line is horizontal, at the level of the fixed costs - the same at every output.
- The **total cost** line starts where the fixed cost line meets the vertical axis and slopes upward; its steepness is the variable cost per unit.
- The **total revenue** line starts at the origin, because zero output earns nothing, and slopes upward more steeply than total cost - if it did not, the business could never break even.

Where total revenue crosses total cost is the **break-even point**; read straight down to the horizontal axis for the break-even level of output. To the left of it the vertical gap between the lines is a **loss**; to the right it is **profit**. The horizontal distance from break-even output to current output is the **margin of safety**.

### Kaoko Juice, plotted

Price N$28, variable cost N$16, fixed costs N$96 000 a month, current sales 12 000 bottles. Three lines, each plotted from two points:

| Output (bottles) | Fixed costs | Total cost | Total revenue |
|---:|---:|---:|---:|
| 0 | N$96 000 | N$96 000 | N$0 |
| 4 000 | N$96 000 | N$160 000 | N$112 000 |
| 8 000 | N$96 000 | N$224 000 | N$224 000 |
| 12 000 | N$96 000 | N$288 000 | N$336 000 |

```
N$000        TR = total revenue      TC = total cost      FC = fixed costs
  360 |
      |                                                   ****
  300 |                                              *****   +
      |                                         *****++++++++
  240 |                                     ****++++
      |                            ++++****X
  180 |                    +++++++*****
      |           +++++++++  *****
  120 |   ++++++++      *****
      |+++----------****--------------------------------------
   60 |        *****
      |   *****
    0 |***
      +---------+--------+--------+--------+--------+--------+>
      0       2 000    4 000    6 000    8 000   10 000   12 000  units
```

*Key: `*` is total revenue (TR), `+` is total cost (TC), `-` is fixed costs (FC), and `X` marks where TR and TC meet. All three lines are straight. TR passes through the origin; TC starts on the vertical axis at the level of the fixed cost line. Read values off the gridlines.*

The chart is drawn from the table: total revenue from (0, N$0) to (12 000, N$336 000), total cost from (0, N$96 000) to (12 000, N$288 000), and fixed costs flat at N$96 000. Read it back and every figure from the calculations is there. The two sloping lines meet at 8 000 bottles - marked `X` - and that is the break-even output; read straight down from it to the axis. At 12 000 bottles the revenue line is at N$336 000 and the cost line at N$288 000, a vertical gap of N$48 000, which is the monthly profit. The distance along the axis from 8 000 to 12 000 is 4 000 bottles - the margin of safety. Notice too that the revenue line crosses the flat fixed-cost line earlier, at about 3 400 bottles: that is only the point where sales have covered the fixed costs, and the business is still making a loss there because total cost is higher again. Break-even is where revenue meets TOTAL cost.

And the steepness of each line comes from a per-unit figure: revenue rises N$28 for every bottle, total cost rises N$16, and the N$12 difference between those slopes is the contribution per unit, which is why the gap between the lines widens by N$12 for each extra bottle sold.

**Drawing one yourself.** Work out the value of each line at zero output and at one convenient high output, mark the two points, and join them - all three lines are straight. Label both axes with what they measure and their units, mark the break-even point where the two sloping lines cross, and write in the margin of safety if the question gives you current output.

### Three ways to lower break-even output, and what each really does

A business that wants to break even sooner has three levers, and each acts on the formula in a different place.

**Raise the selling price.** Contribution per unit rises, so fixed costs are covered by fewer units. If Kaoko raised its price to N$30, contribution becomes N$14 and break-even falls to 6 858 bottles. The catch sits outside the arithmetic: the calculation assumes the same volume sells at the higher price, and if customers leave, the business may be further from break-even, not nearer.

**Cut variable cost per unit.** Same effect through the other term - cheaper inputs, less waste, a redesigned product. At N$14 variable cost, contribution is N$14 and break-even is again 6 858. This lever tends to be safer than the first, because it does not depend on how customers react, though quality can suffer if the saving comes from a cheaper input.

**Cut the fixed costs.** A smaller premises, fewer salaried staff. Cutting fixed costs to N$84 000 brings break-even to 7 000 bottles at the original contribution. This works directly, but fixed costs are usually the hardest to move quickly and cutting them can reduce the capacity the business will need if it grows.

Which lever a business should pull depends on which of the three it can move without damaging the others - and in most cases the answer in a case study is written in the stimulus rather than in the formula.

### Rearranging the formula for what is actually asked

Questions often supply three of the four quantities and ask for the fourth. The same relationship, rearranged:

- **Fixed costs = break-even output x contribution per unit.** Given break-even output and contribution, the fixed cost total follows.
- **Contribution per unit = fixed costs / break-even output.** From that, variable cost per unit = selling price - contribution.
- **Price needed to break even at a chosen volume = (fixed costs / that volume) + variable cost per unit.** If Kaoko wanted to break even at 6 000 bottles: (N$96 000 / 6 000) + N$16 = N$16 + N$16 = **N$32 a bottle**.

Nothing new is being learned here. It is one relationship read in different directions, and recognising that is faster than memorising four formulas.

### Profit, loss and the space between

Below break-even the business is making a loss, and the loss equals the fixed costs not yet covered by contribution. At 6 000 bottles Kaoko earns 6 000 x N$12 = N$72 000 of contribution against N$96 000 of fixed costs, so it loses N$24 000.

At break-even the profit is exactly zero. Above it, profit grows by the contribution per unit for every additional unit sold - N$12 a bottle, every bottle, with no further fixed costs to meet.

That last point explains why businesses with high fixed costs and high contribution per unit are described as risky: they lose heavily below break-even and gain heavily above it. The same output change moves their profit much further than it moves the profit of a business whose costs are mostly variable.

### Uses and limitations

**What break-even analysis is used for.** Setting a sales target that everyone in the business can understand. Testing the effect of a price change or a cost increase before committing to it. Judging whether a new product or a new site is worth starting. Supporting an application for finance, because it shows a lender exactly what has to be sold for the business to stand up.

**The assumptions it rests on.** Each of these can fail, and each failure moves the answer:

- *Everything produced is sold.* If output and sales differ, the chart's revenue line overstates what came in.
- *The selling price is the same at every volume.* Selling far more usually means discounting, so the revenue line is straighter on the chart than in life.
- *Variable cost per unit does not change.* Bulk buying lowers it; overtime and rushed supply raise it.
- *Every cost sorts cleanly into fixed or variable.* Many do not - a phone bill with a standing charge and a usage charge is both.

**Two further weaknesses.** It is built on forecast figures, so it dates the moment a price or a cost moves. And a single chart assumes one product, or an unchanging mix between products - a business selling three things at different contributions has a break-even point that shifts whenever the mix does.

**What follows from all that.** Not that the technique is useless - that would be the wrong conclusion, and it is a common one. The limitations set the weight it can bear. Break-even analysis is at its most useful for isolating the arithmetic effect of changing one input while the others are held where they are: that is a sensitivity test, and it is worth doing before any change is committed to. It is weakest as a prediction, because then the assumptions are the answer.

One caution about comparisons, because it is tempting to think the assumptions do not matter when two options are set side by side. They still do. An assumption held constant may be wrong in different directions under each option - the whole point of a price rise is that it may move volume, which the calculation holds fixed. So the arithmetic isolates the effect, and the comparison is only finished when you have asked which of the held-constant figures would not in fact hold.

### Common errors

**Dividing fixed costs by output first.** Fixed costs enter the formula as a total. Turning them into a per-unit figure before dividing by contribution is the single most common way to lose the marks.

**Using total variable cost instead of variable cost per unit** in the contribution calculation. Contribution is a per-unit figure unless the question asks for total contribution.

**Mixing periods.** Monthly fixed costs with annual output, or the reverse. Check the period on both.

**Rounding down.** Break-even output rounds up: at 4 199 of a required 4 199.6, the business has not broken even.

**Answering "contribution" when the question said "profit".** Contribution is before fixed costs; profit is after.

**Treating the margin of safety as a percentage automatically.** It is a number of units unless the question asks for a percentage - and if it does, the percentage is of current output, not of break-even output.

### Where this connects

Fixed and variable costs are separated in 5.4.1 and contribution is defined in 5.4.2 - break-even analysis cannot be attempted until both are secure. The cash-flow forecast in 5.3 answers a different question: break-even is about profit, and a business can be above break-even and still run out of cash. Business objectives are in 1.4.

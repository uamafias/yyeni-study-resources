# Changelog

## 0.2.0-draft - 2026-09-08

Raised by CR-003 after the RS-28 independent review of the pilot topic (Cambridge AS Business 9609, topic 5.2)
returned **reject** with 15 open issues on a build whose deterministic pass had reported 22 of 25 checks passing.

- **Added RS-33 to RS-40** - bounded generality, generalisations surviving their members, variant completeness,
  assessment claims requiring assessment evidence, command-word-shaped practice, declared answer structures,
  offline reconstructibility, meaningful traceability.
- **Amended RS-07** (a mapping counts only where the item actually practises the objective) and **RS-21**
  (third-party behaviour is likelihood with a reason, never certainty).
- **Six new hard release blockers.**
- **New check suite** at `checks/` - 28 subject-agnostic checks, `not_run` never counts as a pass, a raising check
  is a failing check. Proven against the unrepaired pilot: it independently rediscovered 13 of the 15 review issues.
- **New generated review packet** at `checks/make_review_packet.py` - the reviewer brief and prompt are assembled
  from the build, not hand-written per topic.
- **New human-maintained inputs**: `subject-profile.yaml -> variant_register` and `-> answer_structures`;
  `contract.json -> depth_constraints.excluded_constructs`.
- **New `OPERATOR_RUNBOOK.md`** for teams running the pipeline across many subjects.
- Recorded, in the check source and the runbook, one check that was written and withdrawn for firing on 47 of 68
  items, so nobody rewrites it.

### Found while repairing the pilot topic

- `run_checks.py` now **carries forward any semantic review already on file**. It previously overwrote
  `qa_report.json` wholesale, so every deterministic run silently erased the reviewer's verdict.
- The release decision now reads **unresolved issues**, not the stored verdict. A review that said reject and
  whose issues are all resolved leaves the build awaiting re-review rather than rejected forever - and a build
  whose issues the author has marked resolved can never reach `pass` on that basis alone.
- Added **C-00 schema validity** (the suite had no schema check) and schema support for the three new fields the
  rules require: `generality` on a claim, `generalisation_scope` on a content block, and `variant_register` /
  `answer_structures` on a subject profile.
- Added `build/render_notes.py`. The offline notes are now **rendered from the content units** rather than
  maintained separately, which is what makes RS-39 structural instead of aspirational.
- Two language patterns were narrowed after firing on ordinary prose: `never` and `always` now need a modal or a
  quantified object, and `guarantee` now needs a verb form. `can be` was removed from the hedge list - it was
  suppressing genuine exclusivity claims such as "can be obtained only from".


### Topic 5.4 review round 1 - the measurement, and four checks it bought

5.4 was the first topic authored under v0.2.0 rather than repaired into it. It passed all 31 checks first time and
came back from review **reject: 2 critical, 6 high, 5 medium** - against 5.2's 3 critical and 10 high. Blocking
issues fell from 13 to 8.

**The finding that matters:** every defect class the rules were written for was gone. What remained was
subject-matter accuracy - a collapsed cost classification, owner's drawings treated as a fixed cost, an invalid
claim that break-even assumptions cancel between options, and an arithmetic error in a worked answer. The rules
eliminate process defects and do nothing about knowledge defects. Review is a permanent per-topic cost, not a
gate the framework eventually outgrows.

Four new checks, each built from a finding and each verified to reproduce it before the repair began:

- **C-31 syllabus modality coverage.** An objective whose syllabus wording names a chart, graph or diagram must be
  practised in that form. 5.4.4-02 was decomposed into four members but never into its two modalities, so numeric
  coverage passed while the compulsory graphic half went untaught and untested.
- **C-32 stated arithmetic is correct.** Every equation in a canonical answer is recomputed. It catches the kind of
  error that is worst in a quantitative topic and entirely checkable.
- **C-33 flashcards are self-contained.** A prompt opening "The same print shop ..." with no recorded prerequisite
  cannot be answered when scheduled alone.
- **C-34 interpretation is not an arithmetic check.** Re-deriving a figure by a second route verifies it; saying what
  it means for the business interprets it.

**C-30 was rebuilt.** Its first design compared a hash computed at stamp time against the same text, so it could
never fire. It now records `prior_hash` - the text the stamp replaced - and distinguishes a proven bulk stamp from a
stamp made before the field existed, which it reports as unauditable rather than claiming a verdict it cannot
support. `reviewed_unchanged` implements the part of RS-41 that says a re-read finding nothing to change must be
recorded rather than stamped silently.

**RS-41 drove a repair for the first time.** Revising six claims marked 21 artefacts stale and the gate named every
one, instead of a reviewer finding them three rounds later.

### Second review round - RS-41 and the propagation gate

The pilot topic was reviewed again after repair and rejected a second time with 14 issues. The finding underneath
most of them was one thing: the repair had corrected claims without propagating to every item and block citing
them, so a claim and a card sat side by side saying opposite things. Two of the three criticals were that.

- **Added RS-41 - derived work goes stale when its source changes.** Claims carry a `revision`; blocks and items
  record `claims_seen`. Bumping a claim leaves every citing artefact stale until re-authored. A stale derivative
  blocks release. Schema support added for all three fields.
- **Added C-29** to enforce it. Bootstrapped from the repair history already recorded in the files, it found
  **22 stale artefacts** on the unrepaired build - including every propagation defect the reviewer named.
- **Fixed C-28.** The packet manifest contained its own hash, which can never verify because writing the line
  changes the file. The manifest now excludes itself and its hash is detached in `packet.sha256.hash`.
- **C-12 now scans per content-unit block** rather than a character window. A variant named three sections away
  from the term has not been named where the term is taught.
- Two more over-broad language patterns narrowed (`no other`, and the `guarantee` noun).

**The lesson worth keeping:** the un-propagated card said limited liability makes borrowing "usually easier and
cheaper". The hedge suppressed the language check. *Hedging can make a factually inverted statement pass a
language check* - the pattern sees caution, the content is still wrong. Language checks police confidence, not
truth, and no amount of pattern work changes that.

## 0.2.0-draft — 2026-09-12 (CR-005)

One rule, two checks and a renderer, from the fourth review of topic 5.4 — one critical, on a build the
deterministic suite had reported clean. Full reasoning in
`operations/standard-change-requests/CR-005-generated-depictions.md`.

- **RS-47 / C-41 — depictions are generated, not authored.** `build/render_chart.py` renders a break-even chart
  from its declared parameters; C-41 re-renders every declared chart, in items and in content blocks, and fails
  any plot that is not byte-identical to the result. A plot with no declared chart fails too.
- **C-42 (RS-45) — contract counts match the live build.** The contract authorised 92 items beside a bank of 105.
- **C-35 narrowed** to accept the revenue/fixed-cost crossing as a real point on the chart.
- **`answer_structures.PROC`** declared, so C-16 stops passing procedural cards vacuously.
- Suite: 43 checks, 48 tests.

**The lesson worth keeping:** a check that tests for the *presence* of a thing will pass a fake version of that
thing. C-31 tested that a graphical objective had a chart item, and got one that was algebraically impossible.
C-35 was built to test the chart's numbers, and got one whose numbers were right and whose lines never met. The
escape is not another check on the artefact — it is to stop authoring the artefact. A generated picture cannot
be faked, because the data is the picture.

## 0.2.0-draft — 2026-09-12 (CR-004)

Four rules, four checks and two mechanisms, from the third review of topic 5.4 (0 critical, 3 high, 4 medium).
Full reasoning in `operations/standard-change-requests/CR-004-conditions-completeness-and-derived-data.md`.

- **RS-43 / C-37 — conditioned mechanisms carry their conditions.** The subject profile registers each mechanism
  whose conclusion holds only under stated conditions; the check fails any claim, block or item that asserts one
  without carrying every condition.
- **RS-44 / C-38 — an answer may not supply its own facts.** A completeness assertion in an answer needs the
  prompt to establish it, or the recommendation to be explicitly conditional. Naming a cost *category* states a
  total; enumerating named *instances* does not.
- **RS-45 / C-39 — derived metadata is recomputed, never edited.** Exposure figures must recompute from the
  evidence records, satisfy the file's own class definitions, and keep no superseded figure beside the new one.
- **RS-46 / C-40 — quantities are named in their own units.** A currency amount is not named in physical units.
- **C-27 gains written waivers.** A class floor names subtypes; where one does not fit the objective the contract
  waives it with a reason of at least twelve words, reported on every run. Padding a bank to satisfy a count
  teaches nothing; a silent gap hides a real one.
- **`checks/ingest_review.py`** replaces the hand edit that merged a review into a qa report, and refuses to mark
  an issue resolved without a written reason.
- Exposure class definitions amended to read on frequency as well as tariff. Recomputing all 258 objectives moved
  exactly one.
- Suite: 41 checks, 43 tests.

**The lesson worth keeping:** all three high issues in round three came from the *repair* step, not from
authoring. A repair that fixes the claim leaves the topic wrong, because every mechanism is taught in several
places and the condition has to travel to all of them. RS-41 cannot see this - the unrepaired copies were never
stale, they cite a different claim. Only a check that recognises the mechanism itself can find them.

## 0.1.0-draft — 2026-08-31

Initial team-review package containing:

- concise operative runtime standard;
- machine-readable runtime standard;
- end-to-end pipeline;
- universal artifact schemas;
- Business subject profile;
- Cambridge International AS Level Business 9609 qualification profile for 2026–2028;
- deterministic validator and pytest suite;
- valid draft fixture and negative controls;
- independent semantic-review protocol;
- draft Claude Co-work handoff prompt;
- team review questions.
